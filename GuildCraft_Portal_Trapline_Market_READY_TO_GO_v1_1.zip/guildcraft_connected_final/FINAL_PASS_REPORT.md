# GuildCraft Connected Rooms — Targeted Fix Full Pass

**Build checked:** `GuildCraft_Connected_Rooms_Portal_v1_1_TARGETED_FIX.zip`  
**Order:** Portal → Trapline → Market Stall  
**Method:** archive integrity, JavaScript syntax, JSON parse, local-reference audit, cross-room contract inspection, targeted runtime harnesses, and browser smoke attempt guided by the Game Studio playtest checklist.

## Verdict

**PASS WITH ONE DISCUSSION EDGE CASE + ONE LOW-PRIORITY DRIFT ITEM.**

The targeted fixes hold. The Black Cottontail rumor is one-shot and exact, Ada is the visible maker, the direct-delivery bridge is inactive, Wild↔Market transitions use the Portal player state, ground drops still obey the 24-hour rule, and the player stall till remains non-portable.

No files were modified during this pass.

---

## 1. Portal

### PASS — shared player / room bridge
- Portal runtime owns the `guildcraft.portal.snapshot` schema.
- The portable code uses the single `GCPS1` template.
- Portal listens for `GC_ROOM_TRANSITION` and swaps the Game View between Trapline and Market without requiring the player to leave the overall Portal session.
- Launching a room now uses `classList.add('max')` rather than the older toggle behavior, so a room transition does not accidentally collapse the Game View.

### PASS — portable card excludes stall till
A runtime round-trip confirmed that a Market room snapshot containing a `marketBusiness.till` value is sanitized before export. The exported `GCPS1` payload contains no till value.

### DISCUSSION EDGE CASE — loading a Player Card currently deletes the browser-held till
`PortalRuntime.importCode()` explicitly executes:

`sessionStorage.removeItem(marketTill_<playerId>)`

This means an uncollected till can sit in browser memory indefinitely **until the player imports/loads a Player Card in that same browser**. At that moment the local till is cleared even though the card itself never owned the money.

This is not a duplication or account-credit bug: the till is still excluded from the card and never enters the player's floppy balance automatically. It is simply a policy question created by the clarified rule:

- current behavior: **card load wipes uncollected local till**
- possible alternate behavior: **card load ignores the till entirely; the existing browser-held till remains locked to the stall**

Per the user's instruction to let this behavior ride and discuss glitches before changing them, this pass does **not** modify it.

### PASS — schema / package checks
- Portal JS syntax: pass.
- Portal JSON: pass.
- Local assets/references: pass.

---

## 2. Trapline / The Wild

### PASS — room role
Trapline remains the resource/survival room. No `workshop.js` is loaded and the player-facing transition is Market-bound rather than a local manufacturing loop.

### PASS — shared inventory transition
`portalTransfer.enterMarket()`:
1. synchronizes the Portal Player Card,
2. commits the hidden-rabbit clue eligibility,
3. saves the local Wild state,
4. transitions to `market-stall`.

There is no normal cargo-claim step.

### PASS — old delivery path inactive
No active `deliveryBridge` / `pendingDeliveries` path was found in the connected runtime.

### PASS — ground-drop behavior
The ground-drop system still:
- drops overflow items rather than deleting them,
- allows selective pickup,
- leaves an item on the ground if the bag is still full,
- persists drop state,
- expires drops at `1440` game minutes = 24 in-game hours.

### PASS — package/static checks
- Trapline JS syntax: pass.
- Trapline JSON: pass.
- Local references: pass.

---

## 3. Market Stall

### PASS — one-shot Black Cottontail rumor
The Wild runner has persistent fields for:
- `blackLineFired`
- `blackRumorPending`
- `blackRumorDelivered`

The delivered line is exactly:

`did you hear someone found the Black Cottontail?`

After delivery, the pending flag is cleared and later conversations return to the normal Wild-comparison dialogue. The hashed audit marker remains attached to the arm/delivery events.

### PASS — NPC manufacturing presentation
The player-facing recipe action is now:

`Ask Ada to make ...`

The active handler describes the output as an NPC service rather than player manufacturing. Trapline remains outside this production path.

### PASS — player stall / till separation
- Stall sales place proceeds into the stall till.
- Till money is not immediately added to the Player Card.
- The player must physically be at the stall to collect it.
- Collection then moves the amount into `player.floppyBalance` and synchronizes Portal state.
- Browser-held till uses `sessionStorage` and is excluded from portable snapshots.

### PASS — hired seller / away simulation
The hired seller participates in background sales while the player is away. Catch-up processing resolves elapsed time when Market is loaded again rather than requiring the Market room to remain rendered continuously.

### PASS — three roaming market actors
- **Kerr Voss / agitator:** applies price pressure and reacts to player display pricing.
- **Mira Quill / liquidity:** uses actual inventory and finite currency while moving stock.
- **Rook Fen / Wild runner:** leaves on expeditions, returns with actual tracked inventory, and compares Wild performance with the player.

### LOW — dormant legacy self-crafting function remains loaded
`market-stall/crafting.js` still contains `crafting.attemptCraft()`, which directly consumes components and adds a finished item to the player's inventory. The normal UI does not call this function; the visible path uses Ada via `onAttemptCraft()` / the Market crafter systems.

So this is not currently a player-facing crafting route, but it is stale architecture that could be accidentally reused later. Removing or hard-disabling it would make the “Market NPC crafts, player does not” contract cleaner.

### PASS — package/static checks
- Market JS syntax: pass.
- Market JSON: pass.
- Local references: pass.

---

## Cross-package checks

- ZIP integrity: **PASS**.
- JavaScript `node --check`: **0 failures**.
- JSON parse: **0 failures**.
- Missing local HTML asset/script/style references: **0**.
- Portal room transition wiring: **PASS**.
- Direct-delivery bridge absence: **PASS**.
- Targeted one-shot rumor fix: **PASS**.
- Ada wording fix: **PASS**.
- Portable till exclusion: **PASS**.

## Browser / visual QA

A fresh local HTTP server was started and Chromium headless was attempted again. Chromium still hangs in this execution environment before producing a usable DOM/screenshot, so visual/mobile QA is **not marked as passed**. This is an environment limitation, not evidence of a game failure.

## Recommended next action

The build is mechanically safe to continue testing. Before changing the till behavior, decide whether **loading a Player Card on the same browser should erase the currently browser-held, uncollected till or simply leave that till untouched and locked to Market**.

The only cleanup I would do without changing behavior is remove/hard-disable the dormant `crafting.attemptCraft()` route so future code cannot accidentally bypass Ada.
