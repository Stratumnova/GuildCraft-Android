# GuildCraft Connected Rooms — Build Audit v1.1

Order checked: Portal → Trapline / The Wild → Market Stall.

## Portal — PASS
- Four canonical mapped terminals remain: Game View, Player Information, Console / Log, Games / Versions.
- Portal owns the shared Player Card state and room registry.
- One extensible portable snapshot contract: `guildcraft.portal.snapshot`, schema 1.
- Portable code format: `GCPS1.<payload>.<checksum>`.
- Snapshot export/import round-trip test passed.
- Carried inventory and floppy balance are shared above room state.
- Wild ↔ Market uses room transitions, not cargo claims.
- Player Card pause overlay supports code copy, load validation and print.
- Uncollected Market stall till is excluded from portable snapshots.
- Legacy schema-4 cargo ledger remains only as compatibility/audit material.

## Trapline / The Wild — PASS
- No active `deliveryBridge.js` script.
- Direct `Enter Market` transition is wired through Portal room bridge.
- Resource/survival role retained: hunting, trapping, gathering, ecology, live specimens, camp systems.
- No Market-style manufacturing path and field cooking button removed; prepared food comes from Market crafter.
- Ground overflow remains selectable and persists for 1,440 game minutes (24 in-game hours).
- Hidden cottontail catch sets the shared one-time cross-room trigger without changing its ordinary visual/label behavior.

## Market Stall — PASS
- No active Trapline cargo-claim panel or delivery bridge.
- Uses the same Portal-owned carried inventory and floppy balance.
- NPC crafter manufactures field gear and prepared food from supplied materials.
- Missing recipe inputs can be purchased from actual Market supply when stock/currency permit.
- Player can purchase a stall, stock it, sell from the exact stall location, and later hire a seller.
- Stall sales go into an uncollected till. The till is session-local and is not part of local/portable save snapshots; player must return to the stall and collect it before the floppies join the Player Card.
- Hired seller runs background sales while player is away; return-time catch-up is bounded.
- Player stall only joins walking-NPC foreground targeting while the player is exactly at the stall; otherwise it is handled by background simulation.
- Background Market supply/demand/currency remains separate from player-visible account values.
- Three roaming market actors exist and come/go:
  - price agitator: changes both player selling pressure and material-buying cost pressure;
  - liquidity trader: moves real inventory using finite NPC currency and accepts the offered price;
  - Wild runner: returns with a real tracked haul, sells that stock, and compares Wild performance to the player.
- Hidden Wild-runner rumor is one-shot after the hidden cottontail is caught: `did you hear someone found the Black Cottontail?`
- Hidden rumor SHA-256 marker: `f7c47e95440539c7844fdbb96dca087d9bbf5f0fbea80a3a8670438a7a83b87f`.
- Iris Vale rewards now update the live shared player floppy balance before Portal sync, avoiding the prior overwrite bug.

## Mechanical QA — PASS
- All JavaScript passed `node --check`.
- All JSON parsed successfully.
- All local HTML `src` / `href` references resolve.
- Portable snapshot runtime round-trip passed with inventory preservation and stall-till exclusion.
- Ordered architecture assertions all passed.
- No active direct `deliveryBridge.js` references remain.

## Browser QA note
This pass validates source, runtime contracts and deterministic Node-executable snapshot logic. It does not claim a screenshot-based Chromium/mobile visual pass in this container.
