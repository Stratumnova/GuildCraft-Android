# GuildCraft Connected Rooms — Ready-to-Go Build

This package contains the three connected surfaces:

- `portal/` — shared player/account authority, pause/player-card surface, room bridge, snapshot/export/import tools.
- `trapline/` — The Wild resource/survival room. No player manufacturing path is exposed here.
- `market-stall/` — Market room with NPC economy, Ada crafting, player stall, roaming market actors, and stall till.

## Locked current behavior

- Player inventory/account continuity follows the Portal shared-state contract between rooms.
- Trapline is a resource-pool/survival room.
- Ada is the current visible manufacturing path in Market Stall.
- `market-stall/crafting.js` is retained as dormant/reserved infrastructure for a possible future player crafting bench; no current live UI should expose it as a player crafting bypass.
- Uncollected stall till remains locked to the market stall/browser state and is excluded from portable Player Card snapshots until the player physically collects it.
- Local room state versus imported snapshot precedence is intentionally left in its current hybrid behavior for live testing.
- Hidden Black Cottontail rumor is one-shot and uses the exact intended line.

See `FINAL_PASS_REPORT.md` for the latest ordered Portal → Trapline → Market Stall audit.
