const PortalReleaseQA={
 run(playerId='testPlayerOne'){
  const checks=[]; const add=(name,ok,detail='')=>checks.push({name,ok:!!ok,detail});
  const map={game:{x:11.7,y:23.4,w:29.9,h:25.4},player:{x:58.3,y:23.4,w:29.9,h:25.4},console:{x:11.7,y:56.6,w:29.9,h:25.4},games:{x:58.3,y:56.6,w:29.9,h:25.4}};
  add('Canonical stage 1536×1024',document.getElementById('stage')!==null,'3:2 spatial stage');
  add('Four mapped terminal panels',['game','player','console','games'].every(id=>document.getElementById('panel-'+id)));
  add('No free dragging',!document.querySelector('[draggable="true"]'));
  add('Trapline launcher wired',!!document.querySelector('[data-game="trapline"]'));
  add('Market launcher wired',!!document.querySelector('[data-game="market"]'));
  add('Portal snapshot schema 1',typeof PortalRuntime!=='undefined'&&PortalRuntime.VERSION===1);
  add('Single export/import template',typeof PortalRuntime?.exportCode==='function'&&typeof PortalRuntime?.importCode==='function');
  const state=typeof PortalRuntime!=='undefined'?PortalRuntime.read(playerId):null;
  add('Player Card owns carried inventory',!!state&&!!state.player&&typeof state.player.inventory==='object');
  add('Room bridge tracks current room',!!state&&!!state.session&&typeof state.session.currentRoom==='string',state?.session?.currentRoom||'missing');
  const portable=typeof PortalRuntime!=='undefined'?PortalRuntime.sanitizedSnapshot(playerId):null;
  add('Portable snapshot excludes uncollected stall till',!portable?.rooms?.['market-stall']?.state?.marketBusiness?.till);
  add('Legacy cargo ledger retained for audit only',typeof PortalLedger!=='undefined'&&PortalLedger.SCHEMA===4);
  const res={passed:checks.filter(c=>c.ok).length,total:checks.length,checks,at:new Date().toISOString(),layout:map};
  localStorage.setItem(`portalReleaseQA_${playerId}`,JSON.stringify(res)); return res;
 },
 text(playerId='testPlayerOne'){const r=this.run(playerId);return [`Portal release QA ${r.passed}/${r.total}`,...r.checks.map(c=>`${c.ok?'PASS':'FAIL'} | ${c.name}${c.detail?' | '+c.detail:''}`)].join('\n')}
};
