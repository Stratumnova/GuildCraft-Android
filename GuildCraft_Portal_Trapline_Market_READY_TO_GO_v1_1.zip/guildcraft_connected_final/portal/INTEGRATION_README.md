# Portal integration v1.1

Portal is the account/state bridge for all rooms. The current rooms are sibling folders `trapline/` and `market-stall/` and run inside the mapped Game View terminal.

Current room versions:
- Trapline Survival v1.6 / The Wild / simulation schema 11
- Market Stall Fieldworks v1.4
- Portal portable snapshot schema 1
- Legacy schema-4 transfer ledger retained only as historical/debug compatibility; ordinary room continuity does not use it.

The same Player Card inventory, floppy balance, progression, and room registry follow the player between rooms. Each room owns only its local world state.
