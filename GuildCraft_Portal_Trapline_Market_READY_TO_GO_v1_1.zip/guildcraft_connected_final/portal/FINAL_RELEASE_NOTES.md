# R_D Portal v1.0 Final

Final integration release for Portal + Trapline + Market Stall.

## Locked runtime contract
- Portal is the cross-game cargo authority.
- Trapline extracts raw materials/specimens and consumes Market-made field gear.
- Market Stall processes/crafts gear and fulfills Iris Vale field requests.
- Secret cottontail is never ordinary cargo. Portal reveals the route only when the route marker exists **and** the saved Trapline state still proves the unique cottontail is alive and carried.
- Four mapped Portal terminals remain fixed to the rabbit artwork; panels open/close/maximize without free dragging.

## Final QA additions
- Ledger schema 4 adds checksum repair/validation and rejects tampered or contract-invalid pending transfers.
- `qa` console command runs Portal release invariants.
- Final build includes RELEASE_MANIFEST.json and automated static regression results.
