(function(global){
  const SCHEMA=4, MAX=500;
  const transferable={
    traplineToMarket:new Set(['wood','hardwood','ironOre','copperOre','fiber','cordage','medicinalHerb','resin','scrapMetal','oldAlloy','rabbitPelt','squirrelPelt','turkeyFeather','deerPelt','beaverPelt','raccoonPelt','foxPelt','owlFeather','boarHide','wolfPelt','rabbitMeat','squirrelMeat','turkeyMeat','deerMeat','beaverMeat','raccoonMeat','boarMeat','wolfMeat',...['rabbit','squirrel','turkey','deer','beaver','raccoon','fox','owl','boar','wolf'].map(k=>`live:${k}`)]),
    marketToTrap:new Set(['bagTier1','bagTier2','bagTier3','bagTier4','trapKit:0','trapKit:1','trapKit:2','trapKit:3','spear1','spear2','spear3','bow1','bow2','bow3','arrows','gun1','gun2','gun3','shot','powder','bait','predatorBait','captureCrate','captureRig','fieldTonic','tentKit','campfireKit','repairKit'])
  };
  function now(){return new Date().toISOString()}
  function uid(){return `tx_${Date.now()}_${Math.random().toString(36).slice(2,9)}`}
  function hashText(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16).padStart(8,'0')}
  function checksumFor(t){return hashText(`${t.id}|${t.sourceGame}|${t.destinationGame}|${t.itemId}|${t.quantity}|${t.originRecipe||''}`)}
  function normalize(raw){
    const state=raw&&typeof raw==='object'?raw:{}; const out={schema:SCHEMA,revision:Number(state.revision||0),transfers:[],audit:Array.isArray(state.audit)?state.audit.slice(-MAX):[]};
    const seen=new Set(); let repaired=0,rejected=0,duplicates=0;
    (Array.isArray(state.transfers)?state.transfers:[]).forEach((t,i)=>{
      if(!t||typeof t!=='object')return; const id=String(t.id||`legacy_${i}_${hashText(JSON.stringify(t))}`); if(seen.has(id)){duplicates++;return} seen.add(id);
      const qty=Math.max(0,Math.floor(Number(t.quantity)||0)); if(!qty)return;
      let status=['pending','claimed','cancelled','rejected'].includes(t.status)?t.status:'pending';
      const tx={id,sourceGame:String(t.sourceGame||'unknown'),destinationGame:String(t.destinationGame||'unknown'),itemId:String(t.itemId||''),quantity:qty,status,createdAt:t.createdAt||now(),claimedAt:t.claimedAt||null,originRecipe:t.originRecipe||null,provenance:t.provenance||null,lastError:t.lastError||null,checksum:t.checksum||null};
      const expected=checksumFor(tx);
      if(!tx.checksum){tx.checksum=expected;repaired++}
      else if(tx.checksum!==expected){tx.status='rejected';tx.lastError='checksum-mismatch';tx.checksum=expected;rejected++;repaired++}
      if(!allowed(tx.sourceGame,tx.destinationGame,tx.itemId) && tx.status==='pending'){tx.status='rejected';tx.lastError='blocked-by-transfer-contract';rejected++}
      out.transfers.push(tx);
    });
    if(repaired||rejected||duplicates) out._repair={repaired,rejected,duplicates};
    return out;
  }
  function key(playerId){return `portalTransfers_${playerId}`}
  function read(playerId){let raw={};try{raw=JSON.parse(localStorage.getItem(key(playerId))||'{}')}catch{} const s=normalize(raw); if(raw.schema!==SCHEMA||s._repair){delete s._repair;localStorage.setItem(key(playerId),JSON.stringify(s))} return s}
  function write(playerId,state,action,meta={}){const s=normalize(state);delete s._repair;s.revision=(Number(s.revision)||0)+1;if(action)s.audit.push({at:now(),action,...meta});s.audit=s.audit.slice(-MAX);s.transfers=s.transfers.slice(-MAX);localStorage.setItem(key(playerId),JSON.stringify(s));return s}
  function allowed(source,dest,item){if(item==='liveCottontail'||item==='blackCottontail'||item==='live:black_cottontail')return false;if(source==='trapline'&&dest==='market-stall')return transferable.traplineToMarket.has(item);if(source==='market-stall'&&dest==='trapline')return transferable.marketToTrap.has(item);return false}
  function create(playerId,{sourceGame,destinationGame,itemId,quantity,originRecipe=null,provenance=null}){
    const qty=Math.max(0,Math.floor(Number(quantity)||0)); if(!qty||!allowed(sourceGame,destinationGame,itemId))return {ok:false,error:'blocked-by-transfer-contract'};
    const s=read(playerId), id=uid(); const tx={id,sourceGame,destinationGame,itemId,quantity:qty,status:'pending',createdAt:now(),claimedAt:null,originRecipe,provenance,lastError:null}; tx.checksum=checksumFor(tx); s.transfers.push(tx); write(playerId,s,'create',{id,itemId,quantity:qty,sourceGame,destinationGame}); return {ok:true,transfer:tx};
  }
  function pending(playerId,destinationGame){return read(playerId).transfers.filter(t=>t.status==='pending'&&(!destinationGame||t.destinationGame===destinationGame))}
  function claim(playerId,destinationGame,accept){
    const s=read(playerId); let claimed=0, blocked=0;
    s.transfers.forEach(t=>{if(t.status!=='pending'||t.destinationGame!==destinationGame)return;if(!allowed(t.sourceGame,t.destinationGame,t.itemId)){t.status='rejected';t.lastError='blocked-by-transfer-contract';blocked++;return}let ok=false;try{ok=!!accept(t)}catch(e){t.lastError='destination-error';blocked++;return}if(ok){t.status='claimed';t.claimedAt=now();t.lastError=null;claimed++;}else{t.lastError='destination-capacity-or-validation';blocked++;}});
    write(playerId,s,'claim-pass',{destinationGame,claimed,blocked}); return {claimed,blocked};
  }
  function stats(playerId){const s=read(playerId),p=s.transfers.filter(t=>t.status==='pending');return {schema:SCHEMA,revision:s.revision,total:s.transfers.length,pending:p.length,toMarket:p.filter(t=>t.destinationGame==='market-stall').length,toTrap:p.filter(t=>t.destinationGame==='trapline').length,rejected:s.transfers.filter(t=>t.status==='rejected').length,audit:s.audit};}
  function validate(playerId){const s=read(playerId);const bad=s.transfers.filter(t=>t.checksum!==checksumFor(t));return {ok:bad.length===0,bad:bad.map(t=>t.id),schema:s.schema,revision:s.revision}}
  global.PortalLedger={SCHEMA,transferable,read,write,allowed,create,pending,claim,stats,validate};
})(window);
