// milestoneCounter.js
// -----------------------------------------------------------------------------
// Generic capped counter with milestone triggers. Mined from two Godot
// cousins: loopcoin_manager.gd (0-25, first 10 fill a hotbar, deposit wipes)
// and bytecoin_manager.gd (0-25, milestones at 5/10/15/20/25 drive an HP
// curve). Both are the same shape underneath: collect up to a cap, fire an
// event at specific thresholds, do something when the cap is reached, reset
// on demand. No lore, no hotbar/HP specifics — those are the caller's job.
// -----------------------------------------------------------------------------

const MilestoneCounter = {
  /**
   * milestones: sorted array of thresholds to fire events at, e.g. [5,10,15,20,25]
   * cap: hard max the counter will not exceed
   */
  create(id, { cap, milestones = [] } = {}) {
    return { id, cap, milestones: [...milestones].sort((a, b) => a - b), count: 0 };
  },

  /** Returns { granted, milestonesHit, capped } — never mutates past cap. */
  collect(counter, amount = 1) {
    const before = counter.count;
    const after = Math.min(counter.cap, before + amount);
    const granted = after - before;
    counter.count = after;

    const milestonesHit = counter.milestones.filter(m => before < m && after >= m);
    const capped = after >= counter.cap;

    if (typeof EventConsole !== "undefined" && granted > 0) {
      EventConsole.emit(
        "MILESTONE_COUNTER",
        `${counter.id} +${granted} (${after}/${counter.cap})`,
        capped ? "cap reached" : milestonesHit.length ? `milestone ${milestonesHit.join(",")}` : "collected",
        { id: counter.id, count: after, milestonesHit, capped }
      );
    }
    return { granted, milestonesHit, capped };
  },

  /** How many milestones have been passed at the counter's current value. */
  milestonesPassed(counter) {
    return counter.milestones.filter(m => counter.count >= m).length;
  },

  isFull(counter) {
    return counter.count >= counter.cap;
  },

  /** Zero the counter out — this is a per-level/per-run reset, not a wipe of history. */
  reset(counter) {
    counter.count = 0;
    if (typeof EventConsole !== "undefined") {
      EventConsole.emit("MILESTONE_COUNTER", `${counter.id} reset`, "level/run reset", { id: counter.id });
    }
  },
};

if (typeof module !== "undefined") module.exports = MilestoneCounter;
