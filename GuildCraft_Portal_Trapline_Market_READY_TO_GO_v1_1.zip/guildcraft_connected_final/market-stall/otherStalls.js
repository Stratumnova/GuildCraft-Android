// otherStalls.js
// -----------------------------------------------------------------------------
// 10 background stalls scattered around the map. Each is assigned a
// category (cycling through the 5 base categories) and auto-restocks a
// couple of display slots so NPCs always have something to consider buying.
// These are NOT the player's stall - no player currency is involved, but
// every sale here still gets logged (Section: dev log, Section: 10 stalls).
// -----------------------------------------------------------------------------

const otherStalls = {
  list: [],

  // Spread across the 32x32 grid, away from the player's own stall
  // (which sits around column 12-16, row 10-11).
  positions: [
    { column: 4, row: 4 }, { column: 28, row: 4 },
    { column: 4, row: 28 }, { column: 28, row: 28 },
    { column: 16, row: 2 }, { column: 2, row: 16 },
    { column: 30, row: 16 }, { column: 16, row: 30 },
    { column: 8, row: 22 }, { column: 24, row: 8 },
  ],

  categoryCycle: ["food", "blacksmith", "alchemy", "carpenter", "tannery"],

  setup() {
    this.list = this.positions.map((position, index) => {
      const categoryKey = this.categoryCycle[index % this.categoryCycle.length];
      const aiStall = {
        id: `stall_${index}`,
        categoryKey,
        column: position.column,
        row: position.row,
        slots: [null, null],
        restockTimer: 0,
      };
      this.restock(aiStall);
      return aiStall;
    });
  },

  // Stocks an empty slot with a random early-stage item from this stall's
  // category, priced at the plain NPC base rate for that stage.
  restock(aiStall) {
    const categoryData = techTree[aiStall.categoryKey];
    if (!categoryData || !categoryData.paths) return;

    const pathKeys = Object.keys(categoryData.paths);
    const chosenPathKey = pathKeys[Math.floor(Math.random() * pathKeys.length)];
    const pathData = categoryData.paths[chosenPathKey];
    const maxStageToStock = Math.min(3, pathData.stages.length); // keep restocks to early, common items
    const stageIndex = Math.floor(Math.random() * maxStageToStock);
    const stageData = pathData.stages[stageIndex];
    const itemData = stageData.items[Math.floor(Math.random() * stageData.items.length)];
    const sweetSpot = pricing.npcBasePriceByStage[stageIndex];

    for (let i = 0; i < aiStall.slots.length; i++) {
      if (!aiStall.slots[i]) {
        aiStall.slots[i] = { itemName: itemData.name, askingPrice: sweetSpot, sweetSpot };
        break;
      }
    }
  },

  attemptPurchaseFromStall(aiStall) {
    const occupiedIndexes = aiStall.slots
      .map((slot, index) => (slot ? index : null))
      .filter((index) => index !== null);
    if (occupiedIndexes.length === 0) return false;

    const chosenIndex = occupiedIndexes[Math.floor(Math.random() * occupiedIndexes.length)];
    const slot = aiStall.slots[chosenIndex];
    const acceptChance = pricing.calculateAcceptChance(slot.askingPrice, slot.sweetSpot);

    if (Math.random() < acceptChance) {
      this.completeSale(aiStall, chosenIndex);
      return true;
    }
    return false;
  },

  // Finalizes a sale with no RNG of its own - see display.js's completeSale
  // for why this split exists (personality-adjusted rolls in npc.js).
  completeSale(aiStall, slotIndex) {
    const slot = aiStall.slots[slotIndex];
    if (!slot) return false;
    salesLog.logSale(aiStall.id, slot.itemName, slot.askingPrice);
    aiStall.slots[slotIndex] = null;
    aiStall.restockTimer = 5;
    return true;
  },

  // Picks a random occupied slot without rolling for purchase - lets a
  // caller (npc.js) compute its own accept chance against that specific
  // slot before deciding whether to call completeSale.
  pickRandomOccupiedSlotIndex(aiStall) {
    const occupiedIndexes = aiStall.slots
      .map((slot, index) => (slot ? index : null))
      .filter((index) => index !== null);
    if (occupiedIndexes.length === 0) return null;
    return occupiedIndexes[Math.floor(Math.random() * occupiedIndexes.length)];
  },

  update(deltaSeconds) {
    this.list.forEach((aiStall) => {
      if (aiStall.restockTimer > 0) {
        aiStall.restockTimer -= deltaSeconds;
        if (aiStall.restockTimer <= 0) this.restock(aiStall);
      }
    });
  },

  draw(canvasContext) {
    this.list.forEach((aiStall) => {
      const color = stall.categoryColors[aiStall.categoryKey] || "#999999";
      stall.drawHalfBlockTable(canvasContext, aiStall.column, aiStall.row, color);
    });
  },
};
