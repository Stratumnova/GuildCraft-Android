// display.js
// -----------------------------------------------------------------------------
// The 4+ slot display table. Player places ANY item from inventory into a
// slot and sets an asking price; NPCs check occupied slots and buy (or
// don't) based on the sweet-spot model in pricing.js. Extra slots can be
// purchased.
// -----------------------------------------------------------------------------

const displayTable = {

  slots: [null, null, null, null], // each: { itemName, askingPrice, sweetSpot } or null

  expandSlotCost: 25, // rises each time a slot is added

  placeItem(slotIndex, itemName, askingPrice) {
    if (typeof marketBusiness !== "undefined" && !marketBusiness.state.owned) return false;
    if (this.slots[slotIndex]) {
      console.log("That display slot is already occupied.");
      return false;
    }
    if (!(player.inventory[itemName] > 0)) {
      console.log(`You don't have a ${itemName} to display.`);
      return false;
    }

    // Sweet spot is snapshotted at placement time so it works for ANY
    // inventory item, not just items tied to a known crafting stage.
    const sweetSpot = pricing.getSweetSpotForItem(itemName);

    player.inventory[itemName] -= 1;
    this.slots[slotIndex] = { itemName, askingPrice, sweetSpot };
    return true;
  },

  removeItem(slotIndex) {
    const slot = this.slots[slotIndex];
    if (!slot) return;
    player.addToInventory(slot.itemName, 1);
    this.slots[slotIndex] = null;
  },

  attemptPurchaseFromSlot(slotIndex) {
    const slot = this.slots[slotIndex];
    if (!slot) return false;

    const acceptChance = pricing.calculateAcceptChance(slot.askingPrice, slot.sweetSpot);

    if (Math.random() < acceptChance) {
      this.completeSale(slotIndex);
      return true;
    }
    return false;
  },

  // Finalizes a sale with no RNG of its own - used both by the plain
  // attemptPurchaseFromSlot roll above AND by callers (npc.js) that already
  // rolled their own accept chance, e.g. with a personality-adjusted sweet
  // spot instead of the flat one.
  completeSale(slotIndex) {
    const slot = this.slots[slotIndex];
    if (!slot) return false;
    crafting.recordSale(slot.itemName, slot.askingPrice, "player");
    this.slots[slotIndex] = null;
    return true;
  },

  getOccupiedSlotIndexes() {
    return this.slots
      .map((slot, index) => (slot ? index : null))
      .filter((index) => index !== null);
  },

  // Adds one more display slot, at a rising floppies cost.
  expandSlots() {
    if (player.floppyBalance < this.expandSlotCost) {
      console.log("Not enough floppies to add a display slot.");
      return false;
    }
    player.floppyBalance -= this.expandSlotCost;
    this.slots.push(null);
    this.expandSlotCost = Math.round(this.expandSlotCost * 1.5);
    return true;
  },
};
