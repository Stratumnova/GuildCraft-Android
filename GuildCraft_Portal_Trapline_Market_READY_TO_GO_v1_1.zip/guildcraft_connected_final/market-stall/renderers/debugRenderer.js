// debugRenderer.js — preserves the original instrumented renderer.
const DebugRenderer = {
  id: "debug",
  draw(ctx) {
    grid.draw(ctx);
    otherStalls.draw(ctx);
    stall.draw(ctx);
    npc.draw(ctx);
    worker.draw(ctx);
  }
};
