// worldRenderer.js — player-facing renderer over the same Market Stall simulation.
// Past/Current/Plan guard: visual reuse is presentation; it does not silently establish new lore facts.
const WorldRenderer = {
  id:"world", assets:{}, ready:false,
  load(){
    const p="assets/byte-my-chip/byte-my-chip/assets/";
    const e="assets/emergent/tiles/";
    const paths={floor:p+"tiles/floor_cracked.png",grate:p+"tiles/floor_metal_grating.png",terminal:p+"tiles/terminal_info.png",floppy:p+"tiles/bytecoin.png",player:p+"sprites/player_idle/down.png",
      crates:e+"prop_supply_crates.png",barrel:e+"prop_barrel.png",bench:e+"prop_workbench.png",server:e+"prop_server_rack.png",debris:e+"prop_debris_pile.png",lantern:e+"fixture_lantern.png",panel:e+"fixture_control_panel.png",tools:e+"fixture_tool_rack.png",junction:e+"fixture_junction_box.png",monitors:e+"prop_monitor_stack.png",computer:e+"fixture_computer_terminal.png",battery:e+"prop_battery_rack.png"};
    Object.entries(paths).forEach(([k,src])=>{const img=new Image();img.src=src;this.assets[k]=img;}); this.ready=true;
  },
  img(ctx,key,c,r,w=1,h=1,a=1){const im=this.assets[key];if(!im||!im.complete||!im.naturalWidth)return;const q=grid.cellToPixels(c,r);ctx.save();ctx.globalAlpha=a;ctx.imageSmoothingEnabled=false;ctx.drawImage(im,q.x,q.y,60*w,60*h);ctx.restore();},
  awning(ctx,c,r,w,color){const x=c*60,y=r*60;ctx.save();ctx.fillStyle="#3a281d";ctx.fillRect(x,y+34,w*60,18);ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(x-8,y+34);ctx.lineTo(x+w*60+8,y+34);ctx.lineTo(x+w*60-12,y-22);ctx.lineTo(x+12,y-22);ctx.closePath();ctx.fill();ctx.strokeStyle="#241914";ctx.lineWidth=5;ctx.stroke();ctx.restore();},
  actor(ctx,u){const p=grid.cellToPixels(u.gridColumn,u.gridRow),x=p.x+30,y=p.y+30;ctx.save();ctx.fillStyle=npc.getColorForNpc(u);ctx.beginPath();ctx.arc(x,y+5,19,0,Math.PI*2);ctx.fill();ctx.fillStyle="#d1b18a";ctx.beginPath();ctx.arc(x,y-16,12,0,Math.PI*2);ctx.fill();ctx.fillStyle="#2a211c";ctx.fillRect(x-16,y+22,32,15);if(u.name){ctx.font="bold 13px Georgia";ctx.textAlign="center";ctx.fillStyle="#f0e1b5";ctx.fillText(u.name,x,y-34);}ctx.restore();},
  draw(ctx){
    if(!this.ready)this.load(); ctx.fillStyle="#39382e";ctx.fillRect(0,0,1920,1920);
    for(let r=0;r<32;r++)for(let c=0;c<32;c++){if((c*3+r*5)%11===0)this.img(ctx,"floor",c,r,1,1,.28);}
    // old substrate: visible but subordinate to the living settlement.
    [[3,5],[4,5],[22,8],[23,8],[8,24],[9,24],[10,24]].forEach(q=>this.img(ctx,"grate",q[0],q[1],1,1,.72));
    this.img(ctx,"terminal",25,5,1,1,.8); this.img(ctx,"server",26,5,1,2,.65); this.img(ctx,"junction",24,6,1,1,.7); this.img(ctx,"battery",2,24,1,1,.62);
    ctx.save();ctx.fillStyle="rgba(123,95,58,.48)";ctx.fillRect(0,13*60,1920,6*60);ctx.fillRect(13*60,0,6*60,1920);ctx.fillStyle="rgba(62,80,45,.5)";[[1,2],[5,3],[29,4],[2,27],[27,26],[15,29],[18,2],[30,29]].forEach(([c,r])=>{ctx.beginPath();ctx.arc(c*60+30,r*60+30,38,0,Math.PI*2);ctx.fill();});ctx.restore();
    // Human market dressing around authoritative stall coordinates.
    this.awning(ctx,4,9,4,"#77513e");this.awning(ctx,11,7,4,"#6c6240");this.awning(ctx,19,10,4,"#4f6550");this.awning(ctx,25,14,4,"#6b4d59");
    [[5,10,"crates"],[12,8,"bench"],[20,11,"barrel"],[27,15,"crates"],[7,21,"tools"],[18,23,"barrel"],[4,18,"debris"],[28,20,"lantern"],[16,6,"panel"],[24,23,"monitors"]].forEach(([c,r,k])=>this.img(ctx,k,c,r,1,1,.92));
    otherStalls.draw(ctx); stall.draw(ctx);
    npc.list.forEach(u=>this.actor(ctx,u)); worker.draw(ctx);
    npc.list.forEach(u=>{if(!u.currentSpeech)return;const p=grid.cellToPixels(u.gridColumn,u.gridRow),text=u.currentSpeech;ctx.save();ctx.font="16px Georgia";ctx.textAlign="center";const w=Math.min(430,Math.max(160,ctx.measureText(text).width+26)),x=p.x+30,y=p.y-42;ctx.fillStyle="rgba(20,18,14,.92)";ctx.fillRect(x-w/2,y-25,w,31);ctx.strokeStyle="rgba(212,175,55,.75)";ctx.strokeRect(x-w/2,y-25,w,31);ctx.fillStyle="#eee5cf";ctx.fillText(text,x,y-5,w-16);ctx.restore();});
    const pp=grid.cellToPixels(player.gridColumn,player.gridRow),pi=this.assets.player;if(pi&&pi.complete&&pi.naturalWidth){ctx.save();ctx.imageSmoothingEnabled=false;ctx.drawImage(pi,pp.x,pp.y-21,60,81);ctx.restore();}
    // Market Stall meaning: floppy icon is currency only.
    const fi=this.assets.floppy;if(fi&&fi.complete&&fi.naturalWidth){ctx.save();ctx.fillStyle="rgba(18,17,14,.82)";ctx.fillRect(12,12,170,58);ctx.drawImage(fi,20,18,46,46);ctx.font="bold 25px Georgia";ctx.fillStyle="#f0dfac";ctx.fillText(String(player.floppyBalance||0),78,51);ctx.restore();}
  }
};
