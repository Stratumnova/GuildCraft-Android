// rendererManager.js — one simulation, switchable presentations.
const RendererManager = {
  active: null,
  init() {
    const requested = new URLSearchParams(location.search).get("renderer");
    this.active = requested === "debug" ? DebugRenderer : WorldRenderer;
    this.syncButton();
  },
  toggle() {
    this.active = this.active === DebugRenderer ? WorldRenderer : DebugRenderer;
    this.syncButton();
  },
  draw(ctx) { (this.active || DebugRenderer).draw(ctx); },
  syncButton() {
    const el=document.getElementById("rendererToggle");
    if(el) el.textContent=`View: ${(this.active||DebugRenderer).id.toUpperCase()}`;
  }
};
