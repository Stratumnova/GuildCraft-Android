// specialization.js
// -----------------------------------------------------------------------------
// Handles picking a category + master path (Section 4/5 fork-and-lock),
// checking whether Master Merchant King is unlocked, and firing the
// masteryComplete drop + save when a path's final stage is finished.
// -----------------------------------------------------------------------------

const specialization = {

  // Categories the player can currently choose from. Master Merchant King
  // only appears once all five base categories are mastered (Section 4).
  getAvailableCategories() {
    const baseCategories = ["food", "blacksmith", "alchemy", "carpenter", "tannery"];
    const allBaseMastered = baseCategories.every((category) =>
      player.masteredCategories.includes(category)
    );

    const available = [...baseCategories];
    if (allBaseMastered) available.push("masterMerchantKing");
    return available;
  },

  chooseCategory(categoryKey) {
    player.chosenCategory = categoryKey;
    player.chosenPath = null; // must still pick a path next
  },

  // A path is available if: (a) its opposed partner, if any, hasn't been
  // touched yet this run (fork-and-lock), and (b) any capstone-style
  // unlockRequirement it has is satisfied (Section 4 gate).
  isPathAvailable(categoryKey, pathKey) {
    const categoryData = techTree[categoryKey];
    const pathData = categoryData.paths[pathKey];

    if (pathData.opposedWith) {
      const partnerTouched =
        player.chosenPath === pathData.opposedWith ||
        player.pathProgress[pathData.opposedWith] !== undefined;
      if (partnerTouched) return false;
    }

    if (pathData.unlockRequirement) {
      const { stageIndexThreshold, pairs } = pathData.unlockRequirement;
      const anyPairMet = pairs.some(
        ([a, b]) =>
          player.getStageIndexForPath(a) >= stageIndexThreshold &&
          player.getStageIndexForPath(b) >= stageIndexThreshold
      );
      if (!anyPairMet) return false;
    }

    return true;
  },

  getAvailablePaths(categoryKey) {
    const categoryData = techTree[categoryKey];
    return Object.keys(categoryData.paths).filter((pathKey) =>
      this.isPathAvailable(categoryKey, pathKey)
    );
  },

  choosePath(pathKey) {
    if (!this.isPathAvailable(player.chosenCategory, pathKey)) {
      EventConsole.emit("SPECIALIZATION", `Path choice blocked: ${pathKey}`, "locked - opposed pair or unmet unlock requirement", { category: player.chosenCategory, path: pathKey }, "state");
      return false;
    }
    const categoryData = techTree[player.chosenCategory];
    const pathData = categoryData.paths[pathKey];
    player.switchToPath(pathKey);

    EventConsole.emit(
      "SPECIALIZATION", `Chose ${categoryData.label} > ${pathData.label}`,
      pathData.opposedWith ? `locks out the opposed path: ${pathData.opposedWith}` : "no opposed pair",
      { category: player.chosenCategory, path: pathKey }, "decision"
    );
    return true;
  },

  // Switches to a different path within the SAME category, mid-run,
  // without a restart. Each path keeps its own progress (player.js).
  switchPath(pathKey) {
    if (!this.isPathAvailable(player.chosenCategory, pathKey)) {
      EventConsole.emit("SPECIALIZATION", `Path switch blocked: ${pathKey}`, "locked - opposed pair or unmet unlock requirement", { category: player.chosenCategory, path: pathKey }, "state");
      return false;
    }
    player.switchToPath(pathKey);
    return true;
  },

  // Called by crafting.js once craftsCompletedThisStage reaches the
  // current stage's requirement.
  async advanceStage() {
    const pathData = player.getCurrentPathData();
    const wasMasteryStage = player.isOnMasteryStage();

    if (wasMasteryStage) {
      await this.completeMastery();
      return;
    }

    player.currentStageIndex += 1;
    player.craftsCompletedThisStage = 0;

    EventConsole.emit(
      "SPECIALIZATION", `Stage advanced: ${pathData.label}`, `now on stage ${player.currentStageIndex + 1}`,
      { category: player.chosenCategory, path: player.chosenPath, newStageIndex: player.currentStageIndex }, "milestone"
    );

    await backendApi.reportDrop(saveState.currentPlayerId, "stageUp", {
      category: player.chosenCategory,
      path: player.chosenPath,
      newStageIndex: player.currentStageIndex,
    });
    await saveState.saveNow(player);
  },

  async completeMastery() {
    const categoryKey = player.chosenCategory;
    player.masteredCategories.push(categoryKey);

    await backendApi.markCategoryMastered(saveState.currentPlayerId, categoryKey);
    await backendApi.reportDrop(saveState.currentPlayerId, "masteryComplete", {
      category: categoryKey,
      path: player.chosenPath,
    });
    await saveState.saveNow(player);

    EventConsole.emit("SPECIALIZATION", `${categoryKey} MASTERED`, "player can now restart with a new category", { category: categoryKey, path: player.chosenPath }, "milestone");
  },
};
