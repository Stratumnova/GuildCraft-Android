// npcPersonality.js — BASE LAYER.
// -----------------------------------------------------------------------------
// Personality archetypes that modify how an NPC shops: how price-sensitive
// they are, whether they haggle, and whether they're loyal to one category.
// Also defines a small set of named, recurring NPCs so the map has some
// characters instead of purely anonymous customers.
//
// This is generic engine logic - it doesn't reference specific items, only
// category keys (which come from whatever content file is loaded) and the
// stall/pricing systems already in base.
// -----------------------------------------------------------------------------

const npcPersonalityTypes = {
  bargainHunter: {
    label: "Bargain Hunter",
    // Shifts their personal "ideal price" below the real sweet spot - they
    // just want it cheap, even if that means a lower accept chance overall.
    sweetSpotBiasMultiplier: 0.85,
    hagglesChance: 0.35, // see haggling note below
  },
  bigSpender: {
    label: "Big Spender",
    sweetSpotBiasMultiplier: 1.2, // tolerates - even prefers - higher prices
    hagglesChance: 0,
  },
  loyalist: {
    label: "Loyalist",
    sweetSpotBiasMultiplier: 1.0,
    hagglesChance: 0.05,
    preferredCategory: null, // set per-NPC when spawned; biases target-stall picking
  },
  impulsive: {
    label: "Impulsive Shopper",
    sweetSpotBiasMultiplier: 1.0,
    hagglesChance: 0.1,
    buyAttemptSpeedMultiplier: 1.6, // decides faster, revisits stalls more often
  },
};

// A handful of recurring named NPCs with fixed personalities, so the map
// has some characters you'll start to recognize rather than pure numbers.
// Loyalist category assignments are filled in at spawn time (npc.js) based
// on whatever categories the loaded content file actually has.
const namedNpcRoster = [
  { name: "Old Maren", personality: "bargainHunter" },
  { name: "Ser Callum", personality: "bigSpender" },
  { name: "Young Tobin", personality: "impulsive" },
  { name: "Widow Hesk", personality: "loyalist" },
];

const npcPersonality = {
  // Assigns a personality to a fresh NPC. The first few spawned NPCs get
  // the named roster (in order); anyone beyond that gets a random
  // archetype so the map doesn't run out of personality once more than
  // namedNpcRoster.length customers exist.
  assignPersonality(npcUnit, spawnIndex) {
    const archetypeKeys = Object.keys(npcPersonalityTypes);

    if (spawnIndex < namedNpcRoster.length) {
      const rosterEntry = namedNpcRoster[spawnIndex];
      npcUnit.name = rosterEntry.name;
      npcUnit.personalityKey = rosterEntry.personality;
    } else {
      npcUnit.name = null; // anonymous
      npcUnit.personalityKey = archetypeKeys[Math.floor(Math.random() * archetypeKeys.length)];
    }

    // Loyalists need an actual category to prefer - pick one at random from
    // whatever categories the loaded content file has (excludes capstones).
    if (npcUnit.personalityKey === "loyalist") {
      const categoryKeys = Object.keys(techTree).filter((k) => techTree[k].paths);
      npcUnit.preferredCategory = categoryKeys[Math.floor(Math.random() * categoryKeys.length)];
    }
  },

  getArchetype(npcUnit) {
    return npcPersonalityTypes[npcUnit.personalityKey] || npcPersonalityTypes.bigSpender;
  },

  // Applies this NPC's price bias to a base sweet spot.
  getPersonalSweetSpot(npcUnit, baseSweetSpot) {
    const archetype = this.getArchetype(npcUnit);
    return baseSweetSpot * archetype.sweetSpotBiasMultiplier;
  },

  // Haggling: if the listed price is above what this NPC would normally
  // accept, a haggler gets one chance to talk it down to their personal
  // sweet spot instead of walking away. Doesn't change the actual price
  // paid in the log - represents them successfully negotiating, so the
  // sale still records at the ORIGINAL asking price (the seller doesn't
  // lose money - the haggle just improves the NPC's odds of buying at all).
  attemptHaggleImprovedChance(npcUnit, originalChance) {
    const archetype = this.getArchetype(npcUnit);
    if (Math.random() < archetype.hagglesChance) {
      return Math.min(1, originalChance + 0.25);
    }
    return originalChance;
  },
};
