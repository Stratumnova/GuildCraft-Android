// resourcePool.js
// -----------------------------------------------------------------------------
// Generic shared-resource pool with a fair-share draw limit.
// Scar this came from: a single species could monopolize a tile's food stock
// during prototype testing. Fix: cap how much of the CURRENT stock any one
// request can take in a single tick, and require multi-consumer callers to
// scale requests down proportionally instead of first-come-first-served.
//
// No project names, no lore. Works with eventConsole.js / permanentLedger.js
// if they're loaded on the page, but doesn't require them.
// -----------------------------------------------------------------------------

const ResourcePool = {
  /**
   * Create a pool. capacity = max it can ever hold. stock = current amount.
   * drawLimit = fraction of CURRENT stock any single request may take (0-1).
   */
  create(id, { capacity, stock = capacity, drawLimit = 0.35, regenRate = 0 } = {}) {
    return { id, capacity, stock, drawLimit, regenRate };
  },

  /** Advance one tick: regenerate toward capacity. Safe to call every tick. */
  tick(pool, seasonMultiplier = 1) {
    if (pool.regenRate > 0) {
      pool.stock = Math.min(pool.capacity, pool.stock + pool.regenRate * seasonMultiplier);
    }
    return pool;
  },

  /**
   * Single-consumer draw. Hard-capped at drawLimit * current stock, no matter
   * how much is requested. Returns the amount actually granted.
   */
  request(pool, amountWanted) {
    const available = pool.stock * pool.drawLimit;
    const granted = Math.min(amountWanted, available);
    pool.stock -= granted;

    if (typeof EventConsole !== "undefined") {
      EventConsole.emit(
        "RESOURCE_POOL",
        `Granted ${granted.toFixed(2)} from ${pool.id}`,
        granted < amountWanted ? "draw-limit reached" : "request fully met",
        { poolId: pool.id, wanted: amountWanted, granted, stockAfter: pool.stock }
      );
    }
    return granted;
  },

  /**
   * Multi-consumer fair-share draw. Pass every request for this pool THIS TICK
   * as one array — this is the actual fix, not request() called in a loop.
   * If total wanted exceeds what's available, every requester gets scaled
   * down proportionally instead of draining first-come-first-served.
   * Returns an array of granted amounts, same order/length as requests.
   */
  requestFairShare(pool, amountsWanted) {
    const available = pool.stock * pool.drawLimit;
    const totalWanted = amountsWanted.reduce((a, b) => a + b, 0);

    if (totalWanted <= available || totalWanted === 0) {
      pool.stock -= totalWanted;
      return amountsWanted.slice();
    }

    const scale = available / totalWanted;
    const granted = amountsWanted.map(w => w * scale);
    pool.stock -= available;

    if (typeof EventConsole !== "undefined") {
      EventConsole.emit(
        "RESOURCE_POOL",
        `Fair-share scaled ${amountsWanted.length} requests on ${pool.id}`,
        `demand ${totalWanted.toFixed(2)} exceeded available ${available.toFixed(2)}`,
        { poolId: pool.id, scale, stockAfter: pool.stock }
      );
    }
    return granted;
  },

  deposit(pool, amount) {
    pool.stock = Math.min(pool.capacity, pool.stock + amount);
    return pool.stock;
  },
};

if (typeof module !== "undefined") module.exports = ResourcePool;
