// salesLog.js
// -----------------------------------------------------------------------------
// One shared log of every sale, across the player's stall and all 10 AI
// stalls (otherStalls.js). Powers the dev log tab and the "average price /
// how many sold" stats shown in the Storage tab.
// -----------------------------------------------------------------------------

const salesLog = {
  entries: [], // most recent first: { stallId, itemName, price, gameTimeLabel, realTimestamp }
  maxEntries: 500,

  itemStats: {}, // itemName -> { totalSold, totalRevenue }

  logSale(stallId, itemName, price) {
    const gameTimeLabel = (typeof clock !== "undefined") ? clock.getFormattedTime() : "";
    this.entries.unshift({
      stallId,
      itemName,
      price,
      gameTimeLabel,
      realTimestamp: new Date().toISOString(),
    });
    if (this.entries.length > this.maxEntries) this.entries.pop();

    if (!this.itemStats[itemName]) this.itemStats[itemName] = { totalSold: 0, totalRevenue: 0 };
    this.itemStats[itemName].totalSold += 1;
    this.itemStats[itemName].totalRevenue += price;
  },

  getStatsForItem(itemName) {
    const stats = this.itemStats[itemName];
    if (!stats) return { totalSold: 0, averagePrice: 0 };
    return {
      totalSold: stats.totalSold,
      averagePrice: Math.round(stats.totalRevenue / stats.totalSold),
    };
  },
};
