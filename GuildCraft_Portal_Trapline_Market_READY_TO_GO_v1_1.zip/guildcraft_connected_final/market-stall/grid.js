// grid.js
// -----------------------------------------------------------------------------
// Everything in Market Stall 1 is grid-clip placement (Section 1 of the
// master doc) - no free placement, no collision math. This file owns the
// grid's size, cell math, and drawing.
// -----------------------------------------------------------------------------

const grid = {
  columns: 32,
  rows: 32,
  cellSizePixels: 60, // tripled from 20 per request - everything on the map renders 3x larger

  // Converts a grid cell (e.g. column 5, row 3) into pixel coordinates
  // for drawing on the canvas.
  cellToPixels(column, row) {
    return {
      x: column * this.cellSizePixels,
      y: row * this.cellSizePixels,
    };
  },

  // Converts a raw pixel click/position into the grid cell it falls in.
  // Used for placing furniture or reading player position.
  pixelsToCell(x, y) {
    return {
      column: Math.floor(x / this.cellSizePixels),
      row: Math.floor(y / this.cellSizePixels),
    };
  },

  // Keeps a cell coordinate inside the 32x32 bounds.
  clampToGrid(column, row) {
    return {
      column: Math.max(0, Math.min(this.columns - 1, column)),
      row: Math.max(0, Math.min(this.rows - 1, row)),
    };
  },

  draw(canvasContext) {
    canvasContext.strokeStyle = "#3a4a3a";
    canvasContext.lineWidth = 1;

    for (let column = 0; column <= this.columns; column++) {
      const x = column * this.cellSizePixels;
      canvasContext.beginPath();
      canvasContext.moveTo(x, 0);
      canvasContext.lineTo(x, this.rows * this.cellSizePixels);
      canvasContext.stroke();
    }

    for (let row = 0; row <= this.rows; row++) {
      const y = row * this.cellSizePixels;
      canvasContext.beginPath();
      canvasContext.moveTo(0, y);
      canvasContext.lineTo(this.columns * this.cellSizePixels, y);
      canvasContext.stroke();
    }
  },
};
