// contractGuard.js
// -----------------------------------------------------------------------------
// The loud half of the shared contract every system's output has to follow.
// A system's log entries already share one shape by convention (system,
// event, reason, state, purpose, timestamp) — this is what actually CHECKS
// that shape instead of just hoping every system emits it correctly, and
// fails loud, not silent, when something doesn't match.
//
// Same two ideas as the Kotlin-side AddonContractGuard, independently
// implemented in each language on purpose — the CONCEPT has to match on
// both sides, not the code. Same exact failure message on both, too:
// "error in code, try again or start over." — deliberately unhelpful about
// WHERE the break is. That's the old-school-checksum cost being accepted
// on purpose, not an oversight.
// -----------------------------------------------------------------------------

const ContractGuard = {

  FAILURE_MESSAGE: "error in code, try again or start over.",

  REQUIRED_EVENT_FIELDS: ["system", "event", "purpose", "timestamp"],

  // Loud, on purpose — every EventConsole.emit() call runs through this.
  // A caller passing a malformed entry (wrong field missing, wrong type)
  // finds out immediately, not several systems downstream.
  validateEvent(entry) {
    if (!entry || typeof entry !== "object") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    for (const field of this.REQUIRED_EVENT_FIELDS) {
      if (!(field in entry) || entry[field] === undefined) {
        return { ok: false, reason: this.FAILURE_MESSAGE };
      }
    }
    if (typeof entry.system !== "string" || typeof entry.event !== "string") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    if (typeof entry.timestamp !== "number") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    return { ok: true };
  },

  // A build/manifest entry (one item from builds.json) has its own,
  // separate required shape — checked before compare.js ever tries to
  // load it into a slot.
  REQUIRED_BUILD_FIELDS: ["id", "label", "path", "notes"],

  validateBuildEntry(build) {
    if (!build || typeof build !== "object") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    for (const field of this.REQUIRED_BUILD_FIELDS) {
      if (!(field in build) || typeof build[field] !== "string" || build[field] === "") {
        return { ok: false, reason: this.FAILURE_MESSAGE };
      }
    }
    return { ok: true };
  },

  // SHA-256 via the browser's own Web Crypto API — no library needed.
  // Same algorithm family as the Kotlin side's MessageDigest use, so the
  // CONCEPT lines up even though nothing here needs to literally interop.
  async computeChecksum(text) {
    const bytes = new TextEncoder().encode(text);
    const hashBuffer = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(hashBuffer))
      .map(b => b.toString(16).padStart(2, "0"))
      .join("");
  },

  // Checksum is opt-in per build, same as the Kotlin side — only enforced
  // if the manifest entry actually declares one via a "checksum" field.
  async validateChecksum(build, actualContent) {
    if (!build.checksum) return { ok: true };
    const actual = await this.computeChecksum(actualContent);
    if (actual !== build.checksum) {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    return { ok: true };
  },

  // scrapyard/manifest.json entries have a different shape than a
  // builds.json entry (path is nullable, browserRunnable/weightClass are
  // typed, not just strings) — a separate validator, not a reuse of
  // validateBuildEntry, since the two schemas genuinely differ.
  VALID_ENTRY_TYPES: ["system", "program", "mini", "meta", "part"],

  validateScrapyardEntry(entry) {
    if (!entry || typeof entry !== "object") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    for (const field of ["id", "type", "label", "status", "notes"]) {
      if (!(field in entry) || typeof entry[field] !== "string" || entry[field] === "") {
        return { ok: false, reason: this.FAILURE_MESSAGE };
      }
    }
    if (!this.VALID_ENTRY_TYPES.includes(entry.type)) {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    if (!("path" in entry) || (entry.path !== null && typeof entry.path !== "string")) {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    if (typeof entry.browserRunnable !== "boolean") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    if (typeof entry.yardCompatible !== "boolean") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    if (typeof entry.weightClass !== "number") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    return { ok: true };
  },

  // A Part entry (standalone reusable code/asset/data, its own catalog
  // entry) has a narrower required shape than a full scrapyard entry -
  // no browserRunnable/yardCompatible/weightClass, just the same core
  // string fields plus a nullable path. Separate validator, same pattern.
  validatePartEntry(entry) {
    if (!entry || typeof entry !== "object") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    for (const field of ["id", "type", "label", "status", "notes"]) {
      if (!(field in entry) || typeof entry[field] !== "string" || entry[field] === "") {
        return { ok: false, reason: this.FAILURE_MESSAGE };
      }
    }
    if (entry.type !== "part") {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    if (!("path" in entry) || (entry.path !== null && typeof entry.path !== "string")) {
      return { ok: false, reason: this.FAILURE_MESSAGE };
    }
    return { ok: true };
  },

  // The new piece Terminal Yard needs: a loader's last-reported timestamp
  // vs. the merge cell's own tick. Past the threshold, the merge display
  // should show that feed as stale/flatlined rather than silently
  // identical to a live one. Pure comparison, no side effects — the
  // caller decides what "flatlined" looks like on screen.
  isFeedStale(loaderLastTimestamp, mergeTickTimestamp, thresholdMs = 5000) {
    if (typeof loaderLastTimestamp !== "number" || typeof mergeTickTimestamp !== "number") {
      return true; // missing/invalid timestamp is treated as stale, not live
    }
    return (mergeTickTimestamp - loaderLastTimestamp) > thresholdMs;
  },

  // Session D: the rule for whether two catalog entries (typically two
  // Finished Products) can combine automatically vs. need manual
  // integration. Two entries combine automatically ONLY if both pass
  // their own type-appropriate shape validation AND both declare the
  // same engineContractVersion. Anything else -- missing version, a
  // mismatch, or either entry failing its own validation -- means
  // manual integration work, not an automatic combine. This does not
  // check gameplay/data compatibility, only whether the shared engine
  // contract lines up -- passing this is necessary, not sufficient.
  canCombine(entryA, entryB) {
    const validatorFor = (entry) => (entry && entry.type === "part")
      ? this.validatePartEntry(entry)
      : this.validateScrapyardEntry(entry);

    const resultA = validatorFor(entryA);
    if (!resultA.ok) {
      return { ok: false, reason: "entryA failed its own shape validation" };
    }
    const resultB = validatorFor(entryB);
    if (!resultB.ok) {
      return { ok: false, reason: "entryB failed its own shape validation" };
    }
    if (typeof entryA.engineContractVersion !== "string" || entryA.engineContractVersion === "") {
      return { ok: false, reason: "entryA has no engineContractVersion" };
    }
    if (typeof entryB.engineContractVersion !== "string" || entryB.engineContractVersion === "") {
      return { ok: false, reason: "entryB has no engineContractVersion" };
    }
    if (entryA.engineContractVersion !== entryB.engineContractVersion) {
      return {
        ok: false,
        reason: `version mismatch: ${entryA.engineContractVersion} vs ${entryB.engineContractVersion} -- manual integration required`,
      };
    }
    return { ok: true, reason: "same engine contract version, both valid -- safe to combine automatically" };
  },
};
