// Compatibility shell: Market does not generate Wild resources.
const worker={list:[],spawnCost:0,spawnWorker(){EventConsole.emit("MARKET","Worker recruitment retired","Hire the stall seller through Your Stall after enough sales.",{},"state");return false},rollWildLoot(){return null},update(){},draw(){}};
