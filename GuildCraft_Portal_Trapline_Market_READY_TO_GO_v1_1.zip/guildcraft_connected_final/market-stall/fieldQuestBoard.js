const fieldQuestBoard={
 key:`fieldQuests_${saveState.currentPlayerId}`, catalogueKey:`fieldCatalogue_${saveState.currentPlayerId}`,
 species:[
  ['rabbit','Cottontail',8,5,'rabbitPelt'],['squirrel','Gray Squirrel',9,5,'squirrelPelt'],['turkey','Wild Turkey',12,7,'turkeyFeather'],
  ['deer','Deer',16,10,'deerPelt'],['beaver','Beaver',18,11,'beaverPelt'],['raccoon','Raccoon',15,9,'raccoonPelt'],
  ['fox','Red Fox',22,13,'foxPelt'],['owl','Night Owl',14,9,'owlFeather'],['boar','Wild Boar',24,15,'boarHide'],['wolf','Wolf',28,18,'wolfPelt']
 ],
 quests:[],
 build(){
  this.quests=[];
  this.species.forEach(([k,label,livePay,deadPay,proof])=>{
    this.quests.push({id:`q_${k}_live`,label:`Bring a live ${label}`,item:`live:${k}`,qty:1,reward:livePay,type:'LIVE',species:k});
    this.quests.push({id:`q_${k}_dead`,label:`Collect ${label} field proof`,item:proof,qty:1,reward:deadPay,type:'DEAD',species:k});
  });
  this.quests.push(
   {id:'q_wood',label:'Fetch field wood',item:'wood',qty:4,reward:6,type:'FETCH'},
   {id:'q_iron',label:'Collect iron ore',item:'ironOre',qty:3,reward:8,type:'FETCH'},
   {id:'q_fiber',label:'Bring plant fiber',item:'fiber',qty:4,reward:7,type:'FETCH'},
   {id:'q_herb',label:'Bring medicinal herbs',item:'medicinalHerb',qty:3,reward:10,type:'FETCH'},
   {id:'q_hardwood',label:'Bring hardwood from the outer Wild',item:'hardwood',qty:3,reward:12,type:'FETCH'},
   {id:'q_copper',label:'Collect copper ore',item:'copperOre',qty:2,reward:14,type:'FETCH'},
   {id:'q_scrap',label:'Recover legacy scrap metal',item:'scrapMetal',qty:2,reward:16,type:'FETCH'},
   {id:'q_alloy',label:'Recover old-world alloy',item:'oldAlloy',qty:1,reward:25,type:'FETCH'}
  ); return this.quests
 },
 read(){
  let s;try{s=JSON.parse(localStorage.getItem(this.key)||'{}')}catch{s={}}
  if(s.schema===4)return s;
  return {schema:4,cycle:0,done:{},history:[],legacyDone:s.done||{}};
 },
 write(s){s.schema=4;s.history=Array.isArray(s.history)?s.history.slice(-100):[];localStorage.setItem(this.key,JSON.stringify(s))},
 catalogue(){try{return JSON.parse(localStorage.getItem(this.catalogueKey)||'{"schema":2,"animals":{}}')}catch{return {schema:2,animals:{}}}},
 active(cycle){
  if(!this.quests.length)this.build();
  const live=this.quests.filter(q=>q.type==='LIVE'),dead=this.quests.filter(q=>q.type==='DEAD'),fetch=this.quests.filter(q=>q.type==='FETCH');
  const pick=(arr,n,step=1,offset=0)=>Array.from({length:n},(_,i)=>arr[(cycle*step+offset+i*step)%arr.length]);
  return [pick(live,1,3,0)[0],pick(dead,1,7,2)[0],...pick(fetch,3,3,cycle%fetch.length)];
 },
 instanceKey(q,cycle){return `${cycle}:${q.id}`},
 complete(id){
  if(!this.quests.length)this.build();const s=this.read(),q=this.active(s.cycle).find(x=>x.id===id),key=q&&this.instanceKey(q,s.cycle);
  if(!q||s.done[key]||(player.inventory[q.item]||0)<q.qty)return false;
  player.inventory[q.item]-=q.qty;s.done[key]={at:new Date().toISOString(),type:q.type,questId:q.id,reward:q.reward};s.history.push({cycle:s.cycle,questId:q.id,at:s.done[key].at,reward:q.reward});this.write(s);
  player.floppyBalance=(player.floppyBalance||0)+q.reward;syncMarketPortal();EventConsole.emit('FIELD REQUEST',q.label,`${q.reward} floppies paid`,{questId:id,cycle:s.cycle},'milestone');this.render();return true
 },
 nextCycle(){const s=this.read(),active=this.active(s.cycle);if(!active.every(q=>s.done[this.instanceKey(q,s.cycle)]))return false;s.cycle++;this.write(s);EventConsole.emit('FIELD REQUEST','New request sheet posted',`Iris posted cycle ${s.cycle+1}.`,{cycle:s.cycle},'state');this.render();return true},
 render(){
  if(!this.quests.length)this.build();const el=document.getElementById('fieldQuestPanel');if(!el)return;const s=this.read(),c=this.catalogue(),active=this.active(s.cycle),done=active.filter(q=>s.done[this.instanceKey(q,s.cycle)]).length,allDone=done===active.length;
  el.innerHTML=`<h3>Iris Vale — Field Requests</h3><p><small>“Bring me proof, not stories. Sometimes I need it breathing.”</small></p><p><strong>Request sheet ${s.cycle+1} · ${done}/${active.length}</strong></p>`+
  active.map(q=>{const finished=!!s.done[this.instanceKey(q,s.cycle)];return `<p>${finished?'✓ ':''}<strong>[${q.type}] ${q.label}</strong> — ${q.reward} floppies<br><small>${q.item}: ${player.inventory[q.item]||0}/${q.qty}</small><br><button ${finished||(player.inventory[q.item]||0)<q.qty?'disabled':''} onclick="fieldQuestBoard.complete('${q.id}')">Turn in</button></p>`}).join('')+
  (allDone?`<button onclick="fieldQuestBoard.nextCycle()">Post next request sheet</button>`:'')+
  `<h4>Field Catalogue</h4><p><small>Ordinary species only. Seen / dead / live are independent records.</small></p>`+this.species.map(([k,label])=>{const a=c.animals[k]||{},complete=!!(a.seen&&a.dead&&a.live);return `<div class="catalogueRow">${complete?'★':'·'} <strong>${label}</strong>: Seen ${a.seen?'✓':'—'} · Dead ${a.dead?'✓':'—'} · Live ${a.live?'✓':'—'}</div>`}).join('')
 }
};
fieldQuestBoard.build();
