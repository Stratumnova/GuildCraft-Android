extends CanvasLayer
## HUD — final locked HUD contents:
## "P for menu" hint, Player HP (X/Y), Bytecoins (X/25), Death Coins
## (plain count-up), reverse tracker (*/* unlabeled), live enemy count
## (+/- plain tracker). No Loopcoin presence anywhere (backend-only).

@onready var hp_label: Label = $Panel/HPLabel
@onready var bytecoin_label: Label = $Panel/BytecoinLabel
@onready var deathcoin_label: Label = $Panel/DeathCoinLabel
@onready var reverse_label: Label = $Panel/ReverseLabel
@onready var enemy_count_label: Label = $Panel/EnemyCountLabel
@onready var pause_hint_label: Label = $Panel/PauseHintLabel

var _player_ref: Node = null

func _ready() -> void:
	pause_hint_label.text = "P for menu"
	BytecoinManager.coin_collected.connect(_refresh_bytecoins)
	DeathCoinManager.token_added.connect(_refresh_deathcoins)
	_refresh_bytecoins(BytecoinManager.coins)
	_refresh_deathcoins(DeathCoinManager.tokens, 0)
	_refresh_reverse()
	_refresh_enemy_count()

func bind_player(player: Node) -> void:
	_player_ref = player
	if player.has_signal("hp_changed"):
		player.hp_changed.connect(_refresh_hp)
		_refresh_hp(player.current_hp, player.max_hp)

func _refresh_hp(current: int, max_hp: int) -> void:
	hp_label.text = "%d/%d" % [current, max_hp]

func _refresh_bytecoins(total: int) -> void:
	bytecoin_label.text = "Bytecoins: %d/%d" % [total, BytecoinManager.MAX_COINS]

func _refresh_deathcoins(total: int, _added: int) -> void:
	deathcoin_label.text = "Death Coins: %d" % total
	_refresh_reverse()

func _refresh_reverse() -> void:
	reverse_label.text = "*%d/+%d*" % [GameState.reverse_fails, GameState.reverse_wins]

func _refresh_enemy_count() -> void:
	var count := get_tree().get_nodes_in_group("enemy").size()
	enemy_count_label.text = "Enemies: %d" % count

func _process(_delta: float) -> void:
	_refresh_enemy_count()
