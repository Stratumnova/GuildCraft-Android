extends CharacterBody2D
## Enemy — Byte My Chip creep. Two skins (player-reskin tint, brute-reskin
## tint), three tiers by VALUES only — skin/color has zero mechanical
## meaning. Patrol A<->B, short-memory chase, return to patrol.

signal died

enum Tier { LOW, MID, HIGH }

@export var tier: Tier = Tier.LOW
@export var patrol_point_a: Vector2
@export var patrol_point_b: Vector2
@export var detect_radius: float = 150.0
@export var chase_timeout: float = 3.0   # short-memory chase duration

# Base HP per tier, per design: low 1-2, mid 2-4, high 5-8.
# These are placeholders within each stated range — tune live.
const TIER_BASE_HP := {
	Tier.LOW: 2,
	Tier.MID: 3,
	Tier.HIGH: 6,
}
const TIER_BASE_SPEED := {
	Tier.LOW: 80.0,
	Tier.MID: 100.0,
	Tier.HIGH: 70.0,   # high tier = tougher, not necessarily faster
}

var max_hp: int = 1
var current_hp: int = 1

var _patrol_target: Vector2
var _chase_timer: float = 0.0
var _player_ref: Node2D = null

@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
	add_to_group("enemy")
	_patrol_target = patrol_point_b
	BytecoinManager.milestone_reached.connect(_on_bytecoin_milestone)
	_recompute_hp()
	current_hp = max_hp

func _recompute_hp() -> void:
	max_hp = TIER_BASE_HP[tier] + BytecoinManager.get_enemy_hp_bonus()

func _on_bytecoin_milestone(_m: int) -> void:
	# "+1 HP per 5 coins, applies retroactively to all enemies on screen."
	var old_max := max_hp
	_recompute_hp()
	current_hp += (max_hp - old_max)

func _physics_process(delta: float) -> void:
	delta *= GameState.game_speed
	var adjustments := LoopcoinMemory.get_creep_adjustment_table()
	var speed: float = TIER_BASE_SPEED[tier] * float(adjustments.get("speed_multiplier", 1.0))

	if _player_ref and is_instance_valid(_player_ref):
		var dist := global_position.distance_to(_player_ref.global_position)
		if dist <= detect_radius or _chase_timer > 0.0:
			_chase_timer = chase_timeout
			var dir := (_player_ref.global_position - global_position).normalized()
			velocity.x = dir.x * speed * float(adjustments.get("aggression_multiplier", 1.0))
			_chase_timer -= delta
			move_and_slide()
			return

	# Patrol loop
	var dir_to_target := sign(_patrol_target.x - global_position.x)
	velocity.x = dir_to_target * speed
	move_and_slide()
	if abs(global_position.x - _patrol_target.x) < 8.0:
		_patrol_target = patrol_point_a if _patrol_target == patrol_point_b else patrol_point_b

func _on_detect_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		_player_ref = body

func take_damage(amount: int) -> void:
	current_hp -= amount
	sprite.modulate = Color(1, 1, 1) * 2.0   # flash, no HP bar per design
	if current_hp <= 0:
		died.emit()
		queue_free()

func _on_body_entered_player(body: Node2D) -> void:
	if body.is_in_group("player") and body.has_method("take_damage"):
		body.take_damage(1)
