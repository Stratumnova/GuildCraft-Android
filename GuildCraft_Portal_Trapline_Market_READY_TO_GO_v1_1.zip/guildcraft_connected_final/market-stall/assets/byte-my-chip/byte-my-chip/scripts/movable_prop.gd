extends RigidBody2D
## MovableProp — pushed by the player (Move Core) onto a SelectBlock to
## activate a moving platform, granting access to an otherwise unreachable
## ledge. Simple physics push, reused pattern from Emergent Systems' boulder.

func nudge(direction: Vector2, force: float = 300.0) -> void:
	apply_central_impulse(direction.normalized() * force)
