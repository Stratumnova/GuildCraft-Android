extends Node
## LoopcoinMemory ("Loopcoin") — the game's actual memory-system test subject.
## Tracks raw player input patterns, converts them into simple weighted
## values, and exposes read-only flags/multipliers for creep AI to query.
##
## Scope, as locked in design: persists across the WHOLE session (not
## per-level, not per-death) using a rolling 3-death window so old behavior
## decays out naturally. No HUD presence — purely backend.
##
## "AI" here means algorithmic pattern-conversion in-engine, not an external
## trained model — there is no ML backend in this browser export.

signal profile_updated

const ROLLING_DEATHS: int = 3

## --- Raw counters for the CURRENT death-window slot ---
class DeathSlot:
	var ranged_uses: int = 0
	var melee_uses: int = 0
	var jumps: int = 0
	var jump_interval_samples: Array[float] = []   # seconds between jumps
	var last_jump_time: float = 0.0

var _slots: Array[DeathSlot] = []   # oldest first, max length ROLLING_DEATHS
var _current: DeathSlot = DeathSlot.new()

## --- Converted, creep-facing values ---
## Everything a creep needs is exposed here as simple flags/multipliers.
## Anything not yet designed is left inert at null/0 per instruction.
var profile := {
	"ranged_bias": 0.0,        # -1.0 (melee-heavy) .. 1.0 (ranged-heavy)
	"favors_ranged": false,
	"favors_melee": false,
	"jump_rhythm": "unknown",  # "rhythmic" | "erratic" | "unknown"
	"avg_jump_interval": 0.0,

	# --- Undiscussed mechanics: left inert until designed ---
	"creep_ranged_counter_unlock": null,   # planned: creep gain a ranged
	                                       # attack if player over-uses ranged
	"movement_hug_pattern": null,          # planned: top-hug / rush / backtrack
	"reserved_slot_1": 0,
	"reserved_slot_2": 0,
}

func _ready() -> void:
	pass

## --- Input tracking hooks (call these from player.gd) ---

func record_ranged_use() -> void:
	_current.ranged_uses += 1
	_recompute()

func record_melee_use() -> void:
	_current.melee_uses += 1
	_recompute()

func record_jump(time_now: float) -> void:
	_current.jumps += 1
	if _current.last_jump_time > 0.0:
		_current.jump_interval_samples.append(time_now - _current.last_jump_time)
	_current.last_jump_time = time_now
	_recompute()

## --- Called on player death: closes out the current slot, rolls window ---
func on_player_death() -> void:
	_slots.append(_current)
	while _slots.size() > ROLLING_DEATHS:
		_slots.pop_front()
	_current = DeathSlot.new()
	_recompute()

func _recompute() -> void:
	var total_ranged := _current.ranged_uses
	var total_melee := _current.melee_uses
	var total_jumps := _current.jumps
	var interval_samples: Array[float] = _current.jump_interval_samples.duplicate()

	for slot in _slots:
		total_ranged += slot.ranged_uses
		total_melee += slot.melee_uses
		total_jumps += slot.jumps
		interval_samples.append_array(slot.jump_interval_samples)

	# Ranged/melee bias: -1 fully melee, +1 fully ranged, 0 = even/no data
	var total_attacks := total_ranged + total_melee
	if total_attacks > 0:
		profile["ranged_bias"] = float(total_ranged - total_melee) / float(total_attacks)
	else:
		profile["ranged_bias"] = 0.0

	profile["favors_ranged"] = profile["ranged_bias"] > 0.35
	profile["favors_melee"] = profile["ranged_bias"] < -0.35

	# Jump rhythm: low variance in intervals = "rhythmic", high = "erratic"
	if interval_samples.size() >= 3:
		var avg := 0.0
		for v in interval_samples:
			avg += v
		avg /= interval_samples.size()
		var variance := 0.0
		for v in interval_samples:
			variance += (v - avg) * (v - avg)
		variance /= interval_samples.size()
		profile["avg_jump_interval"] = avg
		# Threshold is a placeholder — tune live per README notes.
		profile["jump_rhythm"] = "rhythmic" if variance < 0.5 else "erratic"
	else:
		profile["jump_rhythm"] = "unknown"
		profile["avg_jump_interval"] = 0.0

	profile_updated.emit()

## --- Table creep AI reads from. Tunable per design instruction: build the
## table so each behavior can be independently adjusted; leave anything not
## yet designed at null/0 (see creep_ranged_counter_unlock above). ---
func get_creep_adjustment_table() -> Dictionary:
	return {
		"speed_multiplier": _speed_multiplier(),
		"aggression_multiplier": _aggression_multiplier(),
		"grants_ranged_counter": profile["creep_ranged_counter_unlock"],  # null = inert
	}

func _speed_multiplier() -> float:
	# Placeholder curve: erratic jumpers make creep patrol/chase slightly
	# faster (harder to predict-dodge). Tune live.
	if profile["jump_rhythm"] == "erratic":
		return 1.15
	return 1.0

func _aggression_multiplier() -> float:
	# Placeholder curve: heavy ranged reliance makes creep close distance
	# faster (push melee range before player can kite). Tune live.
	if profile["favors_ranged"]:
		return 1.2
	return 1.0

func reset_all() -> void:
	_slots.clear()
	_current = DeathSlot.new()
	_recompute()
