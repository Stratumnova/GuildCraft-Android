extends CharacterBody2D
## Player — Byte My Chip side-scroller controller.
## Controls: WASD/Arrows move, Space/Right-click jump, Left-click attack
## (mouse also sets aim/facing direction), 1-5/Numpad1-5 hotbar equip.

signal died
signal hp_changed(current: int, max_hp: int)

# --- Movement (placeholder values, tune live per README) ---
@export var move_speed: float = 220.0
@export var jump_velocity: float = -420.0
@export var double_jump_velocity: float = -360.0
@export var max_double_jumps: int = 1   # "a couple times" -> start at 1, tune live

var _double_jumps_left: int = 0
var _was_on_floor: bool = true

# --- HP ---
var current_hp: int = 1
var max_hp: int = 1
var _dead: bool = false
var _invulnerable_time: float = 0.0
const INVULNERABLE_DURATION: float = 0.7   # reused from Emergent Systems i-frame value

# --- Hotbar (5 powers, drag-to-reorder happens in the pause menu UI) ---
var hotbar: Array[String] = ["fire_core", "water_core", "melee_burst", "move_core", "fade_core"]
var equipped_index: int = 0

# --- Power cooldowns (per-slot power bars, prevents spam) ---
var _cooldowns: Dictionary = {}

# --- Visuals ---
# Sprite2D is kept only as a fallback/reference node — it stays hidden once
# the three AnimatedSprite2D states are driving visuals. The three nodes
# below match the scene as actually built: a real walk-right animation, a
# real walk-BACKWARDS animation for left (not a mirrored flip), and a
# spinning idle animation.
@onready var sprite: Sprite2D = $Sprite2D
@onready var anim_walk_right: AnimatedSprite2D = $player_walk_right
@onready var anim_walk_left: AnimatedSprite2D = $player_walk_left
@onready var anim_idle: AnimatedSprite2D = $player_idel

var _active_anim: AnimatedSprite2D = null   # tracks whichever of the three is currently shown

func _ready() -> void:
	add_to_group("player")
	max_hp = BytecoinManager.get_player_max_hp()
	current_hp = max_hp
	BytecoinManager.coin_collected.connect(_on_coin_collected)
	hp_changed.emit(current_hp, max_hp)
	sprite.visible = false
	_update_animation(0.0)

func _physics_process(delta: float) -> void:
	if _dead:
		return

	delta *= GameState.game_speed

	# Gravity
	if not is_on_floor():
		velocity.y += get_gravity_y() * delta
	else:
		_double_jumps_left = max_double_jumps

	# Horizontal movement
	var dir := Input.get_axis("move_left", "move_right")
	velocity.x = dir * move_speed

	_update_animation(dir)

	# Jump — single resets on floor contact, double jump has limited charges
	if Input.is_action_just_pressed("jump"):
		if is_on_floor():
			velocity.y = jump_velocity
			LoopcoinMemory.record_jump(Time.get_ticks_msec() / 1000.0)
		elif _double_jumps_left > 0:
			velocity.y = double_jump_velocity
			_double_jumps_left -= 1
			LoopcoinMemory.record_jump(Time.get_ticks_msec() / 1000.0)

	move_and_slide()

	# Fall death — below the level's death plane
	if global_position.y > 2000.0:  # placeholder death-plane Y, set per level
		die()

	# Invulnerability window countdown — flickers whichever of the three
	# animation nodes is currently active, not the (hidden) static Sprite2D.
	if _invulnerable_time > 0.0:
		_invulnerable_time -= delta
		if _active_anim:
			_active_anim.visible = int(Time.get_ticks_msec() / 80) % 2 == 0
	else:
		if _active_anim:
			_active_anim.visible = true

	# Cooldown countdown
	for key in _cooldowns.keys():
		_cooldowns[key] = max(0.0, _cooldowns[key] - delta)

	if Input.is_action_just_pressed("attack"):
		use_equipped_power()

	for i in range(5):
		if Input.is_action_just_pressed("hotbar_%d" % (i + 1)):
			equip_slot(i)

## Shows exactly one of the three AnimatedSprite2D states based on movement
## direction, and remembers which one is active so the invulnerability
## flicker and the death flash know which node to affect.
func _update_animation(move_dir: float) -> void:
	anim_walk_right.visible = false
	anim_walk_left.visible = false
	anim_idle.visible = false

	if move_dir > 0.0:
		_active_anim = anim_walk_right
	elif move_dir < 0.0:
		_active_anim = anim_walk_left
	else:
		_active_anim = anim_idle

	_active_anim.visible = true
	if not _active_anim.is_playing():
		_active_anim.play("default")

func get_gravity_y() -> float:
	return ProjectSettings.get_setting("physics/2d/default_gravity", 980.0)

func equip_slot(index: int) -> void:
	if index < 0 or index >= hotbar.size():
		return
	equipped_index = index

func get_equipped_power_id() -> String:
	if equipped_index < 0 or equipped_index >= hotbar.size():
		return ""
	return hotbar[equipped_index]

func use_equipped_power() -> void:
	var power_id := get_equipped_power_id()
	if power_id == "":
		return
	if _cooldowns.get(power_id, 0.0) > 0.0:
		return   # still recharging — prevents spam/auto-clicker cheese

	var power := PowerDatabase.get_power(power_id)
	if power.is_empty():
		return

	_cooldowns[power_id] = power.get("cooldown", 1.0)

	match power.get("type", ""):
		"ranged":
			LoopcoinMemory.record_ranged_use()
			_fire_projectile(power)
		"melee":
			LoopcoinMemory.record_melee_use()
			_do_melee(power)
		"utility":
			_do_utility(power_id, power)

func _fire_projectile(power: Dictionary) -> void:
	# Aim direction from mouse position, per design ("mouse should track
	# where the player faces and attacks/shoots").
	var aim_dir: Vector2 = (get_global_mouse_position() - global_position).normalized()
	# Actual Projectile scene instancing happens here once Projectile.tscn
	# exists in this project (see README — reuse Emergent Systems' base).
	# Placeholder: emit a signal a level/attack manager can hook.
	print("Fire %s toward %s" % [power.get("display_name", "?"), aim_dir])

func _do_melee(power: Dictionary) -> void:
	print("Melee swing: %s" % power.get("display_name", "?"))
	# Simple overlap check against nearby enemies within power.range —
	# implement via an Area2D child (MeleeHitbox) once scene is built.

func _do_utility(power_id: String, power: Dictionary) -> void:
	match power_id:
		"move_core":
			print("Move Core used — push nearby movable_prop toward select block.")
		"fade_core":
			print("Fade Core used — nearest tagged hazard blocks passable for %.1fs" % power.get("passable_duration", 6.0))

func _on_coin_collected(_total: int) -> void:
	max_hp = BytecoinManager.get_player_max_hp()
	current_hp = min(current_hp + 1, max_hp) if max_hp > current_hp else current_hp
	hp_changed.emit(current_hp, max_hp)

func take_damage(amount: int) -> void:
	if _dead or _invulnerable_time > 0.0:
		return
	current_hp -= amount
	_invulnerable_time = INVULNERABLE_DURATION
	hp_changed.emit(current_hp, max_hp)
	if current_hp <= 0:
		die()

func die() -> void:
	if _dead:
		return
	_dead = true
	if _active_anim:
		_active_anim.modulate = Color(1, 0, 0)  # flash red/black, stays (no revert)
	LoopcoinMemory.on_player_death()
	DeathCoinManager.register_death()
	died.emit()
	await get_tree().create_timer(2.5).timeout
	GameState.restart_current_level()
	# Scene reload handled by LevelManager equivalent — see README.
