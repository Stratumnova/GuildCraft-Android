extends Node
## BytecoinManager — the visible collectible currency (floppy disk coins).
## Resets every death/level-restart. Drives player HP scaling AND the
## enemy HP tier milestone bumps. Deposited at the end-level terminal.

signal coin_collected(total: int)
signal milestone_reached(milestone: int)   # fires at 5, 10, 15, 20, 25
signal level_reset

const MAX_COINS: int = 25
const MILESTONES: Array[int] = [5, 10, 15, 20, 25]

var coins: int = 0

## --- Player HP curve modes ---
## normal:          +1 HP per 5 coins  -> cap 6  (1 base + 5 milestones)
## baby_steps:       +1 HP per 1 coin  -> cap 26 (1 base + 25 coins)
## fingers_crossed:  +2 HP per 5 coins -> cap 11 (1 base + 5 milestones x2)
var hp_mode: String = "normal"

func _ready() -> void:
	pass

func collect_coin() -> void:
	if coins >= MAX_COINS:
		return
	coins += 1
	coin_collected.emit(coins)
	if coins in MILESTONES:
		milestone_reached.emit(coins)

func get_player_max_hp() -> int:
	match hp_mode:
		"baby_steps":
			return 1 + coins
		"fingers_crossed":
			return 1 + (_milestones_passed() * 2)
		_: # "normal"
			return 1 + _milestones_passed()

func get_enemy_hp_bonus() -> int:
	# Every enemy on the map gets +1 HP per Bytecoin milestone (5/10/15/20/25),
	# applied retroactively per the design (all enemies, not just new spawns).
	return _milestones_passed()

func _milestones_passed() -> int:
	var count := 0
	for m in MILESTONES:
		if coins >= m:
			count += 1
	return count

func is_full() -> bool:
	return coins >= MAX_COINS

func reset_level() -> void:
	coins = 0
	level_reset.emit()
