extends Area2D
## SelectBlock — activates a linked moving platform when a MovableProp rests
## on it. Pairs with movable_prop.gd for the Move Core power puzzle.

@export var linked_platform_path: NodePath
var _linked_platform: Node = null
var _activated: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	if linked_platform_path != NodePath(""):
		_linked_platform = get_node(linked_platform_path)

func _on_body_entered(body: Node2D) -> void:
	if _activated:
		return
	if body.is_in_group("movable_prop"):
		_activated = true
		if _linked_platform and _linked_platform.has_method("activate"):
			_linked_platform.activate()
