extends StaticBody2D
## HazardBlock — tagged block usable with Fade Core. When activated, becomes
## passable (collision disabled) for `passable_duration` seconds, then
## reverts. Whatever is beneath (platform or death-plane) is a level-design
## choice, not this script's concern.

@export var passable_duration: float = 6.0   # matches PowerDatabase fade_core value
var _active: bool = false

@onready var collision: CollisionShape2D = $CollisionShape2D
@onready var sprite: Sprite2D = $Sprite2D

func activate() -> void:
	if _active:
		return
	_active = true
	collision.disabled = true
	sprite.modulate.a = 0.4
	await get_tree().create_timer(passable_duration).timeout
	collision.disabled = false
	sprite.modulate.a = 1.0
	_active = false
