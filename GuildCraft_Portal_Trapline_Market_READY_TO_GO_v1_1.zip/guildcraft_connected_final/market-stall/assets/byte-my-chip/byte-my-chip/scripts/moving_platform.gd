extends AnimatableBody2D
## MovingPlatform — travels between point_a and point_b once activated by a
## linked SelectBlock. Some instances should be set `stays_active = true`
## per design ("some will just stay active"); others revert after
## `active_duration` seconds (level-authored timed mechanisms).

@export var point_a: Vector2
@export var point_b: Vector2
@export var travel_speed: float = 60.0
@export var stays_active: bool = true
@export var active_duration: float = 8.0   # only used if stays_active = false

var _activated: bool = false
var _target: Vector2

func activate() -> void:
	if _activated:
		return
	_activated = true
	_target = point_b
	if not stays_active:
		await get_tree().create_timer(active_duration).timeout
		_activated = false
		_target = point_a

func _physics_process(delta: float) -> void:
	if not _activated:
		return
	delta *= GameState.game_speed
	global_position = global_position.move_toward(_target, travel_speed * delta)
	if global_position.distance_to(_target) < 2.0:
		_target = point_a if _target == point_b else point_b
