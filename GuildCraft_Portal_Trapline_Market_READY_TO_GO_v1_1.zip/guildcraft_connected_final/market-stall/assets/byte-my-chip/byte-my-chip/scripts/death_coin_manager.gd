extends Node
## DeathCoinManager — "Death Coins." One token is banked every time the
## player dies WITHIN the current level attempt. Each token = +5 creep at a
## pre-mapped location, weighted light-early -> heavy-late -> choke-at-end.
## Persists across deaths but resets fully once the level is actually
## cleared (deposit terminal). Also drives the reverse-level unlock.
##
## NOTE: this fully replaces the original Emergent Systems "StaticCoinManager"
## secret-unlock role — there is deliberately no separate banked-forever coin.

signal token_added(total_tokens: int, creep_added: int)
signal reverse_level_triggered(tokens_spent: int)
signal level_reset

const CREEP_PER_TOKEN: int = 5
## Provisional cap — intended to be re-tuned once live creep-count testing
## (see README "Tuning Notes") establishes a real performance ceiling.
const CREEP_CAP: int = 125
const REVERSE_TRIGGER_TOKENS: int = 25

var tokens: int = 0
var total_creep_spawned: int = 0

func register_death() -> void:
	if total_creep_spawned >= CREEP_CAP:
		tokens += 1
		return # cap reached, token still counts toward reverse trigger, no more creep added
	tokens += 1
	var to_add: int = min(CREEP_PER_TOKEN, CREEP_CAP - total_creep_spawned)
	total_creep_spawned += to_add
	token_added.emit(tokens, to_add)

## Call this from the deposit terminal once Bytecoins hit 25.
## Consumes ALL currently banked tokens if 25+ are held (prevents farming
## past the threshold for a permanently harder reverse level).
func try_trigger_reverse() -> bool:
	if tokens < REVERSE_TRIGGER_TOKENS:
		return false
	var spent := tokens
	tokens = 0
	reverse_level_triggered.emit(spent)
	return true

func get_spawn_curve_position(section_fraction: float) -> int:
	# section_fraction: 0.0 (level start) -> 1.0 (level end)
	# Returns a weight multiplier for how many of the banked creep-tokens'
	# spawns should land in this section. Pre-mapped sections should call
	# this per-section and distribute total_creep_spawned proportionally.
	if section_fraction < 0.5:
		return 1   # light drip, start -> midpoint
	elif section_fraction < 0.75:
		return 2   # ramping up
	elif section_fraction < 0.98:
		return 4   # heavy bulk, 3/4 -> near end
	else:
		return 6   # choke section, final ~2%

func reset_level() -> void:
	tokens = 0
	total_creep_spawned = 0
	level_reset.emit()
