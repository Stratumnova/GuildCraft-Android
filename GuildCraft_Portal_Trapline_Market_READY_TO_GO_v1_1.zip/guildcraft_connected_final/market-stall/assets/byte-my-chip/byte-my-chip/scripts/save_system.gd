extends Node
## SaveSystem — browser-persistent save/continue via Godot's user:// path,
## which maps to browser storage (IndexedDB) automatically on HTML5 export.
## No custom JS needed.
##
## Persisted: current level, Death Coin tokens for that level, Bytecoin HP
## mode selection, lifetime reverse W/L. NOT persisted: Bytecoins (they
## reset every life anyway) — continuing always resumes at the START of
## the saved level, not mid-run.

const SAVE_PATH := "user://byte_my_chip_save.json"

func save_game() -> void:
	var data := {
		"current_level": GameState.current_level,
		"death_coin_tokens": DeathCoinManager.tokens,
		"hp_mode": BytecoinManager.hp_mode,
		"reverse_fails": GameState.reverse_fails,
		"reverse_wins": GameState.reverse_wins,
		"difficulty": GameState.difficulty,
	}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file:
		return false
	var text := file.get_as_text()
	file.close()
	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		return false

	GameState.current_level = parsed.get("current_level", 1)
	DeathCoinManager.tokens = parsed.get("death_coin_tokens", 0)
	BytecoinManager.hp_mode = parsed.get("hp_mode", "normal")
	GameState.reverse_fails = parsed.get("reverse_fails", 0)
	GameState.reverse_wins = parsed.get("reverse_wins", 0)
	GameState.difficulty = parsed.get("difficulty", "normal")

	# Continuing always resumes at the START of the level, per design.
	BytecoinManager.reset_level()
	return true

func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)

func delete_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
