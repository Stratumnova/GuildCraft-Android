extends Node
## PowerDatabase — registry of the 5 Byte My Chip powers.
## Reused pattern from Emergent Systems' PowerDatabase autoload.

const POWERS := {
	"fire_core": {
		"display_name": "Fire Core",
		"type": "ranged",
		"icon": "res://assets/icons/embercore.png",
		"fx": "res://assets/fx/fireball.png",
		"range": 400.0,          # far
		"projectile_speed": 220.0, # slow
		"cooldown": 1.2,         # power-bar recharge seconds — placeholder
		"damage": 1,
	},
	"water_core": {
		"display_name": "Water Core",
		"type": "ranged",
		"icon": "res://assets/icons/tidecore.png",
		"fx": "res://assets/fx/water_beam.png",
		"range": 180.0,          # short
		"projectile_speed": 480.0, # fast
		"cooldown": 0.8,         # placeholder
		"damage": 1,
	},
	"melee_burst": {
		"display_name": "Melee Burst",
		"type": "melee",
		"icon": "res://assets/icons/concussionburst.png",
		"fx": "res://assets/fx/concussion_burst.png",
		"range": 48.0,
		"cooldown": 0.6,         # placeholder
		"damage": 1,
	},
	"move_core": {
		"display_name": "Move Core",
		"type": "utility",
		"icon": "res://assets/icons/anchorcore.png",
		"description": "Pushes the movable prop onto its select block to activate a moving platform.",
		"cooldown": 0.0,
	},
	"fade_core": {
		"display_name": "Fade Core",
		"type": "utility",
		"icon": "res://assets/icons/voidstep.png",
		"description": "Marks a tagged hazard block passable for 6 seconds, then it drops.",
		"passable_duration": 6.0,  # placeholder, "to start" per design
		"cooldown": 0.0,
	},
}

func get_power(power_id: String) -> Dictionary:
	return POWERS.get(power_id, {})
