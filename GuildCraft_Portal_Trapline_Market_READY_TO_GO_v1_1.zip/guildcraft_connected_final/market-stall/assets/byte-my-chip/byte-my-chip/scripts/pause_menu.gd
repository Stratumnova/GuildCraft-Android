extends CanvasLayer
## PauseMenu — opened with P. Scope locked: sound toggle (placeholder),
## music toggle (placeholder), full reset (wipes everything to 0), hotbar
## drag-to-reorder, game speed (6 settings), difficulty change (triggers
## full reset when changed).

signal closed

@onready var speed_option: OptionButton = $Panel/SpeedOption if has_node("Panel/SpeedOption") else null
@onready var difficulty_option: OptionButton = $Panel/DifficultyOption if has_node("Panel/DifficultyOption") else null

func _ready() -> void:
	visible = false
	if speed_option:
		speed_option.clear()
		for s in GameState.GAME_SPEEDS:
			speed_option.add_item("%sx" % str(s))
		speed_option.select(GameState.GAME_SPEEDS.find(GameState.game_speed))
		speed_option.item_selected.connect(_on_speed_selected)
	if difficulty_option:
		difficulty_option.clear()
		for d in ["easy", "normal", "hard"]:
			difficulty_option.add_item(d)
		difficulty_option.item_selected.connect(_on_difficulty_selected)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_menu"):
		toggle()

func toggle() -> void:
	visible = not visible
	get_tree().paused = visible

func _on_speed_selected(index: int) -> void:
	GameState.game_speed = GameState.GAME_SPEEDS[index]

func _on_difficulty_selected(index: int) -> void:
	var options := ["easy", "normal", "hard"]
	GameState.difficulty = options[index]
	GameState.full_reset()   # "reset the game to 0 when changed" per design

func _on_full_reset_pressed() -> void:
	GameState.full_reset()

func _on_close_pressed() -> void:
	visible = false
	get_tree().paused = false
	closed.emit()

## Hotbar drag-to-reorder: expects a child Control with 5 draggable slot
## nodes bound to player.hotbar. Left as a UI-layer task once Player.tscn
## and PauseMenu.tscn are built in-editor (see README).
func apply_hotbar_order(new_order: Array[String], player: Node) -> void:
	player.hotbar = new_order
