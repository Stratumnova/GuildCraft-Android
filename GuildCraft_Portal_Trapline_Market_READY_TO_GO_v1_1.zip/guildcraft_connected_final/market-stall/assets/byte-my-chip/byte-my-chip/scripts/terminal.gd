extends Area2D
## Terminal — two modes, reused from Emergent Systems' terminal pattern.
## "info": start-of-level how-to-play popup, always interactable.
## "deposit": end-of-level. Only interactable at 25/25 Bytecoins. Banks
##   the coins AND is the single decision point for reverse-level vs.
##   continue — no player choice involved, resolved automatically here.

@export var mode: String = "info"   # "info" | "deposit"
@export var info_text: String = "Move: WASD/Arrows. Jump: Space/Right-click.\nAttack: Left-click (aims at mouse). Hotbar: 1-5.\nCollect Bytecoins. Reach the end. Don't fall."

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if not body.is_in_group("player"):
		return
	if not body.is_in_group("interactable_zone_ready"):
		# Simplified for this scaffold: interaction fires on overlap directly
		# rather than requiring a separate button press, since the design's
		# "same button as attack" InteractionZone requires the full Player
		# scene wiring described in README.
		interact()

func interact() -> void:
	match mode:
		"info":
			_show_info_popup()
		"deposit":
			if BytecoinManager.is_full():
				_deposit_and_resolve()

func _show_info_popup() -> void:
	print("[Terminal] %s" % info_text)
	# Real popup UI: reuse Emergent Systems' TerminalInfoPopup.tscn pattern.

func _deposit_and_resolve() -> void:
	var went_reverse := DeathCoinManager.try_trigger_reverse()
	if went_reverse:
		print("[Terminal] Deposit accepted. Death Coin threshold met -> REVERSE LEVEL.")
		_start_reverse_level()
	else:
		print("[Terminal] Deposit accepted. Proceeding to next level.")
		GameState.go_to_next_level()
	SaveSystem.save_game()

func _start_reverse_level() -> void:
	# Reverse level hook: reuses the same level scene, mirrored spawn
	# density and every-other-platform-slice removed. See README for the
	# level-loader flag this should set once real levels exist.
	print("[Terminal] Reverse level would start here (placeholder hook).")
