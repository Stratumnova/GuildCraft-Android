extends Node
## GameState — tracks which level the player is on and global session info.
## Persists automatically across scene reloads (autoload). Written to disk
## via SaveSystem, minus anything explicitly excluded (Bytecoins).

signal level_changed(new_level: int)

const TOTAL_LEVELS: int = 3

var current_level: int = 1
var player_name: String = "PLAYER"

## Game speed multiplier, adjustable in the pause menu.
## Settings: 0.5, 0.75, 1.0 (normal), 1.25, 1.5, 2.0
var game_speed: float = 1.0
const GAME_SPEEDS: Array[float] = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]

## Difficulty preset. Changing this triggers a full reset (see full_reset()).
var difficulty: String = "normal"

## Lifetime reverse-level tracker. Format shown in HUD as "-fails/+wins".
var reverse_fails: int = 0
var reverse_wins: int = 0

func go_to_next_level() -> void:
	current_level += 1
	if current_level > TOTAL_LEVELS:
		# Placeholder hook: no Level 4+ built yet. Loops back to Level 1.
		# Swap this for real level progression once more levels exist.
		current_level = 1
	level_changed.emit(current_level)
	_reset_per_level_state()

func restart_current_level() -> void:
	level_changed.emit(current_level)
	_reset_per_level_state()

func _reset_per_level_state() -> void:
	BytecoinManager.reset_level()
	DeathCoinManager.reset_level()
	# LoopcoinMemory intentionally NOT reset here — it persists all session.

func full_reset() -> void:
	current_level = 1
	BytecoinManager.reset_level()
	DeathCoinManager.reset_level()
	LoopcoinMemory.reset_all()
	reverse_fails = 0
	reverse_wins = 0
	SaveSystem.save_game()

func record_reverse_result(reached_start: bool) -> void:
	if reached_start:
		reverse_wins += 1
	else:
		reverse_fails += 1
	SaveSystem.save_game()
