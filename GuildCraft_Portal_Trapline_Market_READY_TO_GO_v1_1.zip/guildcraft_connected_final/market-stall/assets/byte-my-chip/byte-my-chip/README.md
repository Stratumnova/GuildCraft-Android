# Byte My Chip — Current Build Status

This README reflects what is **actually built, in the project, and tested
working in-engine** as of this zip — not the full original design scope.
See the bottom section for what's designed but not yet built.

---

## ✅ Tested and confirmed working

### Player movement & physics
- **File:** `scripts/player.gd`, scene: `character_body_2d.tscn`
- WASD / Arrow key movement
- Single jump (Space / Right-click), resets on ground contact
- Double jump with limited charges (tactical float)
- Gravity + `CharacterBody2D` collision against the floor
- Confirmed: player lands on solid ground, does not fall through

### Animations
- Three real `AnimatedSprite2D` nodes: `player_walk_right`, `player_walk_left`
  (a genuine walk-backwards animation, not a mirrored flip), `player_idel`
  (spinning idle)
- `player.gd::_update_animation()` switches between them live based on
  movement direction
- Confirmed: all three play correctly during testing

### World / level structure
- `world.tscn` — root `Node2D` ("World") holding `player` and `floor_1` as
  proper siblings (both instanced scenes)
- `floor_1.tscn` — `StaticBody2D` with correctly nested `CollisionShape2D`
  + `Sprite2D` (three floor tile instances)
- Confirmed: correct parent/child structure, no more fall-through bugs

### Input Map
- All actions bound to real keys in Project Settings -> Input Map:
  `move_left` (A), `move_right` (D), `jump` (Space), `attack` (Left Mouse),
  `pause_menu` (P), `hotbar_1`-`hotbar_5` (number keys)
- Confirmed: movement, jump, and attack all respond to input

### Autoloads (global systems)
All 6 registered and loading correctly in Project Settings -> Autoload:
- `GameState` - `scripts/game_state.gd`
- `BytecoinManager` - `scripts/bytecoin_manager.gd`
- `DeathCoinManager` - `scripts/death_coin_manager.gd`
- `LoopcoinMemory` - `scripts/loopcoin_memory.gd`
- `SaveSystem` - `scripts/save_system.gd`
- `PowerDatabase` - `scripts/power_database.gd`

### Bytecoin pickup
- **Files:** `scenes/bytecoin.tscn` + `scenes/bytecoin_pickup.tscn.gd`
- `Area2D` root, `Sprite2D` (floppy disk art) + sized `CollisionShape2D`
- On player contact: calls `BytecoinManager.collect_coin()`, then
  `queue_free()`s itself
- Confirmed: coin disappears on contact, `collect_coin()` fires
- **Effect confirmed by design (not yet visually confirmed via HUD):**
  `collect_coin()` triggers `player.gd::_on_coin_collected()`, which raises
  `max_hp` per the active HP mode (Normal/Baby Steps/Fingers Crossed) - no
  on-screen confirmation yet since there's no HUD

### Powers (logic only, no visuals yet)
- **File:** `scripts/power_database.gd`, fired via `player.gd::use_equipped_power()`
- Attack input correctly triggers the equipped power's logic branch
  (ranged/melee/utility) and prints a confirmation line to the Output
  console (e.g. `Fire Fire Core toward (x, y)`), including live mouse-aim
  direction
- Cooldown/power-bar timers are functional (prevents spam)
- **Not yet built:** actual projectile scenes, melee hitbox, visual feedback
  for Move Core / Fade Core

---

## In progress

### Pause Menu
- `scripts/pause_menu.gd` exists and is being wired to a `PauseMenu.tscn`
  scene (CanvasLayer + Panel + Restart/Resume buttons)
- P key toggle logic is written (`_unhandled_input` listens for `pause_menu`
  action)
- Not yet confirmed working end-to-end in this zip

---

## Designed but not yet built

- **HUD** - no visible HP/Bytecoin/Death Coin/reverse-tracker display yet.
  All state is currently only checkable via the Godot Inspector during Play
  mode.
- **Death -> respawn at level start** - `player.gd::die()` calls
  `GameState.restart_current_level()`, but that function does not yet call
  `get_tree().reload_current_scene()`, so player position is not currently
  reset on death (coin counts do reset).
- **Enemies** - `scripts/enemy.gd` is written but no `Enemy.tscn` scene
  exists yet.
- **Terminals** (info/deposit) - `scripts/terminal.gd` written, no scene.
- **Power-up pickup coins** (Fire/Water/Melee/Move/Fade) - not yet built as
  world objects; powers currently only exist pre-equipped on the hotbar.
- **Hazard blocks, movable props, moving platforms** - scripts exist
  (`hazard_block.gd`, `movable_prop.gd`, `moving_platform.gd`,
  `select_block.gd`), no scenes built yet.
- **Reverse level mechanic** - logic lives in `death_coin_manager.gd`
  (`try_trigger_reverse()`), not yet hooked into an actual level flow.
- **Save/Load** - `save_system.gd` written, not yet tested end-to-end.
- **Level 1 actual layout** - current `world.tscn` is a physics/systems
  test bed (one floor, one coin), not a real designed level.

---

## Known cleanup items (non-breaking)
- `bytecoin.gd` at the project root is an unused default template, safe to
  delete - the real pickup script is `scenes/bytecoin_pickup.tscn.gd`
- That script's filename has a redundant double extension
  (`bytecoin_pickup.tscn.gd`) - cosmetic only, works fine as-is, could be
  renamed to `bytecoin_pickup.gd` for clarity later

---

## Coin System Naming Note
"Loopcoin" (the behavior-memory system in `loopcoin_memory.gd`) is slated
for a future rename/refactor to align with an updated cross-project coin
architecture (Loopcoin = a shared "bus" concept; this system's actual role
is closer to a "Memorycoin" - a world-memory state carrier). Not yet
changed in code - noted here so the naming makes sense whenever that pass
happens.

---

## Engine
Godot 4.7.2 stable. Export target: HTML5/WebAssembly (not yet exported/tested).
