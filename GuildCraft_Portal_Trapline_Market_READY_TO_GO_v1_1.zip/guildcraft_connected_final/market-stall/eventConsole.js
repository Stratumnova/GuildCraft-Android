// eventConsole.js
// -----------------------------------------------------------------------------
// The one logging interface every system in the toolkit reports through.
// Nothing else in this toolkit should ever call console.log directly - it
// should call EventConsole.emit() instead, so every system's output shares
// one shape and one place to filter/redirect it (a debug overlay later,
// a file, a network tap - swap _print() without touching any calling code).
//
// Three tiers, matching the "Frankenstein World" console design:
//   EVENT  - what happened (always present)
//   REASON - why it happened, in plain words (optional, but every real
//            decision-making system should provide one)
//   STATE  - the raw numbers behind the reason (optional)
//
// Tag filtering exists because an unfiltered log drowns itself in seconds
// once more than one system is running - set a tag allowlist BEFORE wiring
// up a second system, not after the log is already unreadable.
// -----------------------------------------------------------------------------

const EventConsole = {

  _listeners: [],       // [{ filter: fn|null, callback: fn }]
  _enabledTags: null,   // null = everything, or a Set of system tags to allow
  _history: [],         // every entry ever emitted, plain objects — see
                         // getHistoryAsText()/copyHistoryToClipboard() below

  // system: short tag string, e.g. "VILLAGE", "ZONE", "KNOWLEDGE", "PLAYER"
  // event: one line, what happened
  // reason: optional one line, why (plain words, not just numbers)
  // state: optional plain object, the numbers behind the reason
  // purpose: a SECOND, independent tag — not what system this came from,
  //          but what KIND of thing it is: "decision" (a real choice was
  //          made), "state" (nothing chosen, just a status/idle report),
  //          "milestone" (a permanent/notable change worth flagging on its
  //          own), or your own categories. Lets you filter/copy "just the
  //          decisions" across every system, orthogonal to filtering by
  //          which system made them.
  emit(system, event, reason = null, state = null, purpose = "general") {
    const entry = {
      system, event, reason, state, purpose,
      timestamp: performance.now(),
      source: this._captureSource(),
    };

    // The loud half of the contract — every entry passes through this
    // before it goes anywhere. A caller that got the shape wrong finds
    // out immediately, not several systems downstream.
    const check = ContractGuard.validateEvent(entry);
    if (!check.ok) {
      this._failLoud(check.reason);
      return;
    }

    this._history.push(entry);
    this._print(entry);
    for (const listener of this._listeners) {
      if (!listener.filter || listener.filter(entry)) {
        listener.callback(entry);
      }
    }
  },

  // Real file:line of whatever called emit() — not self-reported by the
  // system, captured automatically from the JS engine's own stack trace,
  // the same mechanism a browser's dev console uses for its own log
  // lines. Best-effort: format is a V8/Chrome convention, not a formal
  // standard, so this may come back null on other engines — callers must
  // treat a missing source as "unavailable", never as an error.
  _captureSource() {
    try {
      const stack = new Error().stack;
      if (!stack) return null;
      const lines = stack.split("\n").slice(1); // drop the "Error" line itself
      const callerLine = lines[2]; // [0]=_captureSource, [1]=emit, [2]=real caller
      if (!callerLine) return null;
      const match = callerLine.match(/at\s+(?:(\S+)\s+)?\(?([^\s()]+:\d+:\d+)\)?/);
      if (!match) return null;
      const fnName = match[1] || "anonymous";
      const location = match[2].replace(/^https?:\/\/[^/]+\//, "");
      return `${fnName} @ ${location}`;
    } catch (e) {
      return null;
    }
  },

  // Loud on purpose — console.error alone is easy to miss. If the page
  // has a visible spot for it (#contract-error), use it; otherwise a
  // browser alert() is the fallback, since silent failure is exactly
  // what this exists to prevent.
  _failLoud(reason) {
    console.error(`[CONTRACT] ${reason}`);
    const el = typeof document !== "undefined" ? document.getElementById("contract-error") : null;
    if (el) {
      el.textContent = reason;
      el.style.display = "block";
    } else if (typeof alert === "function") {
      alert(reason);
    }
  },

  // Plain-text rendering of one entry — shared by the console printer and
  // the clipboard export, so the two never drift out of sync with each
  // other over time.
  formatEntry(entry) {
    let text = `[${entry.system}] ${entry.event}`;
    if (entry.reason) text += `\n  REASON  ${entry.reason}`;
    if (entry.state) text += `\n  STATE   ${JSON.stringify(entry.state)}`;
    if (entry.source) text += `\n  SOURCE  ${entry.source}`;
    return text;
  },

  // Every entry emitted this page load, as one plain-text block — this is
  // what "copy log" buttons should call, rather than each page re-scraping
  // its own DOM. Pass a filterFn to grab only a subset (e.g. one panel's
  // entries in a side-by-side comparison) — defaults to everything.
  getHistoryAsText(filterFn = null) {
    const entries = filterFn ? this._history.filter(filterFn) : this._history;
    return entries.map(e => this.formatEntry(e)).join("\n");
  },

  // Same history, but as newline-delimited JSON (one compact object per
  // line) instead of the human-readable EVENT/REASON/STATE block. No
  // labels, no indentation, nothing decorative — built specifically for
  // handing a log to something that's going to parse it (an AI reading
  // pasted output, a script) rather than a person reading it on screen.
  getHistoryAsJSONL(filterFn = null) {
    const entries = filterFn ? this._history.filter(filterFn) : this._history;
    return entries.map(e => JSON.stringify(e)).join("\n");
  },

  // Returns a Promise<boolean> — true on success. Requires a secure
  // context (https, or localhost) for navigator.clipboard to exist at
  // all; callers should handle a false/rejected result gracefully
  // (e.g. Neocities serves over https, so this is fine there).
  async copyHistoryToClipboard(filterFn = null) {
    try {
      await navigator.clipboard.writeText(this.getHistoryAsText(filterFn));
      return true;
    } catch (err) {
      return false;
    }
  },

  // filterFn receives the full entry and returns true/false. Pass null to
  // hear everything. Use this instead of parsing console output if you're
  // building a real debug-overlay UI on top of this later.
  subscribe(filterFn, callback) {
    this._listeners.push({ filter: filterFn, callback });
  },

  // Pass an array of system tags to only print those, or null for everything.
  // This is throttling by SOURCE - see also emitThrottled() below for
  // throttling by RATE, which matters just as much once wildlife/weather
  // are added (nothing should log every physics tick).
  setTagFilter(tags) {
    this._enabledTags = tags ? new Set(tags) : null;
  },

  // Convenience for high-frequency systems (a rabbit's hunger tick, a
  // vendor's idle check) - only actually logs once per `intervalMs` per
  // unique key, so "nothing is hidden" doesn't also mean "nothing is
  // readable". Use plain emit() for genuine one-off decisions (a craft
  // completing, a zone flagging) - reserve this for anything that would
  // otherwise fire every frame.
  _lastEmitByKey: {},
  emitThrottled(key, intervalMs, system, event, reason = null, state = null) {
    const now = performance.now();
    const last = this._lastEmitByKey[key] || 0;
    if (now - last < intervalMs) return;
    this._lastEmitByKey[key] = now;
    this.emit(system, event, reason, state);
  },

  _print(entry) {
    if (this._enabledTags && !this._enabledTags.has(entry.system)) return;
    console.log(`[${entry.system}] ${entry.event}`);
    if (entry.reason) console.log(`  REASON  ${entry.reason}`);
    if (entry.state) console.log(`  STATE  `, entry.state);
  },
};
