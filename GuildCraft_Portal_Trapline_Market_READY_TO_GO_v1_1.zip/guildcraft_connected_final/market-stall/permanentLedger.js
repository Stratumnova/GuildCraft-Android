// permanentLedger.js
// -----------------------------------------------------------------------------
// One shared store for values that only ever go up, never down - the same
// rule that's shown up independently in this project three times now
// (entropy that never decays, a zone's heat flag once tripped, an NPC's
// knowledge tier once learned). Rather than three separate hand-rolled
// "never decrease" checks scattered across three systems, every one of
// them reads/writes through this instead.
//
// Deliberately just numbers under string keys - no opinion on what a key
// MEANS. A vendor's trust score, a zone's drift flag, a rabbit's total
// times-fled-a-predator, and a player's knowledge tier on "rabbit.diet"
// are all just entries here, distinguished only by how you name the key.
//
// Composite keys are just colon-joined strings by convention - e.g.
// "knowledge:player1:huntng:rabbit:diet" or "zone:forest_north:heat".
// buildKey() below exists so every caller uses the same joining rule
// instead of some using ":" and others using "." or "/".
// -----------------------------------------------------------------------------

const PermanentLedger = {

  _values: {},   // key (string) -> number

  buildKey(...parts) {
    return parts.join(":");
  },

  get(key, fallback = 0) {
    return Object.prototype.hasOwnProperty.call(this._values, key)
      ? this._values[key]
      : fallback;
  },

  has(key) {
    return Object.prototype.hasOwnProperty.call(this._values, key);
  },

  // The core rule: never lowers an existing value. Returns what's actually
  // stored afterward, so callers can tell whether their attempt took effect.
  raise(key, value) {
    const current = this.get(key, -Infinity);
    if (value > current) {
      this._values[key] = value;
    }
    return this.get(key, 0);
  },

  // Convenience for the "entropy" shape specifically - add on top of
  // whatever's there now, permanently. Equivalent to raise(key, get(key)+amount)
  // but reads clearer at call sites that are genuinely accumulating rather
  // than setting a specific tier/threshold.
  add(key, amount) {
    return this.raise(key, this.get(key, 0) + amount);
  },

  // For debugging / the Frankenstein console's STATE tier - a shallow
  // snapshot of every key currently under a given prefix, e.g.
  // snapshot("knowledge:player1:") to see everything one entity knows.
  snapshot(prefix = "") {
    const out = {};
    for (const key of Object.keys(this._values)) {
      if (key.startsWith(prefix)) {
        out[key] = this._values[key];
      }
    }
    return out;
  },
};
