// player.js
// -----------------------------------------------------------------------------
// Holds everything about the player: where they are on the grid, what
// specialization they've chosen, their crafting progress, currency, and
// inventory. This is the object saveState.js snapshots for saving.
// -----------------------------------------------------------------------------

const player = {
  gridColumn: 16,
  gridRow: 16,
  moveSpeedCellsPerSecond: 6,
  targetColumn: null, // where the player tapped/clicked - null means "not moving"
  targetRow: null,

  // Specialization / mastery progress (Section 4 & 5 of the master doc)
  chosenCategory: null,   // e.g. "food"
  chosenPath: null,       // e.g. "stews"
  currentStageIndex: 0,   // index into techTree[category].paths[path].stages - ACTIVE path only
  craftsCompletedThisStage: 0, // ACTIVE path only
  masteredCategories: [], // categories fully mastered across past runs

  // Progress on OTHER paths within the current category, kept so switching
  // paths mid-run doesn't lose work (needed for capstone-style gates that
  // require partial progress on two different paths at once - e.g.
  // Blacksmith's Armor/Weapon Master Capstone). Keyed by pathKey ->
  // { stageIndex, craftsCompleted }. Cleared on restart, same as everything
  // else local to a run.
  pathProgress: {},

  // Economy (Section 3: stall-local currency only, never agagets directly)
  floppyBalance: 20, // Market Stall currency: floppy disks

  // Inventory: simple name -> count map. Backpack/storage/display distinction
  // is a UI concern for now, not a separate data structure yet.
  inventory: {},

  // Furniture placement: array of { type, column, row }. Starting kit
  // (Section 2) is placed by setupStartingFurniture() below.
  furniturePlacement: [],

  workerLevel: 0, // 0 = no worker yet, player must buy materials manually (Section 6)

  // ---- Derived helpers ----

  getCurrentPathData() {
    if (!this.chosenCategory || !this.chosenPath) return null;
    return techTree[this.chosenCategory].paths[this.chosenPath];
  },

  getCurrentStageData() {
    const pathData = this.getCurrentPathData();
    if (!pathData) return null;
    return pathData.stages[this.currentStageIndex];
  },

  isOnMasteryStage() {
    const stageData = this.getCurrentStageData();
    return stageData ? !!stageData.isMasteryStage : false;
  },

  // Effective stage index for ANY path in the current category - the live
  // value if it's the currently active path, otherwise whatever was saved
  // in pathProgress the last time the player worked on it, otherwise 0
  // (never touched). Used by capstone-style unlock checks that need to see
  // progress on a path the player isn't currently working on.
  getStageIndexForPath(pathKey) {
    if (pathKey === this.chosenPath) return this.currentStageIndex;
    const saved = this.pathProgress[pathKey];
    return saved ? saved.stageIndex : 0;
  },

  // Switches the active path within the SAME category, saving the current
  // path's progress into pathProgress and restoring (or starting fresh)
  // the target path's progress. Does not touch inventory or currency -
  // those are shared across the whole stall regardless of which recipe
  // track is active.
  switchToPath(newPathKey) {
    if (this.chosenPath) {
      this.pathProgress[this.chosenPath] = {
        stageIndex: this.currentStageIndex,
        craftsCompleted: this.craftsCompletedThisStage,
      };
    }

    const saved = this.pathProgress[newPathKey];
    this.chosenPath = newPathKey;
    this.currentStageIndex = saved ? saved.stageIndex : 0;
    this.craftsCompletedThisStage = saved ? saved.craftsCompleted : 0;
  },

  addToInventory(itemName, quantity = 1) {
    this.inventory[itemName] = (this.inventory[itemName] || 0) + quantity;
  },

  hasComponents(componentList) {
    return componentList.every((name) => (this.inventory[name] || 0) > 0);
  },

  consumeComponents(componentList) {
    componentList.forEach((name) => {
      this.inventory[name] = Math.max(0, (this.inventory[name] || 0) - 1);
    });
  },

  // Places the starting furniture kit (Section 2) at fixed grid positions.
  // Fixed placement keeps v1 simple - no drag-and-drop needed yet.
  setupStartingFurniture() {
    this.furniturePlacement = [
      { type: "salesTable", column: 14, row: 10 },
      { type: "storageBoxOne", column: 12, row: 10 },
      { type: "storageBoxTwo", column: 12, row: 11 },
      { type: "displayTable", column: 16, row: 10 },
    ];
  },

  // Resets everything EXCEPT what survives a restart (Section 4):
  // masteredCategories persists, everything else does not.
  restartWithNewCategory() {
    this.chosenCategory = null;
    this.chosenPath = null;
    this.currentStageIndex = 0;
    this.craftsCompletedThisStage = 0;
    this.pathProgress = {};
    this.floppyBalance = 20;
    this.inventory = {};
    this.workerLevel = 0;
    this.setupStartingFurniture();
    // masteredCategories is deliberately NOT reset here.

    // These two systems live outside the player object but are still part
    // of the "one stall, one save" reset (Section 4) - clear them here too.
    if (typeof displayTable !== "undefined") displayTable.slots = [null, null, null, null];
    if (typeof worker !== "undefined") worker.list = [];
  },
};
