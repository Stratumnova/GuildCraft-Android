// decisionEngine.js
// -----------------------------------------------------------------------------
// One shared weighted-decision function, meant to replace every place a
// system picks "the best option, but not ALWAYS the single best option" -
// a vendor's craft cycle, an animal's forage-vs-flee choice, a route pick.
// Before this file existed, that logic got hand-written slightly differently
// in each system (see Emergent Systems' boss.gd route choice, and this
// session's VendorNPC craft cycle in GDScript) - this is that same shape,
// pulled out once, so every future system gets it for free instead of
// re-deriving it.
//
// Why weighted sampling instead of Math.max(): a hard "always pick the best
// score" makes every NPC's decisions perfectly predictable and same-feeling.
// Exponential weighting keeps the best option MOST likely without making it
// CERTAIN, which is what makes a vendor or an animal feel like it's making a
// judgment call rather than running a lookup table.
//
// The breakdown this returns is not cosmetic - it IS the REASON tier for the
// event console. Any system using this can pass the breakdown straight into
// EventConsole.emit()'s `state` argument with zero extra bookkeeping.
// -----------------------------------------------------------------------------

const DecisionEngine = {

  // candidates: [{ id: string, score: number }, ...]
  // decisiveness: how sharply the pick commits to the highest score.
  //   Low (~1-2)  - close to a coin flip even with a clear best option.
  //   Mid (~4)    - clear lean toward the best, but real variance (this is
  //                 what the Boss's route choice used: ~96% predictable at
  //                 score 0 gap, ~50/50 around a small gap, ~97% at a big one).
  //   High (~8+)  - close to a hard argmax, occasional surprises only.
  //
  // Returns null if candidates is empty. Otherwise:
  //   { chosen: id, breakdown: [{id, score, weight, probability}], roll, total }
  weightedPick(candidates, decisiveness = 4.0) {
    if (!candidates || candidates.length === 0) return null;

    const weights = candidates.map(c => Math.exp(c.score * decisiveness));
    const total = weights.reduce((sum, w) => sum + w, 0);

    const roll = Math.random() * total;
    let acc = 0;
    let chosenIndex = candidates.length - 1;
    for (let i = 0; i < candidates.length; i++) {
      acc += weights[i];
      if (roll <= acc) {
        chosenIndex = i;
        break;
      }
    }

    const breakdown = candidates.map((c, i) => ({
      id: c.id,
      score: c.score,
      weight: weights[i],
      probability: total > 0 ? weights[i] / total : 0,
    }));

    return {
      chosen: candidates[chosenIndex].id,
      breakdown,
      roll,
      total,
    };
  },

  // A plain-English REASON line built straight from weightedPick()'s own
  // breakdown - use this so every system doesn't hand-write its own phrasing
  // for the same shape of decision.
  describePick(result) {
    if (!result) return "no eligible candidates";
    const winner = result.breakdown.find(b => b.id === result.chosen);
    const pct = Math.round(winner.probability * 100);
    return `${result.chosen} selected (${pct}% chance, score ${winner.score.toFixed(2)})`;
  },

  // Returns an INDEPENDENT engine with its own baked-in default
  // decisiveness (still overridable per-call). This exists for side-by-side
  // comparisons: two instances tuned differently, running the same kind of
  // decision, so you can watch the actual behavior difference instead of
  // guessing from the math. It's still the same algorithm in both — for a
  // genuine OLD-CODE-vs-NEW-CODE comparison (the algorithm itself changed,
  // not just a tuning number), keep a renamed copy of the old
  // decisionEngine.js file around and load both under different global
  // names instead; this factory only covers the "same code, different
  // settings" case.
  createInstance(defaultDecisiveness = 4.0) {
    return {
      weightedPick(candidates, decisiveness = defaultDecisiveness) {
        return DecisionEngine.weightedPick(candidates, decisiveness);
      },
      describePick(result) {
        return DecisionEngine.describePick(result);
      },
    };
  },
};
