// commission.js
// -----------------------------------------------------------------------------
// Pay an NPC of a matching category to craft an item FOR you, using
// materials you've already collected - from your own trade, other vendors,
// bartering, or workers. Does NOT count toward your own specialization
// progress (craftsCompletedThisStage is untouched) - this is purely a
// resale strategy, not a shortcut to mastery.
//
// The resulting item is tagged " [NPC]" in inventory so pricing.js prices
// it at the FULL NPC rate instead of the discounted player-made rate
// (Section 6). That premium, minus the crafting fee below, is where the
// margin comes from - e.g. collect stage-4 materials, pay a stage-4 NPC to
// craft it, sell the result at NPC-tier price.
// -----------------------------------------------------------------------------

const commission = {

  feeRateOfNpcPrice: 0.5, // NPC keeps half the item's base NPC value as their fee - tune during playtesting

  getFee(stageIndex) {
    return Math.round(pricing.npcBasePriceByStage[stageIndex] * this.feeRateOfNpcPrice);
  },

  // Same access rule as buying/bartering from another category's vendor
  // (Section 6) - unlocked once the player has recruited a worker.
  canCommissionFrom(categoryKey) {
    return vendor.canBuyFrom(categoryKey);
  },

  craftForHire(categoryKey, pathKey, stageIndex, itemIndex) {
    if (!this.canCommissionFrom(categoryKey)) {
      EventConsole.emit("COMMISSION", `Commission blocked: ${categoryKey}`, "unlock a worker to use another category's NPCs", { category: categoryKey }, "state");
      return false;
    }

    const categoryData = techTree[categoryKey];
    const pathData = categoryData && categoryData.paths[pathKey];
    const stageData = pathData && pathData.stages[stageIndex];
    const itemData = stageData && stageData.items[itemIndex];
    if (!itemData) return false;

    if (!player.hasComponents(itemData.components)) {
      EventConsole.emit("COMMISSION", `Commission failed: ${itemData.name}`, "missing components", { item: itemData.name, needed: itemData.components }, "state");
      return false;
    }

    const fee = this.getFee(stageIndex);
    if (player.floppyBalance < fee) {
      EventConsole.emit("COMMISSION", `Commission failed: ${itemData.name}`, "not enough floppies for the crafting fee", { item: itemData.name, fee }, "state");
      return false;
    }

    player.consumeComponents(itemData.components);
    player.floppyBalance -= fee;
    player.addToInventory(`${itemData.name} [NPC]`, 1);
    EventConsole.emit("COMMISSION", `Commissioned ${itemData.name} [NPC]`, `fee: ${fee}`, { item: itemData.name, fee, category: categoryKey, stageIndex }, "decision");
    return true;
  },
};
