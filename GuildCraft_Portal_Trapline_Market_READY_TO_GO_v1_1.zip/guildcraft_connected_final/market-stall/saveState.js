// saveState.js
// -----------------------------------------------------------------------------
// Decides WHEN to call backendApi.writeSave() - the "one stall, one save"
// rule from the master doc (Section 4). We don't save every frame; we save
// after meaningful changes so it's cheap and still safe to close the tab
// anytime.
// -----------------------------------------------------------------------------

const saveState = {

  currentPlayerId: "testPlayerOne", // stand-in until real login exists

  // Pulls together everything that needs to survive a session close.
  buildSaveSnapshot(player) {
    return {
      chosenCategory: player.chosenCategory,
      chosenPath: player.chosenPath,
      currentStageIndex: player.currentStageIndex,
      craftsCompletedThisStage: player.craftsCompletedThisStage,
      pathProgress: player.pathProgress,
      floppyBalance: player.floppyBalance,
      inventory: player.inventory,
      furniturePlacement: player.furniturePlacement,
      workerLevel: player.workerLevel,
      displaySlots: displayTable.slots,
      workerList: worker.list,
      marketBusiness: typeof marketBusiness!=="undefined" ? marketBusiness.snapshot() : null,
      marketActors: typeof marketActors!=="undefined" ? marketActors.snapshot() : null,
      marketEconomy: typeof marketEconomy!=="undefined" ? JSON.parse(JSON.stringify(marketEconomy.state)) : null,
      savedAt: new Date().toISOString(),
    };
  },

  // Short human-readable string for the player card's activeSaves list
  // (contract Section 1) - lets the Timesheet show progress without
  // understanding this game's save shape at all.
  buildDisplaySummary(player) {
    if (!player.chosenCategory) return "Just started - no category chosen yet";
    const categoryLabel = techTree[player.chosenCategory].label;
    if (!player.chosenPath) return `${categoryLabel} - choosing a path`;
    const pathLabel = techTree[player.chosenCategory].paths[player.chosenPath].label;
    return `${categoryLabel} - ${pathLabel}, Stage ${player.currentStageIndex + 1}`;
  },

  // Call this after: choosing a specialization, completing a craft,
  // advancing a stage, placing furniture, or restarting.
  // Not called on every player movement tick - that would be wasteful.
  async saveNow(player) {
    const snapshot = this.buildSaveSnapshot(player);
    const summary = this.buildDisplaySummary(player);
    return backendApi.writeSave(this.currentPlayerId, snapshot, summary);
  },

  async loadExistingSave() {
    const save = await backendApi.loadSave(this.currentPlayerId);
    return AccountMigration.migrateMarketSave(save);
  },

  // Cheap persistence guard for passive simulation changes (NPC sales, workers,
  // currency changes). The explicit action saves remain; this catches everything else.
  async autosave(player) {
    try { return await this.saveNow(player); }
    catch (error) { console.warn("Market autosave failed", error); return { success:false, error }; }
  },
};
