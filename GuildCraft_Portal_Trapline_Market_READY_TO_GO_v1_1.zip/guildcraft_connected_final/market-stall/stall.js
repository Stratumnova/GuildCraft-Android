// stall.js
// -----------------------------------------------------------------------------
// Draws the player's stall. Visual language (per request):
// - Each category has its own color, applied to all of that stall's furniture.
// - Tables (sales table, display table) = half-block rectangles.
// - Storage boxes = triangles.
// - Player avatar = circle (unchanged).
// -----------------------------------------------------------------------------

const stall = {

  categoryColors: {
    food: "#e0a83c",
    blacksmith: "#8c8c96",
    alchemy: "#9b59b6",
    carpenter: "#8b5a2b",
    tannery: "#c2a06c",
    masterMerchantKing: "#d4af37",
  },

  getStallColor() {
    return this.categoryColors[player.chosenCategory] || "#999999";
  },

  drawHalfBlockTable(canvasContext, column, row, color) {
    const pixels = grid.cellToPixels(column, row);
    const halfHeight = grid.cellSizePixels / 2;
    canvasContext.fillStyle = color;
    canvasContext.fillRect(pixels.x + 2, pixels.y + halfHeight, grid.cellSizePixels - 4, halfHeight - 2);
  },

  drawTriangleStorage(canvasContext, column, row, color) {
    const pixels = grid.cellToPixels(column, row);
    const size = grid.cellSizePixels;
    canvasContext.fillStyle = color;
    canvasContext.beginPath();
    canvasContext.moveTo(pixels.x + size / 2, pixels.y + 2);
    canvasContext.lineTo(pixels.x + size - 2, pixels.y + size - 2);
    canvasContext.lineTo(pixels.x + 2, pixels.y + size - 2);
    canvasContext.closePath();
    canvasContext.fill();
  },

  draw(canvasContext) {
    const color = this.getStallColor();

    player.furniturePlacement.forEach((piece) => {
      if (piece.type === "salesTable" || piece.type === "displayTable") {
        this.drawHalfBlockTable(canvasContext, piece.column, piece.row, color);
      } else if (piece.type === "storageBoxOne" || piece.type === "storageBoxTwo") {
        this.drawTriangleStorage(canvasContext, piece.column, piece.row, color);
      }
    });

    // Player avatar
    const playerPixels = grid.cellToPixels(player.gridColumn, player.gridRow);
    canvasContext.fillStyle = "#e8e8e8";
    canvasContext.beginPath();
    canvasContext.arc(
      playerPixels.x + grid.cellSizePixels / 2,
      playerPixels.y + grid.cellSizePixels / 2,
      grid.cellSizePixels / 2 - 3,
      0,
      Math.PI * 2
    );
    canvasContext.fill();
  },
};
