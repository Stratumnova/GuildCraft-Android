// clock.js
// -----------------------------------------------------------------------------
// In-game clock and calendar. 48 real minutes = 24 in-game hours (to start,
// tunable - see realMinutesPerFullDay). Purely cosmetic/informational in v1;
// nothing in the game currently reacts to time of day, but sales log entries
// are timestamped against this clock rather than real time.
// -----------------------------------------------------------------------------

const clock = {
  totalGameMinutes: 0,
  realMinutesPerFullDay: 48,

  update(deltaSeconds) {
    const gameMinutesPerRealSecond = (24 * 60) / (this.realMinutesPerFullDay * 60);
    this.totalGameMinutes += deltaSeconds * gameMinutesPerRealSecond;
  },

  getDay() {
    return Math.floor(this.totalGameMinutes / (24 * 60)) + 1;
  },

  getFormattedTime() {
    const minutesToday = this.totalGameMinutes % (24 * 60);
    const hour = Math.floor(minutesToday / 60);
    const minute = Math.floor(minutesToday % 60);
    const hourStr = String(hour).padStart(2, "0");
    const minuteStr = String(minute).padStart(2, "0");
    return `Day ${this.getDay()}, ${hourStr}:${minuteStr}`;
  },
};
