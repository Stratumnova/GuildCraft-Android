# Market Stall Fieldworks v1.4

Market economy/crafting room sharing the Portal Player Card directly with The Wild. Includes the NPC crafter, Iris Vale requests, player stall ownership, exact-stall foreground selling/haggling, background seller simulation, uncollected stall till, three roaming market actors, NPC social/runtime systems, and background need/supply/currency simulation.

Uncollected stall till is session-local and deliberately excluded from save-card snapshots. The player must return to the stall and collect it before those floppies join the Portal account.
