// itemsMain.js — glue for the Items/Crafting Tree reference page.
// -----------------------------------------------------------------------------
// This page is a standalone browsable reference, NOT tied to a player save.
// It only needs the content layer (techTreeContent.js) and the base engine
// pieces that expand/read it (techTreeEngine.js, pricing.js for suggested
// values) - none of the live-game systems (npc.js, worker.js, crafting.js,
// player.js, etc.) are loaded on this page at all.
// -----------------------------------------------------------------------------

let searchFilter = "";

function renderTree() {
  const container = document.getElementById("treeContainer");
  const categoryKeys = Object.keys(techTree);

  container.innerHTML = categoryKeys.map((categoryKey) => {
    const categoryData = techTree[categoryKey];

    if (categoryData.isCapstone) {
      return `<details class="category">
        <summary>${categoryData.label}</summary>
        <p class="note">Capstone category - grants access to all five other trees at once. No unique item data of its own.</p>
      </details>`;
    }

    const pathBlocks = Object.entries(categoryData.paths).map(([pathKey, pathData]) => {
      const stageBlocks = pathData.stages.map((stage, stageIndex) => {
        const itemRows = stage.items
          .filter((item) => !searchFilter || item.name.toLowerCase().includes(searchFilter))
          .map((item) => {
            const suggestedPrice = pricing.getPlayerItemValueWindow(stageIndex).sweetSpot;
            const npcPrice = pricing.npcBasePriceByStage[stageIndex];
            const tradeNote = item.components.some((c) => c.startsWith("trade"))
              ? ` <span class="tag">requires trade good</span>` : "";
            return `<div class="item">
              <strong>${item.name}</strong>${tradeNote}<br>
              <small>Components: ${item.components.join(", ")}</small><br>
              <small>Player-made sell value: ${suggestedPrice} · NPC-made/commissioned value: ${npcPrice}</small>
            </div>`;
          }).join("");

        if (searchFilter && itemRows === "") return "";

        return `<details class="stage" open>
          <summary>Stage ${stageIndex + 1}${stage.isMasteryStage ? " (Mastery)" : ""} - ${stage.craftsToAdvance} crafts, ~${stage.secondsPerCraft}s each</summary>
          ${itemRows}
        </details>`;
      }).filter((block) => block !== "").join("");

      if (searchFilter && stageBlocks === "") return "";

      return `<details class="path" open>
        <summary>${pathData.label}${pathData.opposedWith ? ` <span class="tag">opposed with ${categoryData.paths[pathData.opposedWith].label}</span>` : ""}${pathData.gated ? ` <span class="tag">gated</span>` : ""}</summary>
        ${stageBlocks}
      </details>`;
    }).filter((block) => block !== "").join("");

    if (searchFilter && pathBlocks === "") return "";

    return `<details class="category" open>
      <summary>${categoryData.label}</summary>
      ${pathBlocks}
    </details>`;
  }).filter((block) => block !== "").join("");
}

function onSearchInput(value) {
  searchFilter = value.trim().toLowerCase();
  renderTree();
}

renderTree();
