// techTreeEngine.js — BASE LAYER.
// -----------------------------------------------------------------------------
// Generic machinery that operates on WHATEVER content file loaded before this
// one (techTreeContent.js normally, but any file providing the same contract
// would work). Nothing in here references a specific item, category, or
// recipe by name - it only reads the shape (techTree, baseMaterials,
// tradeGoods, rareDropMaterials, categoryVariantModifiers).
//
// Load order requirement: the content file MUST load before this file.
// -----------------------------------------------------------------------------

// ---- Expand each stage's single authored recipe into 4 selectable items ----
// Rather than hand-authoring 4x the recipes in the content file, this
// generates 3 named variants from each stage's original recipe: same tier,
// same craftsToAdvance/secondsPerCraft/mastery status, but each swaps in one
// different "flavor" component from the category's own material pool.
// Selection is INDEX-BASED, not random, so the same variants appear every
// time the page loads rather than reshuffling between sessions.
//
// Any variant that isn't the original ("Classic") item drops the stage's
// trade-good requirement, since the flavor component comes from the normal
// material pool - only the original recipe still requires the trade good at
// stages 5-6. This means a trade-gated stage has a real choice: barter for
// the trade good and make the Classic version, or find a different flavor
// material and make an alternate version without trading. Intentional side
// effect of generating variants this way, not a bug.

function expandTechTreeStagesToFourItems() {
  Object.entries(techTree).forEach(([categoryKey, categoryData]) => {
    if (!categoryData.paths) return; // skip capstone-only categories, no unique data

    // Gather this category's full material pool from the ORIGINAL
    // single-recipe stage data, before any stage gets mutated below.
    const materialPool = new Set();
    Object.values(categoryData.paths).forEach((pathData) => {
      pathData.stages.forEach((stage) => {
        stage.components.forEach((componentName) => {
          const isTradeGood = componentName.startsWith("trade");
          const isRareDrop = rareDropMaterials.includes(componentName);
          if (!isTradeGood && !isRareDrop) materialPool.add(componentName);
        });
      });
    });
    const materialPoolArray = [...materialPool];
    const modifiers = categoryVariantModifiers[categoryKey] || ["Alternate", "Variant", "Special", "Custom"];

    Object.values(categoryData.paths).forEach((pathData) => {
      pathData.stages.forEach((stage) => {
        const classicItem = { name: stage.name, components: [...stage.components] };
        const items = [classicItem];

        for (let variantIndex = 0; variantIndex < 3; variantIndex++) {
          // Skip any modifier that's already a word in the base name (e.g.
          // don't turn "Spiced Festival Loaf" into "Spiced Spiced Festival Loaf").
          const usableModifiers = modifiers.filter(
            (m) => !stage.name.toLowerCase().includes(m.toLowerCase())
          );
          const modifierPool = usableModifiers.length > 0 ? usableModifiers : modifiers;
          const modifier = modifierPool[variantIndex % modifierPool.length];

          const excluded = new Set(stage.components);
          const candidates = materialPoolArray.filter((name) => !excluded.has(name));
          const pickIndex = (variantIndex * 3 + stage.components.length) % Math.max(1, candidates.length);
          const flavorComponent = candidates.length > 0 ? candidates[pickIndex] : null;
          const variantComponents = flavorComponent
            ? [...stage.components.filter((c) => !c.startsWith("trade")), flavorComponent]
            : [...stage.components];

          items.push({ name: `${modifier} ${stage.name}`, components: variantComponents });
        }

        stage.items = items;
        delete stage.name;
        delete stage.components;
      });
    });
  });
}
expandTechTreeStagesToFourItems();

// ---- Lookup helpers used by any page's UI (game page, items page, etc) ----

// Every finished item name across every category/path/stage/item variant,
// mapped back to which category/path/stageIndex it belongs to.
function getFinishedItemLookup() {
  const lookup = {};
  Object.entries(techTree).forEach(([categoryKey, categoryData]) => {
    if (!categoryData.paths) return;
    Object.entries(categoryData.paths).forEach(([pathKey, pathData]) => {
      pathData.stages.forEach((stage, stageIndex) => {
        stage.items.forEach((item) => {
          lookup[item.name] = { categoryKey, pathKey, stageIndex };
        });
      });
    });
  });
  return lookup;
}

// All base materials (non-trade-good components) used anywhere in a given
// category - lets the "other vendors" panel show what's buyable there.
function getBaseMaterialsForCategory(categoryKey) {
  const categoryData = techTree[categoryKey];
  if (!categoryData || !categoryData.paths) return [];
  const materials = new Set();
  Object.values(categoryData.paths).forEach((pathData) => {
    pathData.stages.forEach((stage) => {
      stage.items.forEach((item) => {
        item.components.forEach((componentName) => {
          const isTradeGood = componentName.startsWith("trade");
          const isRareDrop = rareDropMaterials.includes(componentName);
          if (!isTradeGood && !isRareDrop) materials.add(componentName);
        });
      });
    });
  });
  return [...materials];
}
