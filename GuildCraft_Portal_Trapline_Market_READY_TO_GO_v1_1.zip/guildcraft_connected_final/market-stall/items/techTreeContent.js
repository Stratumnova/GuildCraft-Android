// techTreeContent.js — CONTENT LAYER, not base engine.
// -----------------------------------------------------------------------------
// This is the swappable game-content file: the full specialization/crafting
// data. A second tech tree, a DLC-style content pack, or a stripped test
// tree would all just be alternate versions of THIS file - nothing in the
// base engine (in /base) needs to change to load a different one.
//
// CONTRACT this file must fulfill for the base engine to work:
//   - `const techTree`      - categories -> paths -> stages, each stage
//                              having { name, components, craftsToAdvance,
//                              secondsPerCraft, requiresTradeGood?,
//                              isMasteryStage? } in this RAW single-recipe
//                              shape. techTreeEngine.js (base) expands this
//                              into the 4-item-per-stage format at load time.
//   - `const baseMaterials`, `const tradeGoods`, `const rareDropMaterials`
//                            - flat arrays of material name strings
//   - `const categoryVariantModifiers` - category key -> array of 4 flavor
//                              words, used by the base engine's variant
//                              generator (falls back to generic words if a
//                              category key is missing here)
//
// Every category (Section 4/5 of the master doc) has master paths.
// Every master path has 6 stages, one authored recipe per stage - the base
// engine (techTreeEngine.js) expands each into 4 selectable items.
//
// PACING NOTE (for playtesting, Section 13 open item):
// craftsToAdvance x secondsPerCraft gives a rough active-time budget per stage.
// Stages 1-4 are meant to feel fast and satisfying. Stage 5 introduces a
// trade-good requirement (per Section 6, "some higher stages require trade,
// not money"). Stage 6 is the mastery stage - the one that flags the category
// complete (Section 4) and is meant to feel like a real finish line.
// Summed across a full path this lands around 2-2.5 hours of active play.
// Adjust the numbers below during playtesting - nothing here is final.
// -----------------------------------------------------------------------------

const techTree = {

  food: {
    label: "Food",
    paths: {

      bakery: {
        label: "Bakery",
        stages: [
          { name: "Flatbread", craftsToAdvance: 3, secondsPerCraft: 30,
            components: ["groundGrain", "water"] },
          { name: "Simple Loaf", craftsToAdvance: 4, secondsPerCraft: 45,
            components: ["groundGrain", "water", "yeastStarter"] },
          { name: "Seeded Loaf", craftsToAdvance: 5, secondsPerCraft: 75,
            components: ["groundGrain", "water", "yeastStarter", "wildSeeds"] },
          { name: "Honeyed Bread", craftsToAdvance: 6, secondsPerCraft: 120,
            components: ["groundGrain", "water", "yeastStarter", "wildHoney"] },
          { name: "Spiced Festival Loaf", craftsToAdvance: 7, secondsPerCraft: 180,
            components: ["groundGrain", "yeastStarter", "wildHoney", "tradeSpiceBundle"],
            requiresTradeGood: "tradeSpiceBundle" },
          { name: "Masterbaker's Harvest Loaf", craftsToAdvance: 8, secondsPerCraft: 240,
            components: ["groundGrain", "yeastStarter", "wildHoney", "tradeSpiceBundle", "rareHearthAsh"],
            requiresTradeGood: "tradeSpiceBundle", isMasteryStage: true },
        ],
      },

      meats: {
        label: "Meats",
        stages: [
          { name: "Salted Strip", craftsToAdvance: 3, secondsPerCraft: 30,
            components: ["rawMeat", "salt"] },
          { name: "Smoked Cut", craftsToAdvance: 4, secondsPerCraft: 45,
            components: ["rawMeat", "salt", "greenWood"] },
          { name: "Herb-Cured Joint", craftsToAdvance: 5, secondsPerCraft: 75,
            components: ["rawMeat", "salt", "wildHerbs"] },
          { name: "Spit-Roasted Haunch", craftsToAdvance: 6, secondsPerCraft: 120,
            components: ["rawMeat", "salt", "wildHerbs", "greenWood"] },
          { name: "Trader's Dried Ration", craftsToAdvance: 7, secondsPerCraft: 180,
            components: ["rawMeat", "salt", "tradePreservingSalts"],
            requiresTradeGood: "tradePreservingSalts" },
          { name: "Masterhunter's Feast Cut", craftsToAdvance: 8, secondsPerCraft: 240,
            components: ["rawMeat", "wildHerbs", "tradePreservingSalts", "rareGameBeast"],
            requiresTradeGood: "tradePreservingSalts", isMasteryStage: true },
        ],
      },

      stews: {
        label: "Stews",
        stages: [
          { name: "Broth", craftsToAdvance: 3, secondsPerCraft: 30,
            components: ["water", "rootVegetable"] },
          { name: "Simple Stew", craftsToAdvance: 4, secondsPerCraft: 45,
            components: ["water", "rootVegetable", "rawMeat"] },
          { name: "Hearty Stew", craftsToAdvance: 5, secondsPerCraft: 75,
            components: ["water", "rootVegetable", "rawMeat", "wildHerbs"] },
          { name: "Spiced Stew", craftsToAdvance: 6, secondsPerCraft: 120,
            components: ["water", "rootVegetable", "rawMeat", "wildHerbs", "wildSeeds"] },
          { name: "Feast Stew", craftsToAdvance: 7, secondsPerCraft: 180,
            components: ["rootVegetable", "rawMeat", "wildHerbs", "tradeSpiceBundle"],
            requiresTradeGood: "tradeSpiceBundle" },
          { name: "Legendary Cauldron Stew", craftsToAdvance: 8, secondsPerCraft: 240,
            components: ["rootVegetable", "rawMeat", "tradeSpiceBundle", "rareGameBeast"],
            requiresTradeGood: "tradeSpiceBundle", isMasteryStage: true },
        ],
      },

      brews: {
        label: "Brews",
        opposedWith: "provisions",
        stages: [
          { name: "Watered Grain Mash", craftsToAdvance: 3, secondsPerCraft: 30,
            components: ["groundGrain", "water"] },
          { name: "Simple Ale", craftsToAdvance: 4, secondsPerCraft: 45,
            components: ["groundGrain", "water", "yeastStarter"] },
          { name: "Herbed Ale", craftsToAdvance: 5, secondsPerCraft: 75,
            components: ["groundGrain", "yeastStarter", "wildHerbs"] },
          { name: "Honey Mead", craftsToAdvance: 6, secondsPerCraft: 120,
            components: ["yeastStarter", "wildHoney", "water"] },
          { name: "Trader's Reserve Brew", craftsToAdvance: 7, secondsPerCraft: 180,
            components: ["yeastStarter", "wildHoney", "tradeSpiceBundle"],
            requiresTradeGood: "tradeSpiceBundle" },
          { name: "Masterbrewer's Vintage", craftsToAdvance: 8, secondsPerCraft: 240,
            components: ["yeastStarter", "wildHoney", "tradeSpiceBundle", "rareHearthAsh"],
            requiresTradeGood: "tradeSpiceBundle", isMasteryStage: true },
        ],
      },

      provisions: {
        label: "Provisions",
        opposedWith: "brews",
        stages: [
          { name: "Dried Root", craftsToAdvance: 3, secondsPerCraft: 30,
            components: ["rootVegetable", "salt"] },
          { name: "Salted Ration Pack", craftsToAdvance: 4, secondsPerCraft: 45,
            components: ["rootVegetable", "salt", "rawMeat"] },
          { name: "Sealed Preserve Jar", craftsToAdvance: 5, secondsPerCraft: 75,
            components: ["rootVegetable", "salt", "wildHoney"] },
          { name: "Travel Ration Crate", craftsToAdvance: 6, secondsPerCraft: 120,
            components: ["rootVegetable", "rawMeat", "salt", "wildHerbs"] },
          { name: "Trader's Long-Haul Stock", craftsToAdvance: 7, secondsPerCraft: 180,
            components: ["rootVegetable", "rawMeat", "tradePreservingSalts"],
            requiresTradeGood: "tradePreservingSalts" },
          { name: "Masterprovisioner's Expedition Crate", craftsToAdvance: 8, secondsPerCraft: 240,
            components: ["rootVegetable", "tradePreservingSalts", "rareHearthAsh"],
            requiresTradeGood: "tradePreservingSalts", isMasteryStage: true },
        ],
      },
    },
  },

  blacksmith: {
    label: "Blacksmith",
    paths: {
      armor: {
        label: "Armor",
        stages: [
          { name: "Scrap Plate", craftsToAdvance: 3, secondsPerCraft: 40, components: ["rawOre", "leatherStrap"] },
          { name: "Banded Vest", craftsToAdvance: 4, secondsPerCraft: 60, components: ["ingot", "leatherStrap"] },
          { name: "Riveted Cuirass", craftsToAdvance: 5, secondsPerCraft: 90, components: ["ingot", "leatherStrap", "rivets"] },
          { name: "Reinforced Breastplate", craftsToAdvance: 6, secondsPerCraft: 140, components: ["ingot", "rivets", "temperedPlate"] },
          { name: "Trader's Vanguard Armor", craftsToAdvance: 7, secondsPerCraft: 200, components: ["temperedPlate", "rivets", "tradeAlloyIngot"], requiresTradeGood: "tradeAlloyIngot" },
          { name: "Masterplate of the Vanguard", craftsToAdvance: 8, secondsPerCraft: 260, components: ["temperedPlate", "tradeAlloyIngot", "rareMeteoricShard"], requiresTradeGood: "tradeAlloyIngot", isMasteryStage: true },
        ],
      },
      weapon: {
        label: "Weapon",
        stages: [
          { name: "Rough Blade", craftsToAdvance: 3, secondsPerCraft: 40, components: ["rawOre", "woodHandle"] },
          { name: "Honed Shortsword", craftsToAdvance: 4, secondsPerCraft: 60, components: ["ingot", "woodHandle"] },
          { name: "Balanced Longsword", craftsToAdvance: 5, secondsPerCraft: 90, components: ["ingot", "woodHandle", "sharpeningStone"] },
          { name: "Tempered Blade", craftsToAdvance: 6, secondsPerCraft: 140, components: ["temperedPlate", "woodHandle", "sharpeningStone"] },
          { name: "Trader's Edge", craftsToAdvance: 7, secondsPerCraft: 200, components: ["temperedPlate", "sharpeningStone", "tradeAlloyIngot"], requiresTradeGood: "tradeAlloyIngot" },
          { name: "Masterblade of the Forge", craftsToAdvance: 8, secondsPerCraft: 260, components: ["temperedPlate", "tradeAlloyIngot", "rareMeteoricShard"], requiresTradeGood: "tradeAlloyIngot", isMasteryStage: true },
        ],
      },
      toolOther: {
        label: "Tool / Other",
        stages: [
          { name: "Crude Hammer Head", craftsToAdvance: 3, secondsPerCraft: 40, components: ["rawOre", "woodHandle"] },
          { name: "Iron Pickaxe", craftsToAdvance: 4, secondsPerCraft: 60, components: ["ingot", "woodHandle"] },
          { name: "Balanced Tongs", craftsToAdvance: 5, secondsPerCraft: 90, components: ["ingot", "rivets"] },
          { name: "Reinforced Anvil Kit", craftsToAdvance: 6, secondsPerCraft: 140, components: ["ingot", "temperedPlate", "rivets"] },
          { name: "Trader's Toolset", craftsToAdvance: 7, secondsPerCraft: 200, components: ["temperedPlate", "tradeAlloyIngot"], requiresTradeGood: "tradeAlloyIngot" },
          { name: "Mastersmith's Toolkit", craftsToAdvance: 8, secondsPerCraft: 260, components: ["temperedPlate", "tradeAlloyIngot", "rareMeteoricShard"], requiresTradeGood: "tradeAlloyIngot", isMasteryStage: true },
        ],
      },
      armorWeaponCapstone: {
        label: "Armor/Weapon Master Capstone",
        gated: true, // unlocks knight-level gear; requires progress in armor+toolOther OR weapon+toolOther
        // Threshold is a STAGE reached, not full mastery - mastering either
        // prerequisite path would flag the whole Blacksmith category done
        // (Section 4) before the capstone could ever be chosen, so the gate
        // has to trigger on partial progress instead.
        unlockRequirement: {
          stageIndexThreshold: 3, // must have reached stage 4 (index 3) in both paths of a pair
          pairs: [["armor", "toolOther"], ["weapon", "toolOther"]],
        },
        stages: [
          { name: "Knight's Trial Piece", craftsToAdvance: 3, secondsPerCraft: 90, components: ["temperedPlate", "sharpeningStone", "rivets"] },
          { name: "Knight's Vanguard Set", craftsToAdvance: 4, secondsPerCraft: 120, components: ["temperedPlate", "tradeAlloyIngot"], requiresTradeGood: "tradeAlloyIngot" },
          { name: "Knight-Captain's Regalia", craftsToAdvance: 5, secondsPerCraft: 150, components: ["temperedPlate", "tradeAlloyIngot", "rareMeteoricShard"], requiresTradeGood: "tradeAlloyIngot" },
          { name: "Knight-Champion's Full Plate", craftsToAdvance: 6, secondsPerCraft: 180, components: ["tradeAlloyIngot", "rareMeteoricShard"], requiresTradeGood: "tradeAlloyIngot" },
          { name: "Warlord's Ceremonial Set", craftsToAdvance: 7, secondsPerCraft: 210, components: ["rareMeteoricShard", "tradeAlloyIngot"], requiresTradeGood: "tradeAlloyIngot" },
          { name: "Masterknight's Legendary Panoply", craftsToAdvance: 8, secondsPerCraft: 240, components: ["rareMeteoricShard", "tradeAlloyIngot"], requiresTradeGood: "tradeAlloyIngot", isMasteryStage: true },
        ],
      },
    },
  },

  alchemy: {
    label: "Alchemy",
    paths: {
      remedies: {
        label: "Remedies",
        stages: [
          { name: "Crushed Herb Paste", craftsToAdvance: 3, secondsPerCraft: 35, components: ["wildHerbs", "water"] },
          { name: "Basic Salve", craftsToAdvance: 4, secondsPerCraft: 55, components: ["wildHerbs", "water", "beeswax"] },
          { name: "Fever Tonic", craftsToAdvance: 5, secondsPerCraft: 85, components: ["wildHerbs", "waterlilyRoot"] },
          { name: "Restorative Draught", craftsToAdvance: 6, secondsPerCraft: 130, components: ["wildHerbs", "waterlilyRoot", "beeswax"] },
          { name: "Trader's Panacea", craftsToAdvance: 7, secondsPerCraft: 190, components: ["waterlilyRoot", "tradeRareBloom"], requiresTradeGood: "tradeRareBloom" },
          { name: "Masterhealer's Elixir", craftsToAdvance: 8, secondsPerCraft: 250, components: ["waterlilyRoot", "tradeRareBloom", "rareCrystalDew"], requiresTradeGood: "tradeRareBloom", isMasteryStage: true },
        ],
      },
      poisonsToxins: {
        label: "Poisons / Toxins",
        stages: [
          { name: "Bitter Extract", craftsToAdvance: 3, secondsPerCraft: 35, components: ["wildHerbs", "spiderVenomGland"] },
          { name: "Numbing Tincture", craftsToAdvance: 4, secondsPerCraft: 55, components: ["spiderVenomGland", "water"] },
          { name: "Weakening Draught", craftsToAdvance: 5, secondsPerCraft: 85, components: ["spiderVenomGland", "waterlilyRoot"] },
          { name: "Concentrated Toxin", craftsToAdvance: 6, secondsPerCraft: 130, components: ["spiderVenomGland", "waterlilyRoot", "beeswax"] },
          { name: "Trader's Blightbrew", craftsToAdvance: 7, secondsPerCraft: 190, components: ["spiderVenomGland", "tradeRareBloom"], requiresTradeGood: "tradeRareBloom" },
          { name: "Masterpoisoner's Reserve", craftsToAdvance: 8, secondsPerCraft: 250, components: ["spiderVenomGland", "tradeRareBloom", "rareCrystalDew"], requiresTradeGood: "tradeRareBloom", isMasteryStage: true },
        ],
      },
      enhancements: {
        label: "Enhancements",
        stages: [
          { name: "Minor Focus Draught", craftsToAdvance: 3, secondsPerCraft: 35, components: ["wildHerbs", "beeswax"] },
          { name: "Strength Tonic", craftsToAdvance: 4, secondsPerCraft: 55, components: ["wildHerbs", "waterlilyRoot"] },
          { name: "Swiftness Brew", craftsToAdvance: 5, secondsPerCraft: 85, components: ["waterlilyRoot", "beeswax"] },
          { name: "Greater Vigor Elixir", craftsToAdvance: 6, secondsPerCraft: 130, components: ["waterlilyRoot", "beeswax", "wildHerbs"] },
          { name: "Trader's Empowerment Brew", craftsToAdvance: 7, secondsPerCraft: 190, components: ["waterlilyRoot", "tradeRareBloom"], requiresTradeGood: "tradeRareBloom" },
          { name: "Masteralchemist's Apex Draught", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeRareBloom", "rareCrystalDew"], requiresTradeGood: "tradeRareBloom", isMasteryStage: true },
        ],
      },
      preservativesReagents: {
        label: "Preservatives / Reagents",
        stages: [
          { name: "Simple Fixative", craftsToAdvance: 3, secondsPerCraft: 35, components: ["beeswax", "water"] },
          { name: "Reagent Base", craftsToAdvance: 4, secondsPerCraft: 55, components: ["beeswax", "waterlilyRoot"] },
          { name: "Stabilizing Compound", craftsToAdvance: 5, secondsPerCraft: 85, components: ["beeswax", "waterlilyRoot", "wildHerbs"] },
          { name: "Long-Cure Reagent", craftsToAdvance: 6, secondsPerCraft: 130, components: ["waterlilyRoot", "wildHerbs", "beeswax"] },
          { name: "Trader's Preserving Draught", craftsToAdvance: 7, secondsPerCraft: 190, components: ["waterlilyRoot", "tradeRareBloom"], requiresTradeGood: "tradeRareBloom" },
          { name: "Masterreagent's Eternal Fixative", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeRareBloom", "rareCrystalDew"], requiresTradeGood: "tradeRareBloom", isMasteryStage: true },
        ],
      },
    },
  },

  carpenter: {
    label: "Carpenter",
    paths: {
      furniture: {
        label: "Furniture",
        stages: [
          { name: "Rough Stool", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawTimber", "rope"] },
          { name: "Simple Bench", craftsToAdvance: 4, secondsPerCraft: 50, components: ["plankWood", "rope"] },
          { name: "Joined Table", craftsToAdvance: 5, secondsPerCraft: 80, components: ["plankWood", "woodenPegs"] },
          { name: "Carved Cabinet", craftsToAdvance: 6, secondsPerCraft: 130, components: ["plankWood", "woodenPegs", "finishOil"] },
          { name: "Trader's Fine Dresser", craftsToAdvance: 7, secondsPerCraft: 190, components: ["plankWood", "tradeHardwoodPlank"], requiresTradeGood: "tradeHardwoodPlank" },
          { name: "Mastercarpenter's Heirloom Set", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeHardwoodPlank", "rareAncientBurl"], requiresTradeGood: "tradeHardwoodPlank", isMasteryStage: true },
        ],
      },
      construction: {
        label: "Construction",
        stages: [
          { name: "Wood Stake", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawTimber"] },
          { name: "Fence Panel", craftsToAdvance: 4, secondsPerCraft: 50, components: ["plankWood", "woodenPegs"] },
          { name: "Support Beam", craftsToAdvance: 5, secondsPerCraft: 80, components: ["plankWood", "rope"] },
          { name: "Reinforced Frame", craftsToAdvance: 6, secondsPerCraft: 130, components: ["plankWood", "woodenPegs", "rope"] },
          { name: "Trader's Truss Kit", craftsToAdvance: 7, secondsPerCraft: 190, components: ["plankWood", "tradeHardwoodPlank"], requiresTradeGood: "tradeHardwoodPlank" },
          { name: "Masterbuilder's Load-Bearing Frame", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeHardwoodPlank", "rareAncientBurl"], requiresTradeGood: "tradeHardwoodPlank", isMasteryStage: true },
        ],
      },
      toolsHandles: {
        label: "Tools / Handles",
        stages: [
          { name: "Rough Handle", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawTimber"] },
          { name: "Shaped Handle", craftsToAdvance: 4, secondsPerCraft: 50, components: ["plankWood"] },
          { name: "Balanced Tool Grip", craftsToAdvance: 5, secondsPerCraft: 80, components: ["plankWood", "finishOil"] },
          { name: "Reinforced Haft", craftsToAdvance: 6, secondsPerCraft: 130, components: ["plankWood", "woodenPegs", "finishOil"] },
          { name: "Trader's Precision Handle", craftsToAdvance: 7, secondsPerCraft: 190, components: ["plankWood", "tradeHardwoodPlank"], requiresTradeGood: "tradeHardwoodPlank" },
          { name: "Masterjoiner's Perfect Grip", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeHardwoodPlank", "rareAncientBurl"], requiresTradeGood: "tradeHardwoodPlank", isMasteryStage: true },
        ],
      },
      decorativeFineWoodwork: {
        label: "Decorative / Fine Woodwork",
        stages: [
          { name: "Simple Carving", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawTimber"] },
          { name: "Painted Trim", craftsToAdvance: 4, secondsPerCraft: 50, components: ["plankWood", "finishOil"] },
          { name: "Inlaid Panel", craftsToAdvance: 5, secondsPerCraft: 80, components: ["plankWood", "woodenPegs", "finishOil"] },
          { name: "Ornate Frame", craftsToAdvance: 6, secondsPerCraft: 130, components: ["plankWood", "finishOil", "woodenPegs"] },
          { name: "Trader's Gilded Screen", craftsToAdvance: 7, secondsPerCraft: 190, components: ["plankWood", "tradeHardwoodPlank"], requiresTradeGood: "tradeHardwoodPlank" },
          { name: "Masterartisan's Showpiece", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeHardwoodPlank", "rareAncientBurl"], requiresTradeGood: "tradeHardwoodPlank", isMasteryStage: true },
        ],
      },
    },
  },

  tannery: {
    label: "Tannery (Leather)",
    paths: {
      armor: {
        label: "Armor",
        stages: [
          { name: "Raw Hide Wrap", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawHide"] },
          { name: "Cured Leather Vest", craftsToAdvance: 4, secondsPerCraft: 50, components: ["curedLeather"] },
          { name: "Stitched Jerkin", craftsToAdvance: 5, secondsPerCraft: 80, components: ["curedLeather", "sinewThread"] },
          { name: "Reinforced Leather Cuirass", craftsToAdvance: 6, secondsPerCraft: 130, components: ["curedLeather", "sinewThread", "boneToggles"] },
          { name: "Trader's Ranger Coat", craftsToAdvance: 7, secondsPerCraft: 190, components: ["curedLeather", "tradeExoticHide"], requiresTradeGood: "tradeExoticHide" },
          { name: "Mastertanner's Duskhide Armor", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeExoticHide", "rareBeastPelt"], requiresTradeGood: "tradeExoticHide", isMasteryStage: true },
        ],
      },
      goods: {
        label: "Goods",
        stages: [
          { name: "Hide Pouch", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawHide"] },
          { name: "Leather Satchel", craftsToAdvance: 4, secondsPerCraft: 50, components: ["curedLeather", "sinewThread"] },
          { name: "Traveler's Pack", craftsToAdvance: 5, secondsPerCraft: 80, components: ["curedLeather", "sinewThread", "boneToggles"] },
          { name: "Reinforced Saddlebag", craftsToAdvance: 6, secondsPerCraft: 130, components: ["curedLeather", "boneToggles"] },
          { name: "Trader's Merchant Pack", craftsToAdvance: 7, secondsPerCraft: 190, components: ["curedLeather", "tradeExoticHide"], requiresTradeGood: "tradeExoticHide" },
          { name: "Mastertanner's Grand Trunk", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeExoticHide", "rareBeastPelt"], requiresTradeGood: "tradeExoticHide", isMasteryStage: true },
        ],
      },
      bindingsCordage: {
        label: "Bindings / Cordage",
        stages: [
          { name: "Rawhide Strip", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawHide"] },
          { name: "Braided Cord", craftsToAdvance: 4, secondsPerCraft: 50, components: ["curedLeather"] },
          { name: "Waxed Binding", craftsToAdvance: 5, secondsPerCraft: 80, components: ["curedLeather", "sinewThread"] },
          { name: "Reinforced Rigging Rope", craftsToAdvance: 6, secondsPerCraft: 130, components: ["curedLeather", "sinewThread", "boneToggles"] },
          { name: "Trader's Tension Cord", craftsToAdvance: 7, secondsPerCraft: 190, components: ["sinewThread", "tradeExoticHide"], requiresTradeGood: "tradeExoticHide" },
          { name: "Masterbinder's Unbreakable Line", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeExoticHide", "rareBeastPelt"], requiresTradeGood: "tradeExoticHide", isMasteryStage: true },
        ],
      },
      footwearApparel: {
        label: "Footwear / Apparel",
        stages: [
          { name: "Wrapped Foot Hide", craftsToAdvance: 3, secondsPerCraft: 30, components: ["rawHide"] },
          { name: "Simple Sandals", craftsToAdvance: 4, secondsPerCraft: 50, components: ["curedLeather", "sinewThread"] },
          { name: "Stitched Boots", craftsToAdvance: 5, secondsPerCraft: 80, components: ["curedLeather", "sinewThread", "boneToggles"] },
          { name: "Traveler's Cloak", craftsToAdvance: 6, secondsPerCraft: 130, components: ["curedLeather", "boneToggles"] },
          { name: "Trader's Fine Boots", craftsToAdvance: 7, secondsPerCraft: 190, components: ["curedLeather", "tradeExoticHide"], requiresTradeGood: "tradeExoticHide" },
          { name: "Mastertanner's Duskwalker Boots", craftsToAdvance: 8, secondsPerCraft: 250, components: ["tradeExoticHide", "rareBeastPelt"], requiresTradeGood: "tradeExoticHide", isMasteryStage: true },
        ],
      },
    },
  },

  masterMerchantKing: {
    label: "Master Merchant King",
    isCapstone: true, // unlocks only after all five base categories are each mastered once (Section 4)
    // In a Merchant King run, the player gets access to all five trees above simultaneously
    // rather than a separate tree of its own. No unique stage data needed here.
  },
};

// Base materials referenced above as "components" - what an NPC sells at the
// start (Section 6), before any crafting has happened. Named for clarity.
const baseMaterials = [
  "groundGrain", "water", "yeastStarter", "wildSeeds", "wildHoney", "rootVegetable",
  "rawMeat", "salt", "wildHerbs", "greenWood",
  "rawOre", "ingot", "woodHandle", "leatherStrap", "rivets", "temperedPlate", "sharpeningStone",
  "wildHerbs", "beeswax", "waterlilyRoot", "spiderVenomGland",
  "rawTimber", "plankWood", "rope", "woodenPegs", "finishOil",
  "rawHide", "curedLeather", "sinewThread", "boneToggles",
];

// Trade-only goods (Section 6: "some higher stages require trade, not money").
// Cannot be bought with currency - must be acquired via trade leverage.
const tradeGoods = [
  "tradeSpiceBundle", "tradePreservingSalts", "tradeAlloyIngot",
  "tradeRareBloom", "tradeHardwoodPlank", "tradeExoticHide",
];

// Rare drop-tier materials - only obtainable via the drop mechanism (Section 9/10),
// gating the final mastery stage of each path behind actual play, not just grinding.
const rareDropMaterials = [
  "rareHearthAsh", "rareGameBeast", "rareMeteoricShard", "rareCrystalDew",
  "rareAncientBurl", "rareBeastPelt",
];

const categoryVariantModifiers = {
  food: ["Herbed", "Spiced", "Sweetened", "Smoked"],
  blacksmith: ["Reinforced", "Balanced", "Etched", "Polished"],
  alchemy: ["Concentrated", "Diluted", "Refined", "Infused"],
  carpenter: ["Carved", "Lacquered", "Joined", "Inlaid"],
  tannery: ["Stitched", "Oiled", "Braided", "Tooled"],
};
