// crafting.js
// -----------------------------------------------------------------------------
// Assembly-based crafting (Section 7 of the master doc): a finished item
// needs multiple named components, not one material leveling up.
//
// AI BUILD: stage progress accumulation delegates to MilestoneCounter
// (GuildCraft toolkit) instead of hand-rolled +=1/>= checks. player state
// (craftsCompletedThisStage) stays the actual source of truth for save/
// switch-path persistence - a throwaway counter is built from it each call
// so the accumulation math itself isn't reimplemented here. All notable
// events route through EventConsole instead of console.log.
// -----------------------------------------------------------------------------

const crafting = {

  hasFiredFirstSale: false, // tracked locally; real check should come from account data later

  attemptCraft(itemIndex) {
    const stageData = player.getCurrentStageData();
    if (!stageData) return false;
    const itemData = stageData.items[itemIndex];
    if (!itemData) return false;

    if (!player.hasComponents(itemData.components)) {
      EventConsole.emit(
        "CRAFTING", `Craft failed: ${itemData.name}`, "missing components",
        { item: itemData.name, needed: itemData.components }, "state"
      );
      return false;
    }

    player.consumeComponents(itemData.components);
    player.addToInventory(itemData.name, 1);

    const counter = MilestoneCounter.create(
      `${player.chosenCategory}:${player.chosenPath}:stage${player.currentStageIndex}`,
      { cap: stageData.craftsToAdvance }
    );
    counter.count = player.craftsCompletedThisStage;
    const result = MilestoneCounter.collect(counter, 1);
    player.craftsCompletedThisStage = counter.count;

    EventConsole.emit(
      "CRAFTING", `Crafted ${itemData.name}`,
      `${player.craftsCompletedThisStage}/${stageData.craftsToAdvance} toward stage advance`,
      { item: itemData.name, progress: player.craftsCompletedThisStage, cap: stageData.craftsToAdvance },
      "milestone"
    );

    if (result.capped) {
      specialization.advanceStage();
    }

    return true;
  },

  // Base materials are bought from an NPC matching the player's own path,
  // capped to their unlocked stage (Section 6). This is a simplified stand-in:
  // real NPC-matching logic can layer on top once NPC identity data exists.
  buyBaseMaterial(materialName, costInStallCurrency) {
    if (player.floppyBalance < costInStallCurrency) {
      EventConsole.emit(
        "CRAFTING", `Buy failed: ${materialName}`, "not enough stall-local floppies",
        { material: materialName, cost: costInStallCurrency }, "state"
      );
      return false;
    }
    player.floppyBalance -= costInStallCurrency;
    player.addToInventory(materialName, 1);
    return true;
  },

  // Called when an NPC successfully buys a finished item off a display
  // table. stallId defaults to "player" - other stalls (otherStalls.js)
  // pass their own id so all sales land in one shared log (Section: dev log).
  async recordSale(itemName, salePrice, stallId = "player") {
    if (typeof salesLog !== "undefined") salesLog.logSale(stallId, itemName, salePrice);

    EventConsole.emit(
      "SALE", `${itemName} sold @ ${salePrice}`, `stall: ${stallId}`,
      { item: itemName, price: salePrice, stallId }, "milestone"
    );

    if (stallId !== "player") return; // only the player's own economy affects their floppies/drops

    if (typeof marketBusiness !== "undefined" && marketBusiness.state.owned) marketBusiness.depositSale(salePrice,itemName);
    else player.floppyBalance += salePrice;

    if (!this.hasFiredFirstSale) {
      this.hasFiredFirstSale = true;
      await backendApi.reportDrop(saveState.currentPlayerId, "firstSale", {
        item: itemName,
        price: salePrice,
      });
      await saveState.saveNow(player);
    }
  },
};
