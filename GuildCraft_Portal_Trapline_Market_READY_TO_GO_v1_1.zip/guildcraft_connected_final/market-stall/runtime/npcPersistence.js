// npcPersistence.js — persistent social state for recurring Market Stall people.
// Stores game-state relationships/memories only. It does not create lore facts.
const NpcPersistence = {
  key(playerId){ return `marketNpcSocial_${playerId || "player_1"}`; },
  load(playerId){ try { return JSON.parse(localStorage.getItem(this.key(playerId)) || "{}") || {}; } catch { return {}; } },
  apply(unit, saved){
    if(!saved) return unit;
    if(saved.voice) unit.voice=saved.voice;
    if(saved.goals) unit.goals=saved.goals;
    if(saved.relationships) unit.relationships=saved.relationships;
    if(saved.memoryRecords) unit.memoryRecords=saved.memoryRecords.slice(-40);
    if(saved.knowledgeLayers) unit.knowledgeLayers=saved.knowledgeLayers;
    if(saved.preferredCategory) unit.preferredCategory=saved.preferredCategory;
    return unit;
  },
  snapshot(unit){ return {name:unit.name||null,voice:unit.voice,goals:unit.goals,relationships:unit.relationships,memoryRecords:(unit.memoryRecords||[]).slice(-40),knowledgeLayers:unit.knowledgeLayers,preferredCategory:unit.preferredCategory||null}; },
  saveAll(playerId){
    if(typeof npc === "undefined") return;
    const out={}; npc.list.filter(u=>u.name).forEach(u=>out[u.id]=this.snapshot(u));
    try { localStorage.setItem(this.key(playerId),JSON.stringify(out)); } catch(e){ console.warn("NPC social save failed",e); }
  }
};
