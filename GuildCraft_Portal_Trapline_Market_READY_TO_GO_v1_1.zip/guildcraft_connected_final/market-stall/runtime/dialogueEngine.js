// dialogueEngine.js — compact browser runtime mined from GuildCraft voice/template patterns.
// Dialogue describes live Market Stall simulation state. It does not promote Plan material to Current lore.
const DialogueEngine = {
  templates: {
    greeting:["{greeting}, {address}.","{filler}. Didn't expect to see you {place_clause}.","{greeting}. You holding up?"],
    trade:["I'll give you {offer} for {want}.","{want} for {offer}. Fair?","{filler}, I need {want}. I can trade {offer}."],
    refusal:["No. {reason_clause}.","{filler}, I can't do that. {reason_clause}.","Not happening. {boundary_clause}."]
  },
  voices: {
    old_neighbor:{fillers:["well","anyway"], greeting:"Morning", address:"neighbor", formal:false},
    hardcase:{fillers:["listen"], greeting:"Yeah", address:"trader", formal:false},
    plain_survivor:{fillers:["look","well"], greeting:"Hey", address:"friend", formal:false},
    nervous_scavenger:{fillers:["uh","maybe","look"], greeting:"Hey", address:"friend", formal:false},
    educated_medic:{fillers:["however"], greeting:"Good day", address:"merchant", formal:true}
  },
  pick(a){ return a[Math.floor(Math.random()*a.length)]; },
  profile(unit){ return this.voices[unit.voice] || this.voices.plain_survivor; },
  fill(template, vars){ return template.replace(/\{(\w+)\}/g,(_,k)=>vars[k] ?? ""); },
  greeting(unit){
    const v=this.profile(unit), r=NpcSocial.relationship(unit,"player");
    const place=r.TRUST>=3 ? "back here" : "at this stall";
    return this.fill(this.pick(this.templates.greeting),{greeting:v.greeting,address:v.address,filler:this.pick(v.fillers),place_clause:place});
  },
  trade(unit,bought,itemName,price){
    const v=this.profile(unit), r=NpcSocial.relationship(unit,"player");
    if(!bought){
      const reason = r.NEED>3 ? `I need ${itemName}, just not at ${price} floppies` : `Not at ${price} floppies`;
      return this.fill(this.pick(this.templates.refusal),{filler:this.pick(v.fillers),reason_clause:reason,boundary_clause:"Try me another time"});
    }
    const want=itemName, offer=`${price} floppies`;
    let line=this.fill(this.pick(this.templates.trade),{filler:this.pick(v.fillers),want,offer});
    if(r.TRUST>=4) line += v.formal ? " We have dealt well before." : " You deal straight.";
    return line;
  }
};
