// npcSocial.js — mined from GuildCraft actor/relationship/knowledge patterns.
// This is game simulation support, not a declaration of new Stratumnova lore.
const NpcSocial = {
  axes: ["LIKE","TRUST","FEAR","DEBT","LOYALTY","SUSPICION","RESPECT","NEED"],
  voices: ["old_neighbor","hardcase","plain_survivor","nervous_scavenger","educated_medic"],
  clamp(n){ return Math.max(-10, Math.min(10, Number(n)||0)); },
  hydrate(unit, index=0){
    unit.voice = unit.voice || this.voices[index % this.voices.length];
    unit.goals = unit.goals || ["trade"];
    unit.memoryRecords = unit.memoryRecords || [];
    unit.memoryLimit = unit.memoryLimit || 40;
    unit.relationships = unit.relationships || {};
    unit.knowledgeLayers = unit.knowledgeLayers || {worldTruth:[],publicLore:[],factionLore:[],npcKnowledge:[],npcBelief:[],rumor:[],lie:[]};
    unit.currentSpeech = unit.currentSpeech || "";
    unit.speechSeconds = unit.speechSeconds || 0;
    this.relationship(unit,"player");
    return unit;
  },
  relationship(unit, otherId){
    const base={LIKE:0,TRUST:0,FEAR:0,DEBT:0,LOYALTY:0,SUSPICION:0,RESPECT:0,NEED:0};
    unit.relationships[otherId]={...base,...(unit.relationships[otherId]||{})};
    return unit.relationships[otherId];
  },
  remember(unit, kind, data={}){
    const rec={time:Date.now(),kind,...data};
    unit.memoryRecords.push(rec);
    if(unit.memoryRecords.length>unit.memoryLimit) unit.memoryRecords.splice(0,unit.memoryRecords.length-unit.memoryLimit);
  },
  onPurchase(unit, bought, itemName, price){
    const r=this.relationship(unit,"player");
    if(bought){ r.TRUST=this.clamp(r.TRUST+1); r.LIKE=this.clamp(r.LIKE+1); r.RESPECT=this.clamp(r.RESPECT+1); }
    else { r.NEED=this.clamp(r.NEED+1); }
    this.remember(unit,bought?"PURCHASE":"PASS",{itemName,price});
    this.say(unit, (typeof DialogueEngine !== "undefined") ? DialogueEngine.trade(unit,bought,itemName,price) : this.tradeLine(unit,bought,itemName,price));
    if(typeof NpcPersistence!=="undefined" && unit.name && typeof saveState!=="undefined") NpcPersistence.saveAll(saveState.currentPlayerId);
  },
  tradeLine(unit,bought,itemName,price){
    const p=unit.personalityKey;
    if(bought){
      if(p==="bargainHunter") return `I'll take ${itemName}. ${price} floppies still bites.`;
      if(p==="bigSpender") return `${itemName}. Done. ${price} floppies.`;
      if(p==="impulsive") return `${itemName}? Mine. ${price} floppies.`;
      return `${itemName} for ${price} floppies. Fair.`;
    }
    if(p==="bargainHunter") return `Not at ${price} floppies.`;
    if(p==="bigSpender") return `Not what I need today.`;
    if(p==="impulsive") return `No. Something else.`;
    return `I'll pass.`;
  },
  say(unit,text){ unit.currentSpeech=text; unit.speechSeconds=3.2; },
  update(delta){
    if(typeof npc === "undefined") return;
    npc.list.forEach(unit=>{ if(unit.speechSeconds>0){unit.speechSeconds-=delta; if(unit.speechSeconds<=0) unit.currentSpeech="";} });
  }
};
