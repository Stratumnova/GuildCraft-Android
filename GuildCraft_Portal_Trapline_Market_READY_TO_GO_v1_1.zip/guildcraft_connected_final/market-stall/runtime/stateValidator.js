const StateValidator={
  report:[],
  check(label,ok,detail=""){this.report.push({label,ok:!!ok,detail});return !!ok;},
  run(){this.report=[];
    this.check("player exists",typeof player!=="undefined"&&!!player);
    this.check("floppy balance",typeof player!=="undefined"&&typeof player.floppyBalance==="number"&&Number.isFinite(player.floppyBalance),String(typeof player!=="undefined"?player.floppyBalance:"missing"));
    this.check("no live agaget field",typeof player!=="undefined"&&!("agagetBalance" in player));
    this.check("grid 32x32",typeof grid!=="undefined"&&grid.columns===32&&grid.rows===32);
    this.check("renderer split",typeof DebugRenderer!=="undefined"&&typeof WorldRenderer!=="undefined"&&typeof RendererManager!=="undefined");
    this.check("named NPC social state",typeof npc!=="undefined"&&Array.isArray(npc.list)&&npc.list.every(n=>n.id&&n.relationships&&n.memory&&n.knowledgeLayers));
    this.check("Portal Player Card runtime",typeof PortalRuntime!=="undefined"&&PortalRuntime.SCHEMA==="guildcraft.portal.snapshot");
    this.check("single portable snapshot",typeof PortalRuntime?.exportCode==="function"&&typeof PortalRuntime?.importCode==="function");
    this.check("player stall simulation",typeof marketBusiness!=="undefined"&&typeof marketBusiness.collectTill==="function");
    this.check("Market does not gather Wild resources",typeof worker!=="undefined"&&worker.rollWildLoot()===null);
    this.check("NPC crafter service",typeof crafterNpc!=="undefined"&&typeof crafterNpc.craft==="function");
    this.check("three roaming market actors",typeof marketActors!=="undefined"&&Object.keys(marketActors.state||{}).length===3);
    this.check("save snapshot builder",typeof saveState!=="undefined"&&typeof saveState.buildSaveSnapshot==="function");
    this.check("shared account migration",typeof AccountMigration!=="undefined"&&typeof AccountMigration.migrateTimesheet==="function"&&AccountMigration.CURRENT_SCHEMA>=2);
    const failures=this.report.filter(x=>!x.ok); return {ok:failures.length===0,checks:this.report.slice(),failures};
  }
};
