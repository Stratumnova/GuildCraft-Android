# GuildCraft Connected Rooms v1.1 — Targeted Fix Report

## User-authorized behavior preserved

The following two behaviors were intentionally **not changed**:

1. **Market stall till persistence:** uncollected stall income may remain in the browser/session-backed Market till indefinitely. It remains locked to the Market stall, is excluded from the portable Player Card/snapshot, and does not affect the player's shared Portal floppy balance until the player physically returns to the stall and collects it. Losing the browser/session can therefore lose uncollected till income.
2. **Local room state versus portable snapshot precedence:** the current hybrid behavior remains in place for observation/testing. This pass does not make imported Portal room state override existing local room saves.

## Fixes applied

### 1. Black Cottontail rumor is now genuinely one-shot

The Wild runner now uses separate armed/pending/delivered state. Catching the qualifying hidden cottontail arms the rumor once. The next qualifying talk returns exactly:

`did you hear someone found the Black Cottontail?`

After that talk, the pending flag clears and subsequent conversations return normal Wild-run comparison dialogue. The hash audit remains:

`f7c47e95440539c7844fdbb96dca087d9bbf5f0fbea80a3a8670438a7a83b87f`

A small compatibility normalization was added for older Market actor saves where `blackLineFired` existed before the new pending/delivered fields.

### 2. Old player-crafting button copy removed

The specialization-order button no longer says `Craft <item>`. It now says:

`Ask Ada to make <item>`

The progress text was also changed from `crafted` to `completed orders`, keeping Market manufacturing framed as an NPC service rather than Trapline/player manufacturing.

## Verification

- All JavaScript files: `node --check` PASS
- All JSON files parse PASS
- Local HTML `src` / `href` references PASS
- One-shot Black Cottontail runtime regression PASS
  - rumor arms after the hidden capture flag
  - exact line returned on first talk
  - second talk does not repeat it
  - pending flag clears
  - delivered flag sets
  - delivery audit emitted exactly once
- Market till session-backed persistence remains present PASS
- Portable snapshot still strips Market till PASS
- Ada order wording present and old `Craft <item>` button wording absent PASS

## Scope

No change was made to Portal snapshot/local-save precedence or stall-till persistence beyond confirming that the user's intended current behavior remains intact.
