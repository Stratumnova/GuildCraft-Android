// playerCard.js — BASE LAYER, reusable across any page.
// -----------------------------------------------------------------------------
// Fetches and renders the Timesheet / player card (contract Section 1/3 -
// see timesheet-backend-contract.md). Purely generic rendering - it only
// knows the universal shape `getPlayerAccount()` returns, nothing about
// this specific game. Any page with backendApi.js loaded can drop this in
// with a single call.
// -----------------------------------------------------------------------------

const playerCard = {
  async renderInto(elementId, playerId) {
    const container = document.getElementById(elementId);
    if (!container) return;
    container.innerHTML = "<p>Loading player card...</p>";

    const account = await backendApi.getPlayerAccount(playerId);

    const traitsHtml = account.traits.length
      ? account.traits.map((trait) => `<span class="traitTag">${trait}</span>`).join(" ")
      : "<em>none yet</em>";

    const saveEntries = Object.values(account.activeSaves || {});
    const savesHtml = saveEntries.length
      ? saveEntries.map((save) =>
          `<p><strong>${save.gameId}</strong>: ${save.summary}<br>
           <small>last played ${new Date(save.lastPlayed).toLocaleString()}</small></p>`
        ).join("")
      : "<p><em>No active game saves yet.</em></p>";

    container.innerHTML = `
      <h3>${account.avatarName}</h3>
      <p>Floppies: ${account.floppyBalance || 0}</p>
      <p>Traits: ${traitsHtml}</p>
      <h4>Active Saves Across Games</h4>
      ${savesHtml}
    `;
  },
};
