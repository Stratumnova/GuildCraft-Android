# Trapline Survival v1.6

The Wild resource/survival room. 192×192 simulation, schema 11, ecology, time-of-day species, hunting/trapping/gathering, live specimens, camps, survival, ground-drop overflow with 24-game-hour despawn, and Portal Player Card continuity.

Normal weapons, traps, bags, prepared food and other manufactured field goods are obtained in Market. Trapline does not run a manufacturing workshop.
