// populationPools.js — regional population authority for the 192×192 Wild.
// Visible animals are representatives. These regional stocks are the world truth.
const populationPools = {
  regionSize: 16,
  regionColumns: 12,
  regionRows: 12,
  regions: {}, // speciesKey -> array of regional stocks
  accumulator: 0,

  regionIndexFor(column, row) {
    const rx = Math.max(0, Math.min(this.regionColumns - 1, Math.floor(column / this.regionSize)));
    const ry = Math.max(0, Math.min(this.regionRows - 1, Math.floor(row / this.regionSize)));
    return rx + ry * this.regionColumns;
  },

  regionBounds(index) {
    const rx = index % this.regionColumns;
    const ry = Math.floor(index / this.regionColumns);
    return {
      left: rx * this.regionSize,
      top: ry * this.regionSize,
      right: Math.min(grid.columns - 1, (rx + 1) * this.regionSize - 1),
      bottom: Math.min(grid.rows - 1, (ry + 1) * this.regionSize - 1),
    };
  },

  habitatSuitability(species, index) {
    const b = this.regionBounds(index);
    let suitable = 0;
    let samples = 0;
    for (let y = b.top; y <= b.bottom; y += 4) {
      for (let x = b.left; x <= b.right; x += 4) {
        const tile = ecologyField.get(x, y);
        if (!tile) continue;
        samples += 1;
        if (species.habitatTags.includes(tile.habitat)) suitable += 1;
      }
    }
    return samples ? suitable / samples : 0;
  },

  setup(savedState = null) {
    this.regions = {};
    const regionCount = this.regionColumns * this.regionRows;
    Object.entries(speciesContent).forEach(([speciesKey, species]) => {
      const weights = new Array(regionCount).fill(0).map((_, i) => Math.max(0.02, this.habitatSuitability(species, i)));
      const totalWeight = weights.reduce((a, b) => a + b, 0) || 1;
      this.regions[speciesKey] = weights.map((weight, index) => {
        const capacity = Math.max(0.25, species.populationCapacity * (weight / totalWeight));
        const saved = savedState && savedState[speciesKey] && savedState[speciesKey][index];
        return {
          capacity,
          stock: saved && Number.isFinite(saved.stock) ? Math.max(0, Math.min(capacity, saved.stock)) : capacity * (0.62 + Math.random() * 0.28),
        };
      });
    });
  },

  snapshot() {
    const out = {};
    Object.entries(this.regions).forEach(([speciesKey, regions]) => {
      out[speciesKey] = regions.map((r) => ({ stock: Number(r.stock.toFixed(4)) }));
    });
    return out;
  },

  getRegion(speciesKey, column, row) {
    const list = this.regions[speciesKey];
    return list ? list[this.regionIndexFor(column, row)] : null;
  },

  getLocalPopulationFraction(speciesKey, column, row) {
    const region = this.getRegion(speciesKey, column, row);
    return region && region.capacity > 0 ? region.stock / region.capacity : 0;
  },

  getPopulationFraction(speciesKey, column = null, row = null) {
    if (Number.isFinite(column) && Number.isFinite(row)) return this.getLocalPopulationFraction(speciesKey, column, row);
    const regions = this.regions[speciesKey] || [];
    const stock = regions.reduce((sum, r) => sum + r.stock, 0);
    const capacity = regions.reduce((sum, r) => sum + r.capacity, 0);
    return capacity > 0 ? stock / capacity : 0;
  },

  attemptCatch(speciesKey, column, row) {
    const region = this.getRegion(speciesKey, column, row);
    if (!region || region.stock < 1) return false;
    region.stock -= 1;
    return true;
  },

  removeFromRegion(speciesKey, column, row, quantity = 1) {
    const region = this.getRegion(speciesKey, column, row);
    if (!region) return false;
    region.stock = Math.max(0, region.stock - Math.max(0, quantity));
    return true;
  },

  sampleRegionConditions(index) {
    const b = this.regionBounds(index);
    let food = 0, foodCap = 0, danger = 0, samples = 0;
    for (let y = b.top + 2; y <= b.bottom; y += 5) {
      for (let x = b.left + 2; x <= b.right; x += 5) {
        const tile = ecologyField.get(x, y);
        if (!tile) continue;
        food += tile.foodStock;
        foodCap += tile.foodCapacity;
        danger += tile.danger;
        samples += 1;
      }
    }
    return { foodFraction: foodCap > 0 ? food / foodCap : 0.4, danger: samples ? danger / samples : 0 };
  },

  backgroundTick() {
    const rabbits = this.regions.rabbit || [];
    const deer = this.regions.deer || [];
    const wolves = this.regions.wolf || [];
    const count = this.regionColumns * this.regionRows;

    for (let i = 0; i < count; i++) {
      const conditions = this.sampleRegionConditions(i);
      const rabbit = rabbits[i], deerRegion = deer[i], wolf = wolves[i];
      const rabbitFrac = rabbit ? rabbit.stock / Math.max(.001, rabbit.capacity) : 0;
      const deerFrac = deerRegion ? deerRegion.stock / Math.max(.001, deerRegion.capacity) : 0;
      const wolfFrac = wolf ? wolf.stock / Math.max(.001, wolf.capacity) : 0;

      if (rabbit) {
        const births = 0.11 * conditions.foodFraction * Math.max(0, 1 - rabbitFrac) * rabbit.capacity;
        const losses = 0.014 * rabbit.stock + 0.035 * wolfFrac * rabbit.stock + conditions.danger * 0.002 * rabbit.stock;
        rabbit.stock = Math.max(0, Math.min(rabbit.capacity, rabbit.stock + births - losses));
      }
      if (deerRegion) {
        const births = 0.045 * conditions.foodFraction * Math.max(0, 1 - deerFrac) * deerRegion.capacity;
        const losses = 0.007 * deerRegion.stock + 0.018 * wolfFrac * deerRegion.stock + conditions.danger * 0.0015 * deerRegion.stock;
        deerRegion.stock = Math.max(0, Math.min(deerRegion.capacity, deerRegion.stock + births - losses));
      }
      if (wolf) {
        const preySupport = Math.min(1, rabbitFrac * .75 + deerFrac * .55);
        const births = 0.018 * preySupport * Math.max(0, 1 - wolfFrac) * wolf.capacity;
        const losses = (0.009 + Math.max(0, .28 - preySupport) * .05) * wolf.stock;
        wolf.stock = Math.max(0, Math.min(wolf.capacity, wolf.stock + births - losses));
      }

      // Remaining species use their own regen profile and habitat food pressure.
      Object.entries(speciesContent).forEach(([key, species]) => {
        if (["rabbit","deer","wolf"].includes(key)) return;
        const region = this.regions[key] && this.regions[key][i]; if (!region) return;
        const frac = region.stock / Math.max(.001, region.capacity);
        const preySupport = Math.min(1, rabbitFrac * .55 + deerFrac * .25);
        const support = species.predator ? preySupport : conditions.foodFraction;
        const births = Math.max(.004, species.populationRegenRate * .12) * support * Math.max(0, 1-frac) * region.capacity;
        const losses = (.006 + conditions.danger * .0015 + (species.predator ? Math.max(0,.2-preySupport)*.035 : 0)) * region.stock;
        region.stock = Math.max(0, Math.min(region.capacity, region.stock + births - losses));
      });
    }
  },

  update(deltaSeconds) {
    this.accumulator += deltaSeconds;
    if (this.accumulator < 20) return;
    const ticks = Math.min(3, Math.floor(this.accumulator / 20));
    this.accumulator -= ticks * 20;
    for (let i = 0; i < ticks; i++) this.backgroundTick();
  },
};
