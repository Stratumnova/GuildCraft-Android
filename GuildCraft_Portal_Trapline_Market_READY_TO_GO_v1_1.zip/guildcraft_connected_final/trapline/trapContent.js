// trapContent.js — Market-made Trapline field equipment.
// Four requested grades. Normal trap manufacture belongs to Market Stall.
const trapTiers = [
  { name:"Low Trap", grade:"LOW", catchBonus:.05, components:[], milestoneAt:0, requiresReputation:null },
  { name:"Medium Trap", grade:"MED", catchBonus:.15, components:[], milestoneAt:0, requiresReputation:null },
  { name:"High Trap", grade:"HIGH", catchBonus:.30, components:[], milestoneAt:0, requiresReputation:null },
  { name:"Great Trap", grade:"GREAT", catchBonus:.45, components:[], milestoneAt:0, requiresReputation:null, isMasteryTier:true },
];
const specialTrap = { name:"Longspring Trap", inventoryKey:"longspringTrap", catchBonus:.58 };
