// backendApi.js
// -----------------------------------------------------------------------------
// THIS IS THE ONLY FILE THAT SHOULD NEED TO CHANGE when the real backend
// server is ready. Every function below is a stand-in for a real network
// call, using localStorage so the game is fully playable right now.
//
// Follows the shared Timesheet backend contract (see the project's
// timesheet-backend-contract.md) - the same shape every minigame's own
// copy of this file should use, just with a different CURRENT_GAME_ID.
//
// AI BUILD: traits are no longer a plain array living inside the timesheet
// blob - they're sourced from PermanentLedger (GuildCraft toolkit), which
// enforces "never decreases" as an actual invariant rather than an array
// that happens to only ever get pushed to. PermanentLedger itself is
// in-memory only, so this file hydrates it from localStorage before any
// read and persists it back after any write - the Ledger is the working
// authority during a session, localStorage is just its disk.
//
// Each function has a "BACKEND TODO" comment showing the real method, URL,
// and payload shape. When ready: replace the localStorage read/write inside
// each function with a real fetch() call to that URL. Nothing outside this
// file needs to change, as long as function names and return shapes stay
// the same.
// -----------------------------------------------------------------------------

const CURRENT_GAME_ID = "trapline";

function generateEventId() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function capitalize(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

const backendApi = {
  gameId: CURRENT_GAME_ID,

  // ---- Per-game save (contract Section 1: GET/POST /api/minigame/:gameId/save/:playerId) ----

  // BACKEND TODO: GET /api/minigame/trapline/save/:playerId
  async loadSave(playerId) {
    const raw = localStorage.getItem(`minigameSave_${CURRENT_GAME_ID}_${playerId}`);
    return raw ? JSON.parse(raw) : null;
  },

  // BACKEND TODO: POST /api/minigame/trapline/save/:playerId
  // body: { saveData, displaySummary }
  // displaySummary is a short human-readable string (e.g. "Blacksmith -
  // Armor, Stage 4") that gets surfaced on the player card's activeSaves
  // list WITHOUT the server needing to understand this game's save shape.
  async writeSave(playerId, saveData, displaySummary) {
    localStorage.setItem(`minigameSave_${CURRENT_GAME_ID}_${playerId}`, JSON.stringify(saveData));

    const timesheet = this._readTimesheet(playerId);
    timesheet.activeSaves[CURRENT_GAME_ID] = {
      gameId: CURRENT_GAME_ID,
      lastPlayed: new Date().toISOString(),
      summary: displaySummary || "",
    };
    this._writeTimesheet(playerId, timesheet);

    EventConsole.emit("BACKEND_STUB", `Save written: ${playerId}`, displaySummary || "(no summary)", { playerId, gameId: CURRENT_GAME_ID }, "state");
    return { success: true };
  },

  // ---- Universal drop reporting (contract Section 1: POST /api/drop) ----

  // BACKEND TODO: POST /api/drop
  // body: { playerId, gameId, dropType, payload, eventId }
  // The minigame NEVER applies a drop directly - it only ever reports it.
  // eventId defaults to a fresh UUID but can be passed explicitly by a
  // caller implementing its own retry logic, so a retried request reuses
  // the same ID and the server (or this stub) can dedupe it.
  async reportDrop(playerId, dropType, payload, eventId = generateEventId()) {
    const seenKey = `dropEventIds_${playerId}`;
    const seen = JSON.parse(localStorage.getItem(seenKey) || "[]");
    if (seen.includes(eventId)) {
      EventConsole.emit("RECEIPT", `Duplicate ignored: ${dropType}`, `eventId ${eventId} already recorded`, { playerId, dropType, eventId }, "state");
      return { success: true, duplicate: true, eventId };
    }
    seen.push(eventId);
    localStorage.setItem(seenKey, JSON.stringify(seen));

    const logKey = `dropLog_${playerId}`;
    const existingLog = JSON.parse(localStorage.getItem(logKey) || "[]");
    existingLog.push({ gameId: CURRENT_GAME_ID, dropType, payload, eventId, reportedAt: new Date().toISOString() });
    localStorage.setItem(logKey, JSON.stringify(existingLog));

    // "RECEIPT" naming/framing deliberately echoes A25's SEAL/receipt-hash
    // pattern - this really is the same shape: an append-only confirmation
    // keyed by an idempotent ID, standing in for the real drop endpoint.
    EventConsole.emit("RECEIPT", `Drop received: ${dropType}`, `eventId ${eventId}`, { playerId, gameId: CURRENT_GAME_ID, dropType, payload, eventId }, "milestone");

    // First-pass trait-promotion example (contract Section 5 open item:
    // exact promotion rules TBD as more minigames define their own drops).
    if (dropType === "masteryComplete" && payload && payload.category) {
      this._addTrait(playerId, `hasMastered${capitalize(payload.category)}`);
    }

    return { success: true, eventId };
  },

  // ---- Universal Timesheet / player card read (contract Section 1: GET /api/player/:playerId) ----

  // BACKEND TODO: GET /api/player/:playerId
  // Used for DISPLAY (playerCard.js) - not for this game's own internal
  // logic, which reads its own local mastered-categories list below instead.
  async getPlayerAccount(playerId) {
    return this._readTimesheet(playerId);
  },

  // Trapline-specific progression remains in its own save/ledger modules; this backend stub only exposes the shared contract.

  // ---- Internal stub helpers (not part of the contract) ----

  _readTimesheet(playerId) {
    const raw = localStorage.getItem(`timesheet_${playerId}`);
    const stored = raw ? JSON.parse(raw) : {
      playerId, avatarName: "Unnamed Avatar", floppyBalance: 0, activeSaves: {},
    };
    // Shared-currency migration: preserve old balances, then stop writing the old field.
    if (stored.floppyBalance == null && stored.agagetBalance != null) stored.floppyBalance = stored.agagetBalance;
    delete stored.agagetBalance;
    stored.traits = this._readTraits(playerId); // always derived from the Ledger, never stored directly
    return stored;
  },

  // Traits never get written into the plain blob - only the Ledger's own
  // storage (below) is authoritative for them.
  _writeTimesheet(playerId, timesheet) {
    const { traits, ...rest } = timesheet;
    localStorage.setItem(`timesheet_${playerId}`, JSON.stringify(rest));
  },

  _ledgerKeyPrefix(playerId) {
    return PermanentLedger.buildKey("trait", playerId) + ":";
  },

  // PermanentLedger is in-memory only - rehydrate it from localStorage
  // before any read/write so the "never decreases" invariant is enforced
  // live during a session, while still surviving a page reload via the
  // localStorage-backed stub underneath.
  _hydrateLedger(playerId) {
    const raw = localStorage.getItem(`ledgerTraits_${playerId}`);
    if (!raw) return;
    const stored = JSON.parse(raw);
    Object.entries(stored).forEach(([traitName, value]) => {
      PermanentLedger.raise(PermanentLedger.buildKey("trait", playerId, traitName), value);
    });
  },

  _persistLedger(playerId) {
    const prefix = this._ledgerKeyPrefix(playerId);
    const snapshot = PermanentLedger.snapshot(prefix);
    const stored = {};
    Object.entries(snapshot).forEach(([fullKey, value]) => {
      stored[fullKey.slice(prefix.length)] = value;
    });
    localStorage.setItem(`ledgerTraits_${playerId}`, JSON.stringify(stored));
  },

  _addTrait(playerId, trait) {
    this._hydrateLedger(playerId);
    const isNew = PermanentLedger.get(PermanentLedger.buildKey("trait", playerId, trait), 0) < 1;
    PermanentLedger.raise(PermanentLedger.buildKey("trait", playerId, trait), 1);
    this._persistLedger(playerId);
    if (isNew) {
      EventConsole.emit("LEDGER", `Trait sealed: ${trait}`, "promoted from a mastery drop, never decreases", { playerId, trait }, "milestone");
    }
  },

  _readTraits(playerId) {
    this._hydrateLedger(playerId);
    const prefix = this._ledgerKeyPrefix(playerId);
    const snapshot = PermanentLedger.snapshot(prefix);
    return Object.keys(snapshot).filter((k) => snapshot[k] >= 1).map((k) => k.slice(prefix.length));
  },
};
