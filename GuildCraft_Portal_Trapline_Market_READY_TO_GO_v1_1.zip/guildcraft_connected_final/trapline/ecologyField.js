// ecologyField.js — 192x192 dynamic ecological substrate.
const ecologyField = {
  width:192,height:192,tiles:[],accumulator:0,backgroundAccumulator:0,
  index(x,y){return x+y*this.width;},
  get(x,y){ if(x<0||y<0||x>=this.width||y>=this.height)return null; return this.tiles[this.index(x,y)]; },
  setup(){
    this.tiles=new Array(this.width*this.height);
    for(let y=0;y<this.height;y++)for(let x=0;x<this.width;x++){
      const habitat=this.habitatAt(x,y);
      let foodCapacity=habitat==="brush"?125:habitat==="grassland"?92:habitat==="wet-ground"?76:habitat==="creek"?52:38;
      let waterCapacity=habitat==="wet-ground"?100:habitat==="creek"?145:0;
      this.tiles[this.index(x,y)]={habitat,foodCapacity,foodStock:foodCapacity*(.45+Math.random()*.35),waterCapacity,waterStock:waterCapacity,scent:{},danger:0,deadMatter:0};
    }
  },
  habitatAt(x,y){
    // broad, irregular zones: enough landmarks to navigate without showing a full map.
    if(x>=91&&x<=99) return "legacy-cut";
    if((y>=38&&y<=44&&x>=10&&x<=176)||(y>=121&&y<=126&&x>=52&&x<=185)) return "creek";
    if((y>=143&&x<=74)||(y>=103&&y<=142&&x>=151)) return "wet-ground";
    const n=((x*17+y*31+x*y)%37);
    if((x<58&&y<72)||(x>132&&y<88)||(x<70&&y>116)||(x>114&&y>150)||n<7) return "brush";
    return "grassland";
  },
  tick(dt){
    this.accumulator+=dt;if(this.accumulator<2)return;const steps=Math.min(4,Math.floor(this.accumulator/2));this.accumulator-=steps*2;
    for(let s=0;s<steps;s++){
      // Keep the whole world alive, but only fully touch the local passive radius.
      const r=simulationBands.passiveRadius+8;
      const minX=Math.max(0,player.gridColumn-r),maxX=Math.min(this.width-1,player.gridColumn+r);
      const minY=Math.max(0,player.gridRow-r),maxY=Math.min(this.height-1,player.gridRow+r);
      for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++)this.tickTile(this.get(x,y),1);
    }
    this.backgroundAccumulator+=steps*2;
    if(this.backgroundAccumulator>=20){this.backgroundAccumulator=0;this.backgroundTick();}
  },
  tickTile(tile,mult=1){if(!tile)return;tile.foodStock=Math.min(tile.foodCapacity,tile.foodStock+tile.foodCapacity*.0025*mult);for(const key of Object.keys(tile.scent)){tile.scent[key]*=Math.pow(.93,mult);if(tile.scent[key]<.02)delete tile.scent[key];}tile.danger*=Math.pow(.94,mult);tile.deadMatter*=Math.pow(.995,mult);},
  backgroundTick(){
    // Statistical samples keep distant habitat changing without iterating 36k cells every frame.
    for(let i=0;i<950;i++){
      const x=Math.floor(Math.random()*this.width),y=Math.floor(Math.random()*this.height);
      if(simulationBands.bandFor(x,y)!==simulationBands.BACKGROUND)continue;
      this.tickTile(this.get(x,y),10);
    }
  },
  depositScent(x,y,key,amount=1){const t=this.get(x,y);if(t)t.scent[key]=(t.scent[key]||0)+amount;},
  addDanger(x,y,amount=1){const t=this.get(x,y);if(t)t.danger=Math.min(10,t.danger+amount);},
  requestFood(x,y,wanted=1){const t=this.get(x,y);if(!t)return 0;const a=t.foodStock*.35,g=Math.min(wanted,a);t.foodStock-=g;return g;},
  scentScore(x,y,key){const t=this.get(x,y);return t?(t.scent[key]||0):0;},
  bestNeighbor(x,y,scoreFn,seek=true,step=1){
    const dirs=[[0,-step],[0,step],[-step,0],[step,0],[0,0]];let best={x,y,score:seek?-Infinity:Infinity};
    for(const [dx,dy] of dirs){const p=grid.clampToGrid(x+dx,y+dy),score=scoreFn(p.column,p.row);if((seek&&score>best.score)||(!seek&&score<best.score))best={x:p.column,y:p.row,score};}return best;
  },
  findSpawn(habitats,center=null,radius=999){const c=center||{column:96,row:96};let best=null;for(let i=0;i<180;i++){const x=Math.max(0,Math.min(this.width-1,c.column+Math.floor((Math.random()*2-1)*radius))),y=Math.max(0,Math.min(this.height-1,c.row+Math.floor((Math.random()*2-1)*radius))),t=this.get(x,y);if(!t||!habitats.includes(t.habitat))continue;const score=t.foodStock+Math.random()*20;if(!best||score>best.score)best={column:x,row:y,score};}return best||{column:Math.floor(Math.random()*this.width),row:Math.floor(Math.random()*this.height)};}
};
