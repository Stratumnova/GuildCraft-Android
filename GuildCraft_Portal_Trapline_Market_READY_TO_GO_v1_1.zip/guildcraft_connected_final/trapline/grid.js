// grid.js — 192x192 Trapline world with a local camera viewport.
const grid = {
  columns: 192,
  rows: 192,
  cellSizePixels: 40,
  cellToPixels(column,row){ return {x:column*this.cellSizePixels,y:row*this.cellSizePixels}; },
  pixelsToCell(x,y){ return {column:Math.floor(x/this.cellSizePixels),row:Math.floor(y/this.cellSizePixels)}; },
  clampToGrid(column,row){ return {column:Math.max(0,Math.min(this.columns-1,column)),row:Math.max(0,Math.min(this.rows-1,row))}; },
  draw(ctx){
    ctx.strokeStyle="rgba(82,105,84,.42)";ctx.lineWidth=1;const b=camera.visibleCellBounds(1);
    for(let c=b.left;c<=b.right+1;c++){const x=c*this.cellSizePixels;ctx.beginPath();ctx.moveTo(x,b.top*this.cellSizePixels);ctx.lineTo(x,(b.bottom+1)*this.cellSizePixels);ctx.stroke();}
    for(let r=b.top;r<=b.bottom+1;r++){const y=r*this.cellSizePixels;ctx.beginPath();ctx.moveTo(b.left*this.cellSizePixels,y);ctx.lineTo((b.right+1)*this.cellSizePixels,y);ctx.stroke();}
  }
};
