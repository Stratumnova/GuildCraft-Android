// mapContent.js — landmarks, travel corridors, and progression resources across the 192x192 Wild.
// Common materials remain near Trail Camp; rarer craft inputs are deliberately farther out.
const mapContent = {
  resourceNodeLayout:[
    // Near-field basics
    {id:"wood_camp_w",resource:"wood",label:"Field Wood",column:83,row:97,capacity:8,regenRate:.08,rarity:"common"},
    {id:"wood_camp_e",resource:"wood",label:"Field Wood",column:112,row:104,capacity:8,regenRate:.08,rarity:"common"},
    {id:"fiber_creek",resource:"fiber",label:"Plant Fiber",column:77,row:122,capacity:7,regenRate:.075,rarity:"common"},
    {id:"cordage_mid",resource:"cordage",label:"Cordage Plant",column:112,row:125,capacity:7,regenRate:.07,rarity:"common"},
    {id:"iron_service",resource:"ironOre",label:"Iron Ore",column:93,row:82,capacity:5,regenRate:.035,rarity:"common"},
    {id:"herb_mid",resource:"medicinalHerb",label:"Medicinal Herb",column:72,row:109,capacity:5,regenRate:.045,rarity:"common"},

    // West / southwest forest materials
    {id:"wood_nw",resource:"wood",label:"Field Wood",column:34,row:29,capacity:8,regenRate:.08,rarity:"common"},
    {id:"hardwood_sw",resource:"hardwood",label:"Hardwood",column:31,row:156,capacity:5,regenRate:.035,rarity:"uncommon"},
    {id:"resin_sw",resource:"resin",label:"Tree Resin",column:47,row:148,capacity:5,regenRate:.04,rarity:"uncommon"},
    {id:"fiber_wet",resource:"fiber",label:"Wetland Fiber",column:41,row:157,capacity:7,regenRate:.065,rarity:"common"},

    // North / creek country
    {id:"cordage_creek_w",resource:"cordage",label:"Cordage Plant",column:55,row:41,capacity:7,regenRate:.07,rarity:"common"},
    {id:"herb_creek",resource:"medicinalHerb",label:"Medicinal Herb",column:63,row:39,capacity:5,regenRate:.05,rarity:"common"},
    {id:"copper_north",resource:"copperOre",label:"Copper Ore",column:119,row:28,capacity:4,regenRate:.025,rarity:"uncommon"},
    {id:"iron_cut_n",resource:"ironOre",label:"Iron Ore",column:95,row:27,capacity:5,regenRate:.035,rarity:"common"},

    // East / wetland materials
    {id:"wood_east",resource:"wood",label:"Field Wood",column:158,row:63,capacity:8,regenRate:.08,rarity:"common"},
    {id:"fiber_east",resource:"fiber",label:"Reed Fiber",column:164,row:124,capacity:8,regenRate:.07,rarity:"common"},
    {id:"resin_ne",resource:"resin",label:"Tree Resin",column:146,row:34,capacity:5,regenRate:.04,rarity:"uncommon"},
    {id:"hardwood_ne",resource:"hardwood",label:"Hardwood",column:157,row:54,capacity:5,regenRate:.035,rarity:"uncommon"},

    // Legacy salvage — strongest reason to travel far from Trail Camp
    {id:"scrap_array",resource:"scrapMetal",label:"Recovered Scrap",column:139,row:72,capacity:4,regenRate:.018,rarity:"uncommon"},
    {id:"alloy_array",resource:"oldAlloy",label:"Old-world Alloy",column:146,row:68,capacity:2,regenRate:.008,rarity:"rare"},
    {id:"scrap_cut_s",resource:"scrapMetal",label:"Recovered Scrap",column:95,row:137,capacity:4,regenRate:.018,rarity:"uncommon"},
    {id:"iron_far_s",resource:"ironOre",label:"Iron Ore",column:96,row:174,capacity:4,regenRate:.03,rarity:"common"},
    {id:"copper_far_s",resource:"copperOre",label:"Copper Ore",column:108,row:177,capacity:4,regenRate:.024,rarity:"uncommon"},
    {id:"alloy_far_s",resource:"oldAlloy",label:"Old-world Alloy",column:122,row:181,capacity:2,regenRate:.007,rarity:"rare"}
  ],
  landmarks:[
    {id:"trail_camp",label:"Trail Camp",column:98,row:98,kind:"camp",radius:9},
    {id:"old_service_cut",label:"Old Service Cut",column:95,row:82,kind:"legacy",radius:8},
    {id:"north_creek",label:"North Creek",column:57,row:41,kind:"water",radius:9},
    {id:"south_marsh",label:"Wet Ground",column:41,row:157,kind:"marsh",radius:10},
    {id:"east_wetland",label:"Reed Flats",column:165,row:122,kind:"marsh",radius:10},
    {id:"southern_creek",label:"Lower Creek",column:128,row:123,kind:"water",radius:9},
    {id:"broken_array",label:"Broken Array",column:139,row:72,kind:"legacy",radius:7},
    {id:"split_oak",label:"Split Oak",column:62,row:109,kind:"natural",radius:7},
    {id:"north_rocks",label:"North Rocks",column:119,row:28,kind:"natural",radius:7},
    {id:"south_cut",label:"South Service Scar",column:113,row:178,kind:"legacy",radius:8}
  ],
  trails:[
    {id:"west_trader_road",points:[[0,96],[35,96],[66,97],[98,98]]},
    {id:"north_trader_road",points:[[97,0],[96,31],[97,66],[98,98]]},
    {id:"east_trader_road",points:[[191,102],[160,102],[131,100],[98,98]]}
  ]
};
