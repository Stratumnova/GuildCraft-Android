// Trapline clock. One complete in-game day lasts 36 real minutes.
// Activity windows are tuned so true night is 8 in-game hours and the
// combined dawn/day/dusk field window is 16 hours: exactly a 2:1 ratio.
const clock={
 totalGameMinutes:0,realMinutesPerFullDay:36,
 update(deltaSeconds){this.totalGameMinutes+=deltaSeconds*((24*60)/(this.realMinutesPerFullDay*60))},
 getDay(){return Math.floor(this.totalGameMinutes/1440)+1},
 getFormattedTime(){const m=this.totalGameMinutes%1440,h=Math.floor(m/60),mm=Math.floor(m%60);return `Day ${this.getDay()}, ${String(h).padStart(2,'0')}:${String(mm).padStart(2,'0')}`},
 phase(){const h=(this.totalGameMinutes%1440)/60;if(h>=5&&h<7)return 'dawn';if(h>=7&&h<17)return 'day';if(h>=17&&h<21)return 'dusk';return 'night'},
 skipToMorning(){const d=Math.floor(this.totalGameMinutes/1440),m=this.totalGameMinutes%1440;this.totalGameMinutes=(m<300?d:d+1)*1440+300}
};
