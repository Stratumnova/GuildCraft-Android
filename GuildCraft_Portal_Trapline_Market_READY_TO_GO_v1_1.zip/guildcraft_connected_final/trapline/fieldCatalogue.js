const fieldCatalogue={
 key:`fieldCatalogue_${saveState.currentPlayerId}`,
 read(){try{return JSON.parse(localStorage.getItem(this.key)||'{"schema":2,"animals":{}}')}catch{return {schema:2,animals:{}}}},
 write(s){s.schema=2;localStorage.setItem(this.key,JSON.stringify(s))},
 mark(species,state){if(!speciesContent[species])return;const s=this.read();s.animals[species]=s.animals[species]||{seen:false,dead:false,live:false,firstSeen:null,firstDead:null,firstLive:null};const a=s.animals[species],now={phase:clock.phase(),minute:clock.totalGameMinutes};a.seen=true;a.firstSeen=a.firstSeen||now;if(state==='dead'){a.dead=true;a.firstDead=a.firstDead||now}if(state==='live'){a.live=true;a.firstLive=a.firstLive||now}this.write(s)},
 rows(){const s=this.read();return Object.entries(speciesContent).map(([k,v])=>({key:k,label:v.label,habitats:v.habitatTags,activity:v.activity,...(s.animals[k]||{seen:false,dead:false,live:false})}))},
 completion(){const r=this.rows();return {seen:r.filter(x=>x.seen).length,dead:r.filter(x=>x.dead).length,live:r.filter(x=>x.live).length,total:r.length,complete:r.filter(x=>x.seen&&x.dead&&x.live).length}}
};
