// clueBridge.js
// Cross-game route-marker bridge.
// CURRENT mechanic: leaving Trapline while the one concealed cottontail is
// still alive and physically carried records the route marker on the shared Timesheet.
// CURRENT: Portal reads this marker, then independently verifies the qualifying live specimen before revealing the route clue.

const clueBridge = {
  routeId: "portal/black cottontail",
  routeHash: "4844b2e00f18d3921da637a8bbcf443312c466901a82b79bab56892967c04d28",

  _read(playerId) {
    const raw = localStorage.getItem(`timesheet_${playerId}`);
    return raw ? JSON.parse(raw) : { playerId, avatarName: "Unnamed Avatar", floppyBalance: 0, activeSaves: {} };
  },

  _write(playerId, sheet) { localStorage.setItem(`timesheet_${playerId}`, JSON.stringify(sheet)); },

  isEligible(rabbit, inventory) {
    return !!(rabbit && rabbit.captured && !rabbit.processed && !rabbit.tradedAway && inventory && (inventory.liveCottontail || 0) === 1);
  },

  commitIfEligible(playerId, rabbit, inventory) {
    if (!this.isEligible(rabbit, inventory)) return false;
    const sheet = this._read(playerId);
    sheet.routeMarkers = sheet.routeMarkers || {};
    if (!sheet.routeMarkers[this.routeId]) {
      sheet.routeMarkers[this.routeId] = {
        unlocked: true,
        source: "trapline:black-cottontail",
        sha256: this.routeHash,
        firstRecordedAt: new Date().toISOString()
      };
      this._write(playerId, sheet);
      if (typeof EventConsole !== "undefined") EventConsole.emit("ROUTE", "Concealed route marker recorded", this.routeId, { routeId: this.routeId }, "milestone");
    }
    return true;
  },

  // Compatibility alias for older calls; requires the live specimen object now.
  commitIfCarried(playerId, inventory) {
    return this.commitIfEligible(playerId, typeof uniqueBlackRabbit !== "undefined" ? uniqueBlackRabbit : null, inventory);
  }
};
