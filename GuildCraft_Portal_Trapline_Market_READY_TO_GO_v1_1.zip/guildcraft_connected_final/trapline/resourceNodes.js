// resourceNodes.js — regenerating gatherable materials with regional rarity.
const resourceNodes = {
  list: [],
  setup() {
    this.list = mapContent.resourceNodeLayout.map((nodeData) => ({
      ...nodeData,
      label: nodeData.label || nodeData.resource,
      rarity: nodeData.rarity || "common",
      pool: ResourcePool.create(nodeData.id, {
        capacity: nodeData.capacity, stock: nodeData.capacity, drawLimit: 1.0, regenRate: nodeData.regenRate,
      }),
    }));
  },
  update(deltaSeconds) { this.list.forEach((node) => ResourcePool.tick(node.pool, deltaSeconds)); },
  getNodeAt(column, row) { return this.list.find((n) => n.column === column && n.row === row) || null; },
  attemptGather(column, row) {
    const node = this.getNodeAt(column, row); if (!node) return false;
    const granted = Math.floor(ResourcePool.request(node.pool, 1));
    if (granted < 1) { EventConsole.emit("GATHER", `Gather failed: ${node.label}`, "node is depleted right now", { node: node.id }, "state"); return false; }
    const result=groundDrops.giveOrDrop(node.resource,granted,column,row,"gather-overflow");
    EventConsole.emit("GATHER", `Gathered ${node.label}`, `${node.rarity} material · ${result.dropped?"left on ground — pack full":"carried"} · ${node.pool.stock.toFixed(1)} left`, { node: node.id, rarity:node.rarity, stockAfter: node.pool.stock, dropped:result.dropped }, "decision");
    return true;
  },
  draw(canvasContext) {
    const colors={common:"#8a7a4a",uncommon:"#7b7659",rare:"#b07935"};
    this.list.forEach((node) => {
      const pixels = grid.cellToPixels(node.column, node.row), isDepleted = node.pool.stock < 1;
      canvasContext.fillStyle = isDepleted ? "#3a3a2a" : (colors[node.rarity]||colors.common);
      canvasContext.fillRect(pixels.x + 8, pixels.y + 8, grid.cellSizePixels - 16, grid.cellSizePixels - 16);
      if(node.rarity==="rare"&&!isDepleted){canvasContext.strokeStyle="#c99a52";canvasContext.strokeRect(pixels.x+6,pixels.y+6,grid.cellSizePixels-12,grid.cellSizePixels-12)}
    });
  },
};
