// groundDrops.js — overflow loot stays in the world instead of vanishing.
// Drops persist for 24 in-game hours (1440 game minutes), then despawn.
const groundDrops = {
  list: [], nextId: 1, lifetimeMinutes: 1440,
  hydrate(saved){
    this.list = Array.isArray(saved?.list) ? saved.list.filter(d=>d&&d.item&&d.quantity>0) : [];
    this.nextId = Number.isFinite(saved?.nextId) ? saved.nextId : (this.list.reduce((m,d)=>Math.max(m,Number(String(d.id||'').replace(/\D/g,''))||0),0)+1);
    this.expire();
  },
  snapshot(){ return {list:this.list,nextId:this.nextId}; },
  drop(item, quantity=1, column=player.gridColumn, row=player.gridRow, reason='pack-full'){
    quantity=Math.floor(quantity); if(!item||quantity<1)return false;
    const existing=this.list.find(d=>d.item===item&&d.column===column&&d.row===row&&Math.abs((d.createdAtGameMinute||0)-clock.totalGameMinutes)<1);
    if(existing) existing.quantity+=quantity;
    else this.list.push({id:`drop_${this.nextId++}`,item,quantity,column,row,createdAtGameMinute:clock.totalGameMinutes,reason});
    EventConsole.emit('GROUND',`${item} left on the ground`,`${quantity} item${quantity===1?'':'s'} · despawns after 24 in-game hours`,{item,quantity,column,row,reason},'state');
    return true;
  },
  giveOrDrop(item, quantity=1, column=player.gridColumn, row=player.gridRow, reason='pack-full'){
    if(player.addToInventory(item,quantity))return {carried:quantity,dropped:0};
    this.drop(item,quantity,column,row,reason); return {carried:0,dropped:quantity};
  },
  nearby(range=1){this.expire();return this.list.filter(d=>Math.max(Math.abs(player.gridColumn-d.column),Math.abs(player.gridRow-d.row))<=range);},
  take(id, quantity=1){
    this.expire(); const d=this.list.find(x=>x.id===id); if(!d||d.quantity<1)return false;
    quantity=Math.max(1,Math.min(d.quantity,Math.floor(quantity)));
    if(!player.addToInventory(d.item,quantity)){EventConsole.emit('PACK','No room',`${d.item} stays on the ground.`,{dropId:id},'state');return false;}
    d.quantity-=quantity; if(d.quantity<=0)this.list=this.list.filter(x=>x.id!==id);
    EventConsole.emit('GROUND',`Picked up ${d.item}`,`x${quantity}`,{dropId:id},'decision'); return true;
  },
  takeAll(id){const d=this.list.find(x=>x.id===id);return d?this.take(id,d.quantity):false;},
  expire(){
    const now=clock.totalGameMinutes; const expired=this.list.filter(d=>now-(d.createdAtGameMinute||0)>=this.lifetimeMinutes);
    if(expired.length)EventConsole.emit('GROUND','Ground items despawned',`${expired.length} drop${expired.length===1?'':'s'} aged past 24 in-game hours.`,{ids:expired.map(d=>d.id)},'state');
    this.list=this.list.filter(d=>now-(d.createdAtGameMinute||0)<this.lifetimeMinutes);
  },
  tick(){this.expire();},
  draw(ctx){
    this.expire(); this.list.forEach(d=>{if(!camera.isCellVisible(d.column,d.row,2))return;const p=grid.cellToPixels(d.column,d.row);ctx.save();ctx.translate(p.x+20,p.y+27);ctx.fillStyle='rgba(214,190,126,.88)';ctx.beginPath();ctx.moveTo(-7,5);ctx.lineTo(0,-5);ctx.lineTo(8,4);ctx.lineTo(0,8);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(36,31,22,.8)';ctx.stroke();ctx.restore();});
  }
};
