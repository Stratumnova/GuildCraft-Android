// trackingSigns.js — player-facing local evidence, never a whole-map reveal.
const trackingSigns = {
  species:["rabbit","deer","wolf"],
  label:{rabbit:"cottontail",deer:"deer",wolf:"wolf"},
  nearbyLandmark(){
    let best=null;
    mapContent.landmarks.forEach(l=>{const d=Math.max(Math.abs(l.column-player.gridColumn),Math.abs(l.row-player.gridRow));if(d<=(l.radius||8)&&(!best||d<best.distance))best={...l,distance:d};});
    return best;
  },
  strongestDirection(speciesKey){
    const key=speciesContent[speciesKey].scentKey,hasTracker=(player.inventory.scentDial||0)>0,range=hasTracker?10:5;
    const dirs=[{name:"north",dx:0,dy:-1},{name:"south",dx:0,dy:1},{name:"west",dx:-1,dy:0},{name:"east",dx:1,dy:0}];
    let best={name:"nearby",score:ecologyField.scentScore(player.gridColumn,player.gridRow,key)};
    for(const d of dirs){let score=0;for(let step=1;step<=range;step++)score+=ecologyField.scentScore(player.gridColumn+d.dx*step,player.gridRow+d.dy*step,key)*(range+1-step);if(score>best.score)best={name:d.name,score};}
    return best;
  },
  signs(){
    const rows=[],hasTracker=(player.inventory.scentDial||0)>0,threshold=hasTracker?.08:.16;
    for(const sp of this.species){
      const d=this.strongestDirection(sp),local=populationPools.getPopulationFraction(sp,player.gridColumn,player.gridRow);
      if(d.score>threshold||local>.38){
        const strength=d.score>(hasTracker?5:3)?"fresh":d.score>(hasTracker?1.5:1)?"clear":d.score>(hasTracker?.12:.25)?"faint":local>.65?"common":"old";
        rows.push({species:sp,text:`${strength} ${this.label[sp]} sign${d.name!=="nearby"?` leading ${d.name}`:" nearby"}`});
      }
    }
    return rows;
  },
  renderPanel(){
    const panel=document.getElementById("trackingPanel"); if(!panel)return;
    const lm=this.nearbyLandmark(), signs=this.signs(),hasTracker=(player.inventory.scentDial||0)>0;
    let html='<h3>Trail Signs</h3>';
    if(hasTracker)html+='<p><small>Scent Dial active — weak sign carries farther.</small></p>';
    if(lm)html+=`<p><strong>${lm.label}</strong><br><small>You are close enough to recognize this place.</small></p>`;
    html+=signs.length?signs.map(s=>`<p class="trackSign">${s.text}</p>`).join(''):'<p><small>No readable sign nearby. Move, wait, or look for better ground.</small></p>';
    panel.innerHTML=html;
  },
  draw(ctx){
    const b=camera.visibleCellBounds(0);
    this.species.forEach((sp,si)=>{const key=speciesContent[sp].scentKey;for(let y=b.top;y<=b.bottom;y+=2)for(let x=b.left;x<=b.right;x+=2){const s=ecologyField.scentScore(x,y,key);if(s<.38)continue;const p=grid.cellToPixels(x,y);ctx.save();ctx.globalAlpha=Math.min(.42,.08+s*.08);ctx.fillStyle=sp==="wolf"?"#d6cfbe":sp==="deer"?"#c9b893":"#ddd8c8";ctx.beginPath();ctx.ellipse(p.x+12+si*4,p.y+28-si*3,3,6,.35,0,Math.PI*2);ctx.fill();ctx.restore();}});
  }
};
