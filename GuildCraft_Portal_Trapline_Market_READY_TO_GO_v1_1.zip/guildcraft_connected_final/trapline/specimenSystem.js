// specimenSystem.js — ordinary live-specimen capture and provenance.
// The hidden cottontail is intentionally NOT represented here.
const specimenSystem={
  key:`traplineSpecimens_${saveState.currentPlayerId}`,
  captureGear:{rabbit:'captureCrate',squirrel:'captureCrate',turkey:'captureCrate',owl:'captureCrate',raccoon:'captureCrate',deer:'captureRig',beaver:'captureRig',fox:'captureRig',boar:'captureRig',wolf:'captureRig'},
  read(){try{return JSON.parse(localStorage.getItem(this.key)||'{"schema":2,"serial":0,"records":[]}')}catch{return {schema:2,serial:0,records:[]}}},
  write(s){s.schema=2;localStorage.setItem(this.key,JSON.stringify(s))},
  capture(unit){
    const sp=speciesContent[unit.speciesKey]; if(!sp)return false;
    const gear=this.captureGear[unit.speciesKey];
    if(gear&&(player.inventory[gear]||0)<1){EventConsole.emit('CAPTURE','Capture gear required',`${sp.label} requires ${gear} from Market Stall.`,{},'state');return false}
    if(!player.addToInventory(`live:${unit.speciesKey}`,1)){EventConsole.emit('PACK','No room','A live specimen needs a free carry slot.',{},'state');return false}
    const s=this.read();s.serial=(s.serial||0)+1;s.records.push({id:`spec_${s.serial}`,species:unit.speciesKey,capturedAt:clock.totalGameMinutes,alive:true,source:{column:unit.gridColumn,row:unit.gridRow,phase:clock.phase(),habitat:ecologyField.get(unit.gridColumn,unit.gridRow)?.habitat||'unknown'}});this.write(s);
    fieldCatalogue.mark(unit.speciesKey,'live');
    EventConsole.emit('CAPTURE',`${sp.label} secured alive`,`Specimen provenance recorded for Market requests.`,{species:unit.speciesKey},'milestone');return true
  },
  release(species){if((player.inventory[`live:${species}`]||0)<1)return false;player.inventory[`live:${species}`]--;const s=this.read();const r=[...s.records].reverse().find(x=>x.species===species&&x.alive);if(r){r.alive=false;r.disposition='released';r.closedAt=clock.totalGameMinutes}this.write(s);return true},
  transferOne(species){const s=this.read();const r=[...s.records].reverse().find(x=>x.species===species&&x.alive);if(r){r.alive=false;r.disposition='portal';r.closedAt=clock.totalGameMinutes;this.write(s)}},
  summary(){return Object.keys(speciesContent).map(k=>({species:k,count:player.inventory[`live:${k}`]||0})).filter(x=>x.count>0)}
};
