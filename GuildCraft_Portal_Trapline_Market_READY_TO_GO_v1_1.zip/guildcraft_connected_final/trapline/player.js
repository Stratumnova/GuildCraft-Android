const player = {
  gridColumn:98,gridRow:98,moveSpeedCellsPerSecond:6,targetColumn:null,targetRow:null,inventory:{},placedTraps:[],
  canAddToInventory(itemName){const exists=(this.inventory[itemName]||0)>0;return exists||typeof survivalSystem==="undefined"||survivalSystem.used()<survivalSystem.capacity();},
  addToInventory(itemName,quantity=1){if(quantity<=0||!this.canAddToInventory(itemName))return false;this.inventory[itemName]=(this.inventory[itemName]||0)+quantity;return true;},
  hasComponents(componentList){return componentList.every(name=>(this.inventory[name]||0)>0);},
  consumeComponents(componentList){componentList.forEach(name=>{this.inventory[name]=Math.max(0,(this.inventory[name]||0)-1);});}
};
