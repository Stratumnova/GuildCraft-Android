// saveState.js
// -----------------------------------------------------------------------------
// One save per player for Trapline, same "one save, backend-authoritative"
// pattern as Market Stall 1's saveState.js - just a different state shape.
// -----------------------------------------------------------------------------

const saveState = {
  currentPlayerId: "testPlayerOne",

  buildSaveSnapshot(playerState) {
    return {
      worldSize: 192,
      simulationSchema: 11,
      gridColumn: playerState.gridColumn,
      gridRow: playerState.gridRow,
      inventory: playerState.inventory,
      placedTraps: playerState.placedTraps,
      uniqueBlackRabbit: typeof uniqueBlackRabbit !== "undefined" ? uniqueBlackRabbit.snapshot() : null,
      traders: typeof traders !== "undefined" ? traders.snapshot() : null,
      populationState: typeof populationPools !== "undefined" ? populationPools.snapshot() : null,
      totalGameMinutes: typeof clock !== "undefined" ? clock.totalGameMinutes : 0,
      survival: typeof survivalSystem !== "undefined" ? survivalSystem.snapshot() : null,
      groundDrops: typeof groundDrops !== "undefined" ? groundDrops.snapshot() : null,
      savedAt: new Date().toISOString(),
    };
  },

  buildDisplaySummary(playerState) {
    const trapCount = playerState.placedTraps.length;
    const peltCount = Object.entries(playerState.inventory)
      .filter(([name]) => name.endsWith("Pelt") || name.endsWith("Hide"))
      .reduce((sum, [, count]) => sum + count, 0);
    return `${trapCount} trap${trapCount === 1 ? "" : "s"} active, ${peltCount} pelt${peltCount === 1 ? "" : "s"} collected`;
  },

  async saveNow(playerState) {
    const snapshot = this.buildSaveSnapshot(playerState);
    const summary = this.buildDisplaySummary(playerState);
    return backendApi.writeSave(this.currentPlayerId, snapshot, summary);
  },

  async loadExistingSave() {
    return backendApi.loadSave(this.currentPlayerId);
  },
};
