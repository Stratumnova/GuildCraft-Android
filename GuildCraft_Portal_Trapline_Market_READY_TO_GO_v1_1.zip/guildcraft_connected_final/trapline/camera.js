// camera.js — fixed-size local viewport over a much larger 96x96 Wild.
// On phones the canvas scales down, but the player still sees roughly the same
// local territory rather than a zoomed-out whole-map overview.
const camera = {
  viewportWidth: 800,
  viewportHeight: 800,
  x: 0,
  y: 0,
  smoothing: 0.14,

  maxX() { return grid.columns * grid.cellSizePixels - this.viewportWidth; },
  maxY() { return grid.rows * grid.cellSizePixels - this.viewportHeight; },

  targetFor(column, row) {
    const cx = column * grid.cellSizePixels + grid.cellSizePixels / 2 - this.viewportWidth / 2;
    const cy = row * grid.cellSizePixels + grid.cellSizePixels / 2 - this.viewportHeight / 2;
    return {
      x: Math.max(0, Math.min(this.maxX(), cx)),
      y: Math.max(0, Math.min(this.maxY(), cy)),
    };
  },

  snapToPlayer() {
    const target = this.targetFor(player.gridColumn, player.gridRow);
    this.x = target.x; this.y = target.y;
  },

  update() {
    const target = this.targetFor(player.gridColumn, player.gridRow);
    this.x += (target.x - this.x) * this.smoothing;
    this.y += (target.y - this.y) * this.smoothing;
    if (Math.abs(target.x - this.x) < 0.25) this.x = target.x;
    if (Math.abs(target.y - this.y) < 0.25) this.y = target.y;
  },

  screenToWorldPixel(screenX, screenY) { return { x: screenX + this.x, y: screenY + this.y }; },
  screenToWorldCell(screenX, screenY) {
    const p = this.screenToWorldPixel(screenX, screenY);
    return grid.pixelsToCell(p.x, p.y);
  },

  visibleCellBounds(padding = 0) {
    return {
      left: Math.max(0, Math.floor(this.x / grid.cellSizePixels) - padding),
      top: Math.max(0, Math.floor(this.y / grid.cellSizePixels) - padding),
      right: Math.min(grid.columns - 1, Math.ceil((this.x + this.viewportWidth) / grid.cellSizePixels) + padding),
      bottom: Math.min(grid.rows - 1, Math.ceil((this.y + this.viewportHeight) / grid.cellSizePixels) + padding),
    };
  },

  isCellVisible(column, row, padding = 1) {
    const b = this.visibleCellBounds(padding);
    return column >= b.left && column <= b.right && row >= b.top && row <= b.bottom;
  },

  beginWorld(ctx) { ctx.save(); ctx.translate(-this.x, -this.y); },
  endWorld(ctx) { ctx.restore(); },
};
