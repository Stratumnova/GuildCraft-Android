// qa.js — development-side invariant checks. Never changes player progress.
const TraplineQA = {
  run(){
    const checks=[];
    const push=(name,ok,detail='')=>checks.push({name,ok:!!ok,detail});
    const specials=traderContent.map(t=>t.specialTrade&&t.specialTrade.itemKey).filter(Boolean);
    const rabbitCount=Number(player.inventory.liveCottontail||0);
    push('World is 192×192', grid.columns===192 && grid.rows===192, `${grid.columns}×${grid.rows}`);
    push('Four simulation bands', simulationBands.ACTIVE==='active'&&simulationBands.AWARE==='aware'&&simulationBands.PASSIVE==='passive'&&simulationBands.BACKGROUND==='background');
    push('Three roaming traders', Array.isArray(traderContent)&&traderContent.length===3, `count ${traderContent.length}`);
    push('Three distinct temperaments', new Set(traderContent.map(t=>t.temperament)).size===3);
    push('Three distinct specimen barters', specials.length===3 && new Set(specials).size===3, specials.join(', '));
    push('Special barters are one-shot', traderContent.every(t=>typeof traders.state[t.id]?.specialTraded==='boolean'));
    push('Special barter handler is live', typeof onSpecialTraderTrade==='function');
    push('Live cottontail count is 0 or 1', rabbitCount===0||rabbitCount===1, `count ${rabbitCount}`);
    push('Processed/traded specimen cannot remain carried', !(uniqueBlackRabbit.processed||uniqueBlackRabbit.tradedAway)||rabbitCount===0);
    push('Route eligibility requires living carried specimen', clueBridge.isEligible(uniqueBlackRabbit,player.inventory) === (!!uniqueBlackRabbit.captured&&!uniqueBlackRabbit.processed&&!uniqueBlackRabbit.tradedAway&&rabbitCount===1));
    push('Portal route hash matches contract', clueBridge.routeHash==='4844b2e00f18d3921da637a8bbcf443312c466901a82b79bab56892967c04d28');
    push('Save schema current', saveState.buildSaveSnapshot(player).simulationSchema>=10, `schema ${saveState.buildSaveSnapshot(player).simulationSchema}`);
    push('Portal ledger schema 4', typeof PortalLedger!=='undefined'&&PortalLedger.SCHEMA===4, `schema ${typeof PortalLedger!=='undefined'?PortalLedger.SCHEMA:'missing'}`);
    push('Portal ledger checksums valid', typeof PortalLedger!=='undefined'&&PortalLedger.validate(saveState.currentPlayerId).ok);
    push('Secret specimen blocked from cargo', typeof PortalLedger!=='undefined'&&!PortalLedger.allowed('trapline','market-stall','liveCottontail'));
    push('Day/night ratio is 2:1', clock.phase.call({totalGameMinutes:6*60})==='dawn' && clock.phase.call({totalGameMinutes:12*60})==='day' && clock.phase.call({totalGameMinutes:19*60})==='dusk' && clock.phase.call({totalGameMinutes:23*60})==='night');

    const result={passed:checks.filter(c=>c.ok).length,total:checks.length,checks,at:new Date().toISOString()};
    EventConsole.emit('QA',`Trapline QA ${result.passed}/${result.total}`,result.passed===result.total?'all release invariants passed':'one or more checks failed',result,result.passed===result.total?'milestone':'state');
    return result;
  },
  html(){
    const r=this.run();
    return `<div class="qaResult"><strong>Release QA: ${r.passed}/${r.total}</strong>${r.checks.map(c=>`<div class="qaRow ${c.ok?'pass':'fail'}">${c.ok?'✓':'✕'} ${c.name}${c.detail?` <small>${c.detail}</small>`:''}</div>`).join('')}</div>`;
  }
};
