// Trail traders: recurring people with distinct temperaments and one secret barter each.
// The special barter never names or visually identifies the hidden cottontail as unusual.
const traderContent = [
  {
    id:"mara_venn",name:"Mara Venn",voice:"plain_survivor",temperament:"mercurial",route:"west_trader_road",home:{c:98,r:98},hours:[6,13],travelMinutes:55,floppies:36,
    sells:{medicinalHerb:3,fiber:5,resin:2},sellPrice:{medicinalHerb:3,fiber:2,resin:4},buyPrice:{rabbitPelt:3,deerPelt:8,wolfPelt:12,rabbitMeat:2},
    specialTrade:{itemKey:"scentDial",label:"Scent Dial",kind:"tracker",description:"A hand-built tracker that reads weaker sign farther out."},
    lines:{bright:"You're in luck. I'm in a buying mood.",flat:"Say what you need and keep it simple.",sour:"Don't make me regret stopping here."}
  },
  {
    id:"orrin_pike",name:"Orrin Pike",voice:"old_neighbor",temperament:"kind",route:"north_trader_road",home:{c:99,r:98},hours:[11,19],travelMinutes:70,floppies:54,
    sells:{wood:4,cordage:3,ironOre:2},sellPrice:{wood:2,cordage:4,ironOre:5},buyPrice:{rabbitPelt:2,deerPelt:9,wolfPelt:14,rabbitMeat:2},
    specialTrade:{itemKey:"longspringTrap",label:"Longspring Trap",kind:"trap",description:"A one-of-a-kind field trap with a stronger catch spring."},
    lines:{steady:"Good to see you. If I can make the trail easier, I will."}
  },
  {
    id:"sable_rook",name:"Sable Rook",voice:"hardcase",temperament:"abrasive",route:"east_trader_road",home:{c:100,r:98},hours:[17,24],travelMinutes:65,floppies:42,
    sells:{scrapMetal:3,copperOre:2,hardwood:2},sellPrice:{scrapMetal:5,copperOre:7,hardwood:6},buyPrice:{rabbitPelt:3,deerPelt:7,wolfPelt:16,rabbitMeat:1},
    specialTrade:{itemKey:"wolfspike",label:"Wolfspike",kind:"weapon",description:"A brutal trail weapon. Wolves give its carrier more room."},
    lines:{steady:"Buy, sell, or get out of my light."}
  }
];
