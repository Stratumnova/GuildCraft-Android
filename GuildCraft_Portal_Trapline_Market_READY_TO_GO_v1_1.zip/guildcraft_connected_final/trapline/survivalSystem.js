const survivalSystem={
  health:100,food:100,water:100,bagTier:0,bagSlots:[2,4,6,8,10],tent:null,campfire:null,dropCache:null,lastTick:0,fireFuel:0,
  tentStorage:{},tentStorageSlots:12,
  capacity(){return this.bagSlots[this.bagTier]},used(){return Object.values(player.inventory).filter(v=>v>0).length},storageUsed(){return Object.values(this.tentStorage||{}).filter(v=>v>0).length},
  near(kind,range=1){const o=this[kind];return !!o&&Math.max(Math.abs(player.gridColumn-o.column),Math.abs(player.gridRow-o.row))<=range},
  hydrate(s={}){Object.assign(this,{health:s.health??100,food:s.food??100,water:s.water??100,bagTier:Math.min(4,Math.max(0,s.bagTier??0)),tent:s.tent||null,campfire:s.campfire||null,dropCache:s.dropCache||null,fireFuel:Math.max(0,Math.min(100,s.fireFuel||0)),tentStorage:s.tentStorage||{}})},
  snapshot(){return {health:this.health,food:this.food,water:this.water,bagTier:this.bagTier,tent:this.tent,campfire:this.campfire,dropCache:this.dropCache,fireFuel:this.fireFuel,tentStorage:this.tentStorage}},
  tick(dt){
    if(this.fireFuel>0)this.fireFuel=Math.max(0,this.fireFuel-dt*.010);
    this.food=Math.max(0,this.food-dt*.014);this.water=Math.max(0,this.water-dt*.023);
    if(this.food<=0)this.health=Math.max(0,this.health-dt*.18);if(this.water<=0)this.health=Math.max(0,this.health-dt*.32);
    if(this.health<=0)this.knockout();
  },
  nearFire(){return this.campfire&&this.fireFuel>0&&Math.max(Math.abs(player.gridColumn-this.campfire.column),Math.abs(player.gridRow-this.campfire.row))<=5},
  knockout(){
    const lostPrevious=!!this.dropCache,dropped={...player.inventory};player.inventory={};
    this.dropCache={column:player.gridColumn,row:player.gridRow,items:dropped,createdAt:Date.now()};
    if(this.tent){player.gridColumn=this.tent.column;player.gridRow=this.tent.row}else{player.gridColumn=94+Math.floor(Math.random()*9);player.gridRow=94+Math.floor(Math.random()*9)}
    player.targetColumn=null;player.targetRow=null;this.health=60;this.food=Math.max(20,this.food);this.water=Math.max(20,this.water);
    EventConsole.emit('KNOCKOUT','You wake up',`${this.tent?'Recovered at your tent.':'Recovered near Trail Camp.'}${lostPrevious?' The older recovery cache was lost.':''} Your carried inventory is where you fell.`,{},'state')
  },
  recover(){if(!this.dropCache)return false;if(Math.max(Math.abs(player.gridColumn-this.dropCache.column),Math.abs(player.gridRow-this.dropCache.row))>1)return false;const leftovers={};Object.entries(this.dropCache.items||{}).forEach(([k,v])=>{if(v<=0)return;if(!player.addToInventory(k,v))leftovers[k]=v});if(Object.keys(leftovers).length){this.dropCache.items=leftovers;EventConsole.emit('RECOVERY','Pack full','Some dropped gear remains in the recovery cache.',{},'state');return true}this.dropCache=null;EventConsole.emit('RECOVERY','Cache recovered','All dropped inventory recovered.',{},'milestone');return true},
  sleep(){if(!this.near('tent',1))return false;clock.skipToMorning();this.health=Math.min(100,this.health+35);this.food=Math.max(0,this.food-8);this.water=Math.max(0,this.water-10);EventConsole.emit('CAMP','Slept until morning','The Wild advanced while you slept.',{},'state');return true},
  place(kind){const key=kind==='tent'?'tentKit':'campfireKit';if((player.inventory[key]||0)<1||this[kind])return false;player.inventory[key]--;this[kind]={column:player.gridColumn,row:player.gridRow};EventConsole.emit('CAMP',kind==='tent'?'Tent placed':'Campfire placed',`(${player.gridColumn}, ${player.gridRow})`,{},'state');return true},
  pickup(kind){const o=this[kind];if(!o||!this.near(kind,1))return false;if(kind==='tent'&&this.storageUsed()>0){EventConsole.emit('CAMP','Cannot pack tent','Empty tent storage first.',{},'state');return false}if(!player.addToInventory(kind==='tent'?'tentKit':'campfireKit',1))return false;this[kind]=null;if(kind==='campfire')this.fireFuel=0;return true},
  store(item,qty=1){if(!this.near('tent',1)||(player.inventory[item]||0)<qty)return false;const exists=(this.tentStorage[item]||0)>0;if(!exists&&this.storageUsed()>=this.tentStorageSlots)return false;player.inventory[item]-=qty;this.tentStorage[item]=(this.tentStorage[item]||0)+qty;return true},
  take(item,qty=1){if(!this.near('tent',1)||(this.tentStorage[item]||0)<qty)return false;if(!player.addToInventory(item,qty))return false;this.tentStorage[item]-=qty;return true},
  drinkNatural(){if(!ecologyField.tiles.length)return false;const h=ecologyField.get(player.gridColumn,player.gridRow).habitat;if(!['creek','wet-ground'].includes(h))return false;this.water=Math.min(100,this.water+50);EventConsole.emit('SURVIVAL','Drank water',`from ${h.replace('-',' ')}`,{},'state');return true},
  cook(raw){if(!this.nearFire()||(player.inventory[raw]||0)<1)return false;const cooked=`cooked:${raw}`;player.inventory[raw]--;if(!player.addToInventory(cooked,1)){player.inventory[raw]++;return false}return true},
  eat(item){if((player.inventory[item]||0)<1)return false;let value=0;if(item.startsWith('cooked:'))value=36;else if(item.endsWith('Meat'))value=12;else return false;player.inventory[item]--;this.food=Math.min(100,this.food+value);if(item.startsWith('cooked:'))this.health=Math.min(100,this.health+4);return true},
  useTonic(){if((player.inventory.fieldTonic||0)<1)return false;player.inventory.fieldTonic--;this.health=Math.min(100,this.health+32);this.water=Math.min(100,this.water+8);EventConsole.emit('SURVIVAL','Field tonic used','Health restored.',{},'state');return true}
};
survivalSystem.equipBestBag=function(){for(let tier=4;tier>=1;tier--){const k=`bagTier${tier}`;if((player.inventory[k]||0)>0){this.bagTier=Math.max(this.bagTier,tier);player.inventory[k]--;EventConsole.emit('GEAR','Bag equipped',`${this.capacity()} carry slots`,{},'state');return true}}return false};
survivalSystem.feedFire=function(){if(!this.near('campfire',1)||(player.inventory.wood||0)<1)return false;player.inventory.wood--;this.fireFuel=Math.min(100,this.fireFuel+30);return true};
