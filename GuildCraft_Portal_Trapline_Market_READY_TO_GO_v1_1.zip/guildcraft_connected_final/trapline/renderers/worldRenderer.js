const WorldRenderer = {
  id:'world',
  terrainColor(kind){return ({'brush':'#354b36','grassland':'#58694a','wet-ground':'#405b4f','creek':'#48636a','legacy-cut':'#3d4440'})[kind]||'#536447';},
  drawTerrain(ctx){
    const b=camera.visibleCellBounds(1);
    for(let y=b.top;y<=b.bottom;y++)for(let x=b.left;x<=b.right;x++){
      const tile=ecologyField.get(x,y);if(!tile)continue;const p=grid.cellToPixels(x,y);ctx.fillStyle=this.terrainColor(tile.habitat);ctx.fillRect(p.x,p.y,grid.cellSizePixels+1,grid.cellSizePixels+1);
      const hash=(x*31+y*17+x*y)%29;
      if(tile.habitat==='brush'&&hash<5){ctx.fillStyle='rgba(16,39,21,.48)';ctx.beginPath();ctx.arc(p.x+9+(hash*4),p.y+14+(hash%3)*5,5+hash%4,0,Math.PI*2);ctx.fill();}
      if(tile.habitat==='grassland'&&hash<4){ctx.strokeStyle='rgba(210,215,165,.13)';ctx.beginPath();ctx.moveTo(p.x+12,p.y+31);ctx.lineTo(p.x+9,p.y+22);ctx.moveTo(p.x+18,p.y+33);ctx.lineTo(p.x+20,p.y+24);ctx.stroke();}
      if(tile.habitat==='legacy-cut'){ctx.fillStyle='rgba(95,103,98,.16)';ctx.fillRect(p.x+3,p.y+8,34,24);if((x+y)%3===0){ctx.strokeStyle='rgba(176,184,174,.20)';ctx.beginPath();ctx.moveTo(p.x+4,p.y+20);ctx.lineTo(p.x+36,p.y+20);ctx.stroke();}}
      if(tile.habitat==='creek'){ctx.strokeStyle='rgba(200,225,228,.15)';ctx.beginPath();ctx.moveTo(p.x+3,p.y+11);ctx.quadraticCurveTo(p.x+19,p.y+7,p.x+37,p.y+13);ctx.moveTo(p.x+5,p.y+27);ctx.quadraticCurveTo(p.x+19,p.y+22,p.x+35,p.y+28);ctx.stroke();}
      if(tile.habitat==='wet-ground'&&hash<6){ctx.fillStyle='rgba(20,45,38,.22)';ctx.beginPath();ctx.ellipse(p.x+20,p.y+25,11,5,0,0,Math.PI*2);ctx.fill();}
    }
  },
  drawLandmarks(ctx){
    mapContent.landmarks.forEach(l=>{if(!camera.isCellVisible(l.column,l.row,2))return;const p=grid.cellToPixels(l.column,l.row);ctx.save();ctx.translate(p.x+20,p.y+20);
      if(l.kind==='camp'){ctx.fillStyle='#6c553b';ctx.fillRect(-16,-6,32,16);ctx.fillStyle='#8d7653';ctx.beginPath();ctx.moveTo(-18,-6);ctx.lineTo(0,-22);ctx.lineTo(18,-6);ctx.closePath();ctx.fill();}
      else if(l.kind==='legacy'){ctx.fillStyle='#68716a';ctx.fillRect(-14,-16,28,32);ctx.fillStyle='#303632';ctx.fillRect(-7,-10,14,8);ctx.strokeStyle='rgba(190,200,190,.35)';ctx.strokeRect(-14,-16,28,32);}
      else if(l.kind==='natural'){ctx.fillStyle='#51482f';ctx.fillRect(-5,-17,10,30);ctx.fillStyle='#34492f';ctx.beginPath();ctx.arc(0,-18,16,0,Math.PI*2);ctx.fill();}
      else {ctx.fillStyle='#4f6c5e';ctx.beginPath();ctx.ellipse(0,4,18,10,0,0,Math.PI*2);ctx.fill();}
      if(simulationBands.distance(l.column,l.row)<=5){ctx.fillStyle='rgba(15,18,14,.72)';ctx.fillRect(-42,24,84,14);ctx.fillStyle='#e6dbc5';ctx.font='10px Georgia';ctx.textAlign='center';ctx.fillText(l.label,0,34);}ctx.restore();
    });
  },
  drawPlayer(ctx){const p=grid.cellToPixels(player.gridColumn,player.gridRow);ctx.save();ctx.translate(p.x+20,p.y+20);ctx.fillStyle='#d8d0be';ctx.beginPath();ctx.arc(0,-9,6,0,Math.PI*2);ctx.fill();ctx.fillStyle='#6e745f';ctx.fillRect(-7,-2,14,18);ctx.fillStyle='#292c25';ctx.fillRect(-8,14,6,8);ctx.fillRect(2,14,6,8);ctx.strokeStyle='rgba(235,225,205,.45)';ctx.strokeRect(-8,-3,16,19);ctx.restore();},
  draw(ctx){
    ctx.clearRect(0,0,800,800);camera.beginWorld(ctx);this.drawTerrain(ctx);
    mapContent.trails.forEach(route=>{ctx.strokeStyle='rgba(169,151,111,.15)';ctx.lineWidth=9;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();route.points.forEach((pt,i)=>{const p=grid.cellToPixels(pt[0],pt[1]);const x=p.x+20,y=p.y+20;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();});
    this.drawLandmarks(ctx);resourceNodes.draw(ctx);
    player.placedTraps.forEach(trap=>{if(!camera.isCellVisible(trap.column,trap.row,2))return;const p=grid.cellToPixels(trap.column,trap.row);ctx.save();ctx.translate(p.x+20,p.y+22);ctx.strokeStyle=trap.specialType==='longspring'?'#d1b56a':'#aa8d52';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(0,0,13,8,0,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(-9,-5);ctx.lineTo(9,5);ctx.moveTo(-9,5);ctx.lineTo(9,-5);ctx.stroke();ctx.restore();});
    groundDrops.draw(ctx);trackingSigns.draw(ctx);animal.draw(ctx);uniqueBlackRabbit.drawWorld(ctx);traders.draw(ctx,false);this.drawPlayer(ctx);camera.endWorld(ctx);
    const h=(clock.totalGameMinutes%(24*60))/60;const darkness=h<5||h>=21?.34:h<7||h>=19?.18:0;if(darkness){ctx.fillStyle=`rgba(10,17,22,${darkness})`;ctx.fillRect(0,0,800,800);}const g=ctx.createRadialGradient(400,400,245,400,400,570);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(4,8,5,.36)');ctx.fillStyle=g;ctx.fillRect(0,0,800,800);
    ctx.fillStyle='rgba(12,16,12,.72)';ctx.fillRect(12,12,126,25);ctx.fillStyle='#d8d3c4';ctx.font='12px ui-monospace,monospace';ctx.fillText(`${player.gridColumn},${player.gridRow} · ${clock.getFormattedTime()}`,20,29);
  }
};
