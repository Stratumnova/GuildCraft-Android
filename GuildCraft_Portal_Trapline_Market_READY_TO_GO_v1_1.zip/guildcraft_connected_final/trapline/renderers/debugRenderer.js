const DebugRenderer = {
  id:"debug",
  draw(ctx){
    ctx.clearRect(0,0,800,800);ctx.fillStyle="#1d261f";ctx.fillRect(0,0,800,800);camera.beginWorld(ctx);grid.draw(ctx);resourceNodes.draw(ctx);
    player.placedTraps.forEach(trap=>{if(!camera.isCellVisible(trap.column,trap.row,2))return;const p=grid.cellToPixels(trap.column,trap.row);ctx.fillStyle="#d4af37";ctx.beginPath();ctx.moveTo(p.x+20,p.y+6);ctx.lineTo(p.x+34,p.y+34);ctx.lineTo(p.x+6,p.y+34);ctx.closePath();ctx.fill();});
    animal.draw(ctx);uniqueBlackRabbit.drawDebug(ctx);traders.draw(ctx,true);const pp=grid.cellToPixels(player.gridColumn,player.gridRow);ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(pp.x+20,pp.y+20,15,0,Math.PI*2);ctx.fill();camera.endWorld(ctx);
    ctx.fillStyle="rgba(0,0,0,.55)";ctx.fillRect(8,8,205,44);ctx.fillStyle="#d7e6d7";ctx.font="12px monospace";ctx.fillText(`WORLD ${grid.columns}x${grid.rows} | VIEW ~20x20`,16,26);ctx.fillText(`CAM ${Math.round(camera.x)},${Math.round(camera.y)}`,16,43);
  }
};
