// reputation.js
// -----------------------------------------------------------------------------
// Per-species trapper reputation: a running, never-decreasing count of
// successful catches, backed by PermanentLedger (GuildCraft toolkit).
// PermanentLedger is in-memory only, so this hydrates from/persists to
// localStorage the same way backendApi.js does for Timesheet traits -
// same pattern, applied to Trapline's own local progression data instead
// of universal account traits.
// -----------------------------------------------------------------------------

const reputation = {
  _prefix(playerId) {
    return PermanentLedger.buildKey("reputation", playerId) + ":";
  },

  _hydrate(playerId) {
    const raw = localStorage.getItem(`reputationLedger_${playerId}`);
    if (!raw) return;
    const stored = JSON.parse(raw);
    Object.entries(stored).forEach(([speciesKey, value]) => {
      PermanentLedger.raise(PermanentLedger.buildKey("reputation", playerId, speciesKey), value);
    });
  },

  _persist(playerId) {
    const prefix = this._prefix(playerId);
    const snapshot = PermanentLedger.snapshot(prefix);
    const stored = {};
    Object.entries(snapshot).forEach(([fullKey, value]) => {
      stored[fullKey.slice(prefix.length)] = value;
    });
    localStorage.setItem(`reputationLedger_${playerId}`, JSON.stringify(stored));
  },

  raise(playerId, speciesKey) {
    this._hydrate(playerId);
    PermanentLedger.add(PermanentLedger.buildKey("reputation", playerId, speciesKey), 1);
    this._persist(playerId);
    const newValue = this.get(playerId, speciesKey);
    EventConsole.emit(
      "REPUTATION", `${speciesKey} reputation raised`, `now at ${newValue}`,
      { playerId, species: speciesKey, value: newValue }, "milestone"
    );
    return newValue;
  },

  get(playerId, speciesKey) {
    this._hydrate(playerId);
    return PermanentLedger.get(PermanentLedger.buildKey("reputation", playerId, speciesKey), 0);
  },
};
