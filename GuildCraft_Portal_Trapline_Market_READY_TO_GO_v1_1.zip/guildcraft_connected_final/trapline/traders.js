const traders = {
  state:{},
  defaultRelationship(t){return {LIKE:t.temperament==='kind'?3:t.temperament==='abrasive'?-2:0,TRUST:1,FEAR:0,DEBT:0,LOYALTY:0,SUSPICION:t.temperament==='abrasive'?2:0,RESPECT:1,NEED:0};},
  setup(saved){
    traderContent.forEach(t=>{
      const s=saved&&saved[t.id];
      this.state[t.id]=Object.assign({stock:{...t.sells},floppies:t.floppies,visits:0,lastTrade:null,specialTraded:false,relationship:this.defaultRelationship(t),memories:[],lastLine:null,lastSeenDay:null},s||{});
      this.state[t.id].relationship=Object.assign(this.defaultRelationship(t),this.state[t.id].relationship||{});
      this.state[t.id].memories=Array.isArray(this.state[t.id].memories)?this.state[t.id].memories:[];
    });
  },
  snapshot(){ return JSON.parse(JSON.stringify(this.state)); },
  minute(){ return clock.totalGameMinutes%(24*60); },
  hour(){ return Math.floor(this.minute()/60); },
  day(){return Math.floor(clock.totalGameMinutes/(24*60));},
  isPresent(t){ const h=this.hour(); const [a,b]=t.hours; return b===24 ? h>=a : h>=a&&h<b; },
  present(){ return traderContent.filter(t=>this.isPresent(t)); },
  get(id){ return traderContent.find(t=>t.id===id); },
  routeFor(t){return mapContent.trails.find(r=>r.id===t.route);},
  routePoint(t){
    const route=this.routeFor(t); if(!route)return {column:t.home.c,row:t.home.r,status:'camp'};
    const m=this.minute(),start=t.hours[0]*60,end=t.hours[1]*60,travel=t.travelMinutes||60;
    let progress=1,status='camp';
    if(m>=start&&m<start+travel){progress=(m-start)/travel;status='arriving';}
    else if(m>=end-travel&&m<end){progress=(end-m)/travel;status='leaving';}
    const pts=status==='leaving'?[...route.points].reverse():route.points;
    if(status==='camp')return {column:t.home.c,row:t.home.r,status};
    const segs=pts.length-1,scaled=Math.max(0,Math.min(.9999,progress))*segs,i=Math.floor(scaled),f=scaled-i,a=pts[i],b=pts[Math.min(i+1,segs)];
    return {column:Math.round(a[0]+(b[0]-a[0])*f),row:Math.round(a[1]+(b[1]-a[1])*f),status};
  },
  canTrade(t){const p=this.routePoint(t);return this.isPresent(t)&&p.status==='camp'&&Math.max(Math.abs(player.gridColumn-p.column),Math.abs(player.gridRow-p.row))<=8;},
  account(){ return backendApi._readTimesheet(saveState.currentPlayerId); },
  writeAccount(sheet){ backendApi._writeTimesheet(saveState.currentPlayerId,sheet); },
  mood(t){if(t.temperament!=='mercurial')return 'steady';const slot=Math.floor(clock.totalGameMinutes/90)%3;return ['bright','flat','sour'][slot];},
  baseLine(t){return t.lines[this.mood(t)]||t.lines.steady||'.';},
  line(t){return this.state[t.id]?.lastLine||this.baseLine(t);},
  remember(t,text,kind='talk'){const s=this.state[t.id];s.memories.push({kind,text,day:this.day(),minute:this.minute()});if(s.memories.length>12)s.memories=s.memories.slice(-12);},
  relationshipModifier(t){const r=this.state[t.id].relationship;return Math.max(-.12,Math.min(.12,(r.LIKE+r.TRUST+r.RESPECT-r.SUSPICION)/120));},
  priceModifier(t,kind){
    let base=1;
    if(t.temperament==='kind')base=kind==='sell'?.85:1.12;
    else if(t.temperament==='abrasive')base=kind==='sell'?1.15:.9;
    else {const mood=this.mood(t);if(mood==='bright')base=kind==='sell'?.9:1.12;else if(mood==='sour')base=kind==='sell'?1.18:.82;}
    const rel=this.relationshipModifier(t);return kind==='sell'?base-rel:base+rel;
  },
  adjustedPrice(t,base,kind){return Math.max(1,Math.round(base*this.priceModifier(t,kind)));},
  talk(id){
    const t=this.get(id),s=this.state[id];if(!t||!s||!this.canTrade(t))return false;
    const mood=this.mood(t);let line=this.baseLine(t);
    if(t.temperament==='kind'&&s.relationship.TRUST>=4)line='You made it back. Good. Sit a minute if you need to.';
    if(t.temperament==='abrasive'&&s.relationship.RESPECT>=5)line='You keep your word. That puts you ahead of most people.';
    if(t.temperament==='mercurial'&&mood==='sour'&&s.relationship.LIKE>=4)line='Bad day. Not your fault. Make it quick and we stay friends.';
    s.relationship.LIKE=Math.min(10,s.relationship.LIKE+1);s.relationship.TRUST=Math.min(10,s.relationship.TRUST+.5);s.lastLine=line;this.remember(t,line,'talk');
    EventConsole.emit('NPC',`${t.name} spoke`,line,{id,mood},'state');return true;
  },
  onSuccessfulTrade(t,kind,item,price){const s=this.state[t.id];s.relationship.TRUST=Math.min(10,s.relationship.TRUST+.35);s.relationship.RESPECT=Math.min(10,s.relationship.RESPECT+.25);s.visits+=1;const line=t.temperament==='abrasive'?'Fine. Deal.':t.temperament==='kind'?'Fair trade. Safe trails.':this.mood(t)==='bright'?'See? Today likes us.':'Done.';s.lastLine=line;this.remember(t,`${kind} ${item} for ${price} floppies`,'trade');},
  buyFromTrader(id,item){
    const t=this.get(id),s=this.state[id]; if(!t||!s||!this.canTrade(t)||(s.stock[item]||0)<1)return false;
    const price=this.adjustedPrice(t,t.sellPrice[item],'sell'); const sheet=this.account(); if((sheet.floppyBalance||0)<price){s.lastLine=t.temperament==='abrasive'?'Come back when you can pay.':'Not enough floppies for that one.';EventConsole.emit('TRADE','Purchase refused','not enough floppies',{id,item,price},'state'); return false; }
    if(!player.addToInventory(item,1)){s.lastLine='Your pack is full.';EventConsole.emit('PACK','Purchase blocked','Make room before buying another item.',{id,item},'state');return false;}
    sheet.floppyBalance-=price; s.floppies+=price; s.stock[item]-=1; s.lastTrade={kind:'sell',item,at:Date.now()}; this.writeAccount(sheet);this.onSuccessfulTrade(t,'bought',item,price);
    EventConsole.emit('TRADE',`${t.name} sold ${item}`,`${price} floppies`,{id,item,price},'decision'); return true;
  },
  sellToTrader(id,item){
    const t=this.get(id),s=this.state[id]; if(!t||!s||!this.canTrade(t)||(player.inventory[item]||0)<1)return false;
    const base=t.buyPrice[item]; if(!base)return false; const price=this.adjustedPrice(t,base,'buy'); if(s.floppies<price){s.lastLine='I cannot cover that today.';EventConsole.emit('TRADE','Sale refused','trader is short on floppies',{id,item},'state'); return false;}
    player.inventory[item]-=1;s.floppies-=price;s.stock[item]=(s.stock[item]||0)+1;const sheet=this.account();sheet.floppyBalance=(sheet.floppyBalance||0)+price;this.writeAccount(sheet);s.lastTrade={kind:'buy',item,at:Date.now()};this.onSuccessfulTrade(t,'sold',item,price);
    EventConsole.emit('TRADE',`${t.name} bought ${item}`,`${price} floppies`,{id,item,price},'decision');return true;
  },
  canSpecialTrade(id){const t=this.get(id),s=this.state[id];return !!(t&&s&&this.canTrade(t)&&!s.specialTraded&&(player.inventory.liveCottontail||0)>0);},
  specialTrade(id){
    const t=this.get(id),s=this.state[id]; if(!t||!s||!this.canSpecialTrade(id))return false;
    player.inventory.liveCottontail=Math.max(0,(player.inventory.liveCottontail||0)-1);player.addToInventory(t.specialTrade.itemKey,1);s.specialTraded=true;s.lastTrade={kind:'special',item:t.specialTrade.itemKey,at:Date.now()};s.relationship.RESPECT=Math.min(10,s.relationship.RESPECT+3);s.relationship.TRUST=Math.min(10,s.relationship.TRUST+2);s.lastLine=t.temperament==='abrasive'?'You did not get that from me.':t.temperament==='kind'?'Take care of it. It should last you years.':'No floppies. No questions. We are square.';this.remember(t,`private barter: ${t.specialTrade.label}`,'special');
    if(typeof uniqueBlackRabbit!=='undefined')uniqueBlackRabbit.tradeAway(t.id,t.specialTrade.itemKey);
    EventConsole.emit('TRADE',`${t.name} made a private barter`,`${t.specialTrade.label} exchanged for a live Cottontail`,{id,item:t.specialTrade.itemKey},'milestone');return true;
  },
  draw(ctx,debug=false){
    this.present().forEach((t,i)=>{const q=this.routePoint(t);if(!camera.isCellVisible(q.column,q.row,2))return;const p=grid.cellToPixels(q.column,q.row);ctx.save();ctx.translate(p.x+20,p.y+20);ctx.fillStyle=debug?['#d59b62','#7ca0b8','#9c7da8'][i]:['#8c6042','#657a70','#70536d'][i];ctx.beginPath();ctx.arc(0,-7,7,0,Math.PI*2);ctx.fill();ctx.fillRect(-7,1,14,18);ctx.fillStyle='rgba(30,25,20,.8)';ctx.fillRect(-10,17,7,4);ctx.fillRect(3,17,7,4);if(debug){ctx.fillStyle='#fff';ctx.font='10px sans-serif';ctx.fillText(`${t.name} ${q.status}`,-30,34);}else if(simulationBands.distance(q.column,q.row)<=4){ctx.fillStyle='rgba(16,18,14,.75)';ctx.fillRect(-32,-34,64,15);ctx.fillStyle='#eadfca';ctx.font='10px Georgia';ctx.textAlign='center';ctx.fillText(t.name,0,-23);}ctx.restore();});
  }
};
