# Trapline Rebuild v0.9 — release-candidate regression pass

This pass hardens v0.9 rather than expanding the map or simulation.

- Keeps the 192×192 Wild and Active / Aware / Passive / background-tick simulation.
- Fixes the private-barter UI handler so all three live-Cottontail trades actually execute from the rendered trader panel.
- Strengthens the concealed-route contract: the shared marker is written only when the unique specimen is captured, unprocessed, untraded, and exactly one live Cottontail is still in inventory at departure.
- Repairs contradictory legacy saves on load (negative/non-numeric inventory and live specimen remaining after processing/trading).
- Keeps the three personality models and their unique weapon / trap / tracker specimen barters.
- Expands non-destructive Release QA to cover trader temperaments, unique barter items, handler wiring, specimen state consistency, clue eligibility, route hash, four simulation bands, world size, and save schema.
- Save schema advanced to 7; older v0.9 saves remain loadable.

Lore discipline remains Past / Current / Plan. CURRENT implementation: Trapline records the concealed route marker and Portal independently verifies the qualifying live specimen before revealing the route clue.
