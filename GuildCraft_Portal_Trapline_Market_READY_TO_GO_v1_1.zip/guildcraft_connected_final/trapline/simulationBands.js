// simulationBands.js — distance-scaled life simulation for the 192x192 Wild.
// Everything belongs to a band relative to the player. Only the Active band is
// expensive enough to behave frame-to-frame; the rest stays alive at lower rates.
const simulationBands = {
  ACTIVE: "active",
  AWARE: "aware",
  PASSIVE: "passive",
  BACKGROUND: "background",
  activeRadius: 14,
  awareRadius: 30,
  passiveRadius: 62,
  intervals: { active: 1.4, aware: 5.5, passive: 22, background: 70 },

  distance(column, row) {
    return Math.max(Math.abs(column - player.gridColumn), Math.abs(row - player.gridRow));
  },
  bandFor(column, row) {
    const d = this.distance(column, row);
    if (d <= this.activeRadius) return this.ACTIVE;
    if (d <= this.awareRadius) return this.AWARE;
    if (d <= this.passiveRadius) return this.PASSIVE;
    return this.BACKGROUND;
  },
  intervalFor(band) { return this.intervals[band] || this.intervals.background; },
  coarseStepsFor(band) { return band === this.BACKGROUND ? 3 : band === this.PASSIVE ? 2 : 1; },
};
