# GuildCraft Connected Rooms

Authoritative connected browser build.

- `portal/` — R_D Portal v1.1: Player Card/account authority, pause layer, portable snapshot memory card, room bridge, audit/version terminals.
- `trapline/` — Trapline Survival v1.6: **The Wild**, a resource/survival room. Hunting, trapping, gathering, specimens, camps and ground drops. No normal manufacturing.
- `market-stall/` — Market Stall Fieldworks v1.4: economy/crafting room with NPC crafter, player-owned stall, roaming market actors, background supply/demand/currency and Iris requests.

Serve this folder from one origin and open `portal/index.html`. Wild ↔ Market transitions keep the same Portal-owned Player Card inventory and currency; there is no cargo-claim step.

Portable saves use one extensible `GCPS1` snapshot template. Uncollected player-stall till is intentionally not portable and must be physically collected at the stall before it becomes Player Card currency.
