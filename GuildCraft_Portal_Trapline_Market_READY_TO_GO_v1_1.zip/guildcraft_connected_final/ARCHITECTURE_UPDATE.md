# GuildCraft Portal Room Architecture Update

- Portal is the authoritative Player Card/account, portable snapshot owner, pause menu, and room bridge.
- The Wild (Trapline) is resource/survival only. It does not manufacture normal gear.
- Market Stall consumes the same carried inventory. Crossing rooms does not ship/claim cargo.
- Portable card format is `GCPS1.<payload>.<checksum>` and uses one extensible snapshot schema.
- Uncollected player-stall till is deliberately stripped from portable snapshots. The player must physically return to the stall and collect it before it becomes Player Card currency.
- Market has an NPC crafter, player stall progression, background economy, hired seller progression, and three roaming market actors (price agitator, liquidity trader, Wild runner).
- The Wild runner has one hidden one-shot rumor after the hidden cottontail is caught: `Did you hear someone found the Black Cottontail?` No follow-up is attached.
