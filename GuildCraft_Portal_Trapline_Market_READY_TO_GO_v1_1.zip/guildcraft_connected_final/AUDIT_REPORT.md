# GuildCraft Connected Bundle — Correction Audit

Audit date: 2026-09-14

## Result
PASS after correction. The previously identified integration drift has been corrected in this package.

## Corrections applied
- Hidden cottontail capture is now atomic: if the pack cannot accept the live specimen, `captured` is not set and the clue path is not stranded.
- Trapline live header now matches the authoritative **Survival v1.5 Final** build label.
- Normal bait was removed from Trail Trader inventories. Bait remains a Market Stall Fieldworks product.
- Trail Trader stock was reconciled to the current item vocabulary (`medicinalHerb`, `fiber`, `resin`, `wood`, `cordage`, `ironOre`, `scrapMetal`, `copperOre`, `hardwood`).
- `deerHide` trader references were corrected to the current `deerPelt` drop.
- Obsolete local trap-workshop crafting code was removed from Trapline. Normal trap manufacture remains Market Stall → Portal → Trapline.
- Trapline's empty-trap message now directs the player to Market Stall rather than a local Workshop.
- Trapline clue documentation now describes the Portal verification path as CURRENT rather than future Plan.
- Copied Market-Stall endpoint comments/dead category bookkeeping were removed from the Trapline backend stub.
- Trader purchases now refuse cleanly when the player's pack is full instead of charging floppies and losing the item.
- Picking up a placed trap now refuses cleanly when the pack is full instead of deleting the placed trap.
- Ordinary trap catches check carry capacity before removing a population unit/item from the world.
- Iris Vale now uses persisted rotating request sheets instead of a single permanent one-time checklist. Each sheet contains one LIVE request, one DEAD request, and three FETCH requests; the next sheet unlocks after the active sheet is completed. The Field Catalogue remains permanent and separate.

## Connection checks
PASS — Portal launches sibling `trapline/` and `market-stall/` folders.

PASS — Trapline and Market Stall load the same Portal-owned `portal/shared/portalLedger.js`.

PASS — Portal ledger remains schema 4 with directional transfer contracts, checksums, audit history, and claim-once behavior.

PASS — The hidden cottontail remains blocked from ordinary Portal cargo.

PASS — Normal bait is produced by Market Stall and no longer sold by Trapline's roaming traders.

PASS — Obsolete Trapline workshop runtime is no longer loaded or packaged.

PASS — Trapline visible version string is aligned to v1.5.

PASS — Iris request persistence migrated to schema 4 rotating cycles without changing the Field Catalogue schema.

## Regression tests
PASS — All packaged JavaScript files pass `node --check`.

PASS — All packaged JSON files parse successfully.

PASS — All local HTML script/link/image/iframe references resolve to existing files.

PASS — Runtime VM regression: full-pack hidden-cottontail catch leaves the specimen uncaptured and emits a pack-capacity event.

PASS — Runtime VM regression: valid Portal transfer claims exactly once; second claim is rejected by state; checksum validation remains clean.

PASS — Runtime VM regression: hidden cottontail cargo is rejected by the Portal contract.

PASS — Runtime VM regression: Iris request sheets contain 5 requests (1 LIVE, 1 DEAD, 3 FETCH), cannot rotate while unfinished, and advance after completion.

## Browser QA note
The installed Game Studio playtest workflow was used as the QA checklist: boot/link integrity, main interaction contracts, UI/runtime separation, responsive/spatial concerns, and regression-first reporting. A headless Chromium screenshot pass could not complete in this execution container, so this correction audit does **not** claim visual browser verification. The code/runtime/static checks above are the verified scope.

## Architecture status
The intended ownership contract is preserved:

- **Trapline** — extraction, hunting/capture, survival, field use of equipment.
- **Portal** — shared player routing, transfer ledger, provenance, clue verification.
- **Market Stall** — processing/crafting, Iris requests, manufactured weapons/traps/bait/field equipment.

The special trader barters remain intentional exceptions tied to sacrificing the qualifying Cottontail and therefore losing the Portal clue path.
