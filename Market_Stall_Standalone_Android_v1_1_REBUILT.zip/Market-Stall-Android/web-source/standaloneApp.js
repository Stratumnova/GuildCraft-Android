(function(global){
  global.MARKET_STANDALONE=true;
  const app=global.Capacitor?.Plugins?.App;
  if(!app?.addListener)return;
  let lastBackAt=0;
  app.addListener('backButton',()=>{
    const pause=document.getElementById('gcPauseOverlay');
    if(pause){pause.remove();return}
    const terminal=document.getElementById('observerTerminalPanel');
    if(terminal&&!terminal.hidden){terminal.hidden=true;document.getElementById('observerTerminal')?.setAttribute('aria-expanded','false');return}
    if(document.body.classList.contains('toolsOpen')){document.body.classList.remove('toolsOpen');document.getElementById('roomToolsButton')?.setAttribute('aria-expanded','false');return}
    const now=Date.now();
    if(now-lastBackAt<1800){app.exitApp();return}
    lastBackAt=now;
    const readout=document.getElementById('observerReadout');if(readout)readout.textContent='Press Back again to exit Market Stall';
  });
})(window);
