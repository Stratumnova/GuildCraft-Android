const assert = require('assert');
const path = require('path');

const clockPath = path.join(__dirname, '../market-stall/clock.js');
const boundaryPath = path.join(__dirname, '../market-stall/runtime/guildcraftBoundary.js');

const { createGameClock } = require(clockPath);
const { ROOM_CONTRACT_VERSION, validateTransferEnvelope } = require(boundaryPath);

const clock = createGameClock({ startMinutes: 120 });
assert.equal(clock.now(), 120);
clock.advance(15);
assert.equal(clock.now(), 135);
assert.equal(clock.day(), 1);
assert.throws(() => clock.advance(-1), /delta/i);

assert.equal(typeof ROOM_CONTRACT_VERSION, 'string');
const ok = validateTransferEnvelope({
  version: ROOM_CONTRACT_VERSION,
  sourceRoom: 'trapline',
  targetRoom: 'market-stall',
  player: { id: 'player' },
  pack: []
});
assert.equal(ok.ok, true);
assert.equal(validateTransferEnvelope({version:'bad'}).ok, false);

console.log('PASS: standalone Market boundary and clock');
