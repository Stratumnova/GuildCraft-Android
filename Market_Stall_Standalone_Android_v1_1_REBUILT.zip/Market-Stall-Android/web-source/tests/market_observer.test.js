const assert=require('assert');
const {createObserverCamera}=require('../market-stall/runtime/observerCamera.js');

const c=createObserverCamera({home:{x:50,y:50,zoom:1},minZoom:.5,maxZoom:2});
assert.deepEqual(c.snapshot(),{x:50,y:50,zoom:1,followId:null,selectedId:null});
c.follow('npc_food',{x:70,y:30});
assert.equal(c.snapshot().followId,'npc_food');
assert.equal(c.snapshot().x,70);
c.updateFollow({x:72,y:31});
assert.equal(c.snapshot().x,72);
c.pan(5,-2);
assert.equal(c.snapshot().followId,null,'manual pan must break follow');
assert.equal(c.snapshot().x,77);
c.zoomTo(99); assert.equal(c.snapshot().zoom,2);
c.zoomTo(.01); assert.equal(c.snapshot().zoom,.5);
c.select('stall_food_01'); assert.equal(c.snapshot().selectedId,'stall_food_01');
c.home(); assert.deepEqual(c.snapshot(),{x:50,y:50,zoom:1,followId:null,selectedId:'stall_food_01'});
console.log('PASS: Market observer camera');
