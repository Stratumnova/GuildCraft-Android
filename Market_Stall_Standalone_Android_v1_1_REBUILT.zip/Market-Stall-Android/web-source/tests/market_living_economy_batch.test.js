const assert=require('assert');
const {createLivingMarket}=require('../market-stall/runtime/livingMarket.js');
const sim=createLivingMarket({seed:25});
sim.run(7*1440);
const s=sim.snapshot();
assert.equal(s.actors.length>=6,true);
for(const a of s.actors){
  assert(a.needs && Number.isFinite(a.needs.hunger));
  assert(a.location);
  assert(a.currentIntent && a.currentIntent.reason);
  assert(Array.isArray(a.pack));
}
assert(s.events.some(e=>e.type==='NPC_TRAVEL'));
assert(s.events.some(e=>e.type==='NPC_WORK'));
assert(s.events.some(e=>e.type==='NPC_SOURCE'));
assert(s.events.some(e=>e.type==='NPC_PURCHASE'));
assert(s.events.some(e=>e.type==='NPC_CONSUME'));
assert(s.events.some(e=>e.type==='PURCHASE_FAILED'));
assert(s.events.some(e=>e.type==='DAY_BOUNDARY'));
assert(s.events.some(e=>e.type==='NIGHT_STATE'));
assert(s.stalls.every(x=>x.pressure && x.operatorId));
assert(s.health && Array.isArray(s.health.warnings));
assert(s.events.every(e=>Number.isFinite(e.gameMinutes)));
console.log('PASS: living NPC economy batch');
