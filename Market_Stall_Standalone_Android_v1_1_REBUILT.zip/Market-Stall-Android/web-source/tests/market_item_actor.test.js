const assert=require('assert');
const {ITEM_SCOPE,createItemRegistry}=require('../market-stall/runtime/itemRegistry.js');
const {createActorState}=require('../market-stall/runtime/actorState.js');

const r=createItemRegistry();
r.register({itemId:'rabbit_meat',scope:ITEM_SCOPE.GUILDCRAFT,category:'food'});
assert.equal(r.get('rabbit_meat').scope,'GUILDCRAFT');
assert.throws(()=>r.register({itemId:'bad',scope:'EVERYWHERE'}),/scope/i);

const a=createActorState({id:'npc_1',floppies:10});
a.addItem('rabbit_meat',3);
assert.equal(a.quantity('rabbit_meat'),3);
a.removeItem('rabbit_meat',2);
assert.equal(a.quantity('rabbit_meat'),1);
a.credit(5); a.debit(12);
assert.equal(a.floppies,3);
assert.throws(()=>a.debit(4),/funds/i);
assert.throws(()=>a.removeItem('rabbit_meat',2),/quantity/i);
console.log('PASS: canonical Market item and actor state');
