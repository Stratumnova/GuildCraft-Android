const assert=require('assert');
const {createMarketSimulation}=require('../market-stall/runtime/marketSimulation.js');

const sim=createMarketSimulation();
sim.run(3*1440);
const snap=sim.snapshot();
assert(snap.gameMinutes>=4320);
assert(snap.transactions.length>0,'NPC economy should produce sales');
for(const stall of snap.stalls){
 assert(stall.transactions.length>0, `${stall.id} should trade`);
 assert(stall.intents.length>0, `${stall.id} should record operator intents`);
 assert(stall.intents.every(x=>x.reason), 'intents need reasons');
 assert(stall.till>0, `${stall.id} should earn Floppies`);
}
assert(snap.events.some(e=>e.type==='SOURCE_STOCK'),'operators should source stock');
assert(snap.events.some(e=>e.type==='RESTOCK_DISPLAY'),'operators should restock displays');
console.log('PASS: autonomous multi-day Market simulation');
