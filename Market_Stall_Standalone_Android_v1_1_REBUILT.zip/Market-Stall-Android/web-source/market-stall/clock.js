(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.MarketClock = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  function createGameClock(options = {}) {
    let minutes = Number.isFinite(options.startMinutes) ? options.startMinutes : 0;
    return {
      now: () => minutes,
      day: () => Math.floor(minutes / 1440) + 1,
      minuteOfDay: () => ((minutes % 1440) + 1440) % 1440,
      advance(deltaMinutes) {
        if (!Number.isFinite(deltaMinutes) || deltaMinutes < 0) throw new Error('deltaMinutes must be a nonnegative finite number');
        minutes += deltaMinutes;
        return minutes;
      },
      snapshot: () => ({ gameMinutes: minutes })
    };
  }
  return { createGameClock };
});
