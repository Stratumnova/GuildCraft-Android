(function(){
const C=globalThis.MarketObserverCamera,J=globalThis.MarketSimulationJournal,R=globalThis.MarketReportExporter;if(!C||!J||!R)return;
const selectable=['npc_mira','npc_orrin','npc_ves','npc_ada','npc_tomas','npc_ren','stall_food_01','stall_tools_01','stall_salvage_01'];let selectIndex=-1;
const camera=C.createObserverCamera({home:{x:50,y:50,zoom:1}});const journal=J.createSimulationJournal({sessionId:'market-'+Date.now(),build:'market-standalone-dev',schema:'MARKET_REPORT_1',config:{realMinutesPerGameDay:60},initialState:{observer:'home'}});
const $=id=>document.getElementById(id),read=$('observerReadout'),log=$('observerLog'),panel=$('observerTerminalPanel');
function render(){const s=camera.snapshot();read.textContent=`Observer · x ${s.x.toFixed(0)} y ${s.y.toFixed(0)} · ${s.zoom.toFixed(2)}×${s.followId?' · Following '+s.followId:''}`;log.textContent=journal.snapshot().events.concat(journal.snapshot().checkpoints).map(x=>JSON.stringify(x)).join('\n');}
function pan(dx,dy){camera.pan(dx,dy);journal.record({type:'OBSERVER_PAN',gameMinutes:0,dx,dy});render();}
[['observerPanUp',0,-5],['observerPanDown',0,5],['observerPanLeft',-5,0],['observerPanRight',5,0]].forEach(([id,x,y])=>$(id).addEventListener('click',()=>pan(x,y)));
$('observerZoomIn').addEventListener('click',()=>{camera.zoomBy(.1);render();});$('observerZoomOut').addEventListener('click',()=>{camera.zoomBy(-.1);render();});$('observerHome').addEventListener('click',()=>{camera.home();render();});
$('observerFollow').addEventListener('click',()=>{const id=camera.snapshot().selectedId||'npc_mira';camera.follow(id,{x:50,y:50});journal.record({type:'OBSERVER_FOLLOW',actorId:id,gameMinutes:0});render();});
$('observerInspect').addEventListener('click',()=>{selectIndex=(selectIndex+1)%selectable.length;const id=selectable[selectIndex];camera.select(id);journal.record({type:'OBSERVER_INSPECT',selectedId:id,gameMinutes:(globalThis.MarketLiveSimulation?.snapshot().gameMinutes||0)});render();});
function toggle(v){panel.hidden=v===undefined?!panel.hidden:!v;$('observerTerminal').setAttribute('aria-expanded',String(!panel.hidden));}
$('observerTerminal').addEventListener('click',()=>toggle());$('observerTerminalClose').addEventListener('click',()=>toggle(false));
$('observerMark').addEventListener('click',()=>{const s=camera.snapshot();journal.markCheckpoint({gameMinutes:0,selectedId:s.selectedId,followedId:s.followId,recentEventIds:journal.snapshot().events.slice(-10).map(e=>e.eventId)});render();});
$('observerSaveTxt').addEventListener('click',()=>R.saveReportFiles(journal,'market-stall-full-report','txt'));$('observerSaveJson').addEventListener('click',()=>R.saveReportFiles(journal,'market-stall-full-report','json'));
render();globalThis.MarketObserver={camera,journal,render};
})();