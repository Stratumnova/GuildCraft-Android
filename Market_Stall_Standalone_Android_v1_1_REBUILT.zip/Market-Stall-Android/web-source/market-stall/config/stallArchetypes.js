const STALL_ARCHETYPES=Object.freeze({
 FOOD:Object.freeze({id:'food',station:'cook_station',primaryCategories:['food'],demandNeeds:['hunger']}),
 TOOLS:Object.freeze({id:'tools',station:'workbench',primaryCategories:['tool'],demandNeeds:['equipment']}),
 SALVAGE:Object.freeze({id:'salvage',station:'sorting_bench',primaryCategories:['material'],demandNeeds:['production']})
});
module.exports={STALL_ARCHETYPES};
