(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.GuildCraftBoundary = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const ROOM_CONTRACT_VERSION = 'GC-ROOM-1';
  function validateTransferEnvelope(value) {
    if (!value || typeof value !== 'object') return { ok:false, reason:'INVALID_ENVELOPE' };
    if (value.version !== ROOM_CONTRACT_VERSION) return { ok:false, reason:'VERSION_MISMATCH' };
    if (!value.sourceRoom || !value.targetRoom) return { ok:false, reason:'ROOM_REQUIRED' };
    if (!value.player || !value.player.id) return { ok:false, reason:'PLAYER_REQUIRED' };
    if (!Array.isArray(value.pack)) return { ok:false, reason:'PACK_REQUIRED' };
    return { ok:true };
  }
  return { ROOM_CONTRACT_VERSION, validateTransferEnvelope };
});
