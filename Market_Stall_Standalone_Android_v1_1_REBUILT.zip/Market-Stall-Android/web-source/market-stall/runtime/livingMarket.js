(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.LivingMarket=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
function rng(seed){let x=seed|0;return()=>((x=Math.imul(1664525,x)+1013904223|0)>>>0)/4294967296}
function createLivingMarket({seed=25}={}){const random=rng(seed),events=[],ledger=[];let gameMinutes=0,lastDay=0,lastNight=false;
const stalls=[
{id:'stall_food_01',operatorId:'npc_mira',kind:'food',item:'ration',price:5,storage:14,display:6,till:20,pressure:'OK'},
{id:'stall_tools_01',operatorId:'npc_orrin',kind:'tools',item:'field_tool',price:9,storage:10,display:5,till:25,pressure:'OK'},
{id:'stall_salvage_01',operatorId:'npc_ves',kind:'salvage',item:'scrap',price:4,storage:16,display:6,till:15,pressure:'OK'}];
const actors=[
['npc_mira','stall_food_01',34],['npc_orrin','stall_tools_01',28],['npc_ves','stall_salvage_01',18],
['npc_ada',null,22],['npc_tomas',null,3],['npc_ren',null,40]
].map(([id,workplace,floppies],i)=>({id,workplace,occupation:workplace?'vendor':'resident',floppies,pack:[],equipment:[],location:'home_'+id,needs:{hunger:20+i*8,thirst:15+i*5,fatigue:10,safety:5},values:{thrift:.3+random()*.5,quality:.3+random()*.5,community:.3+random()*.5,independence:.3+random()*.5},currentIntent:{type:'REST',reason:'SIMULATION_START'},home:'home_'+id,lastSimulationTime:0}));
function emit(type,data={}){const e={eventId:'evt_'+(events.length+1),gameMinutes,...data,type};events.push(e);return e}
function move(a,to,reason){a.location=to;emit('NPC_TRAVEL',{actorId:a.id,to,reason})}
function intent(a,type,reason){a.currentIntent={type,reason,formedAt:gameMinutes};emit('NPC_INTENT',{actorId:a.id,intent:type,reason})}
function add(a,item,q=1){let r=a.pack.find(x=>x.itemId===item);if(r)r.quantity+=q;else a.pack.push({itemId:item,quantity:q})}
function take(a,item,q=1){let r=a.pack.find(x=>x.itemId===item);if(!r||r.quantity<q)return false;r.quantity-=q;a.pack=a.pack.filter(x=>x.quantity);return true}
function vendorTick(a,s,hour){
 if(hour>=8&&hour<18){if(a.location!==s.id)move(a,s.id,'WORK_OBLIGATION');intent(a,'WORK','SCHEDULED_STALL_SHIFT');emit('NPC_WORK',{actorId:a.id,stallId:s.id});
  if(s.storage<5){intent(a,'SOURCE','STORAGE_BELOW_TARGET');move(a,'wild_boundary','SOURCE_INPUT');add(a,s.item,8);emit('NPC_SOURCE',{actorId:a.id,itemId:s.item,quantity:8});move(a,s.id,'RETURN_TO_STALL');take(a,s.item,8);s.storage+=8}
  if(s.display<3&&s.storage){const q=Math.min(4,s.storage);s.storage-=q;s.display+=q;emit('RESTOCK_DISPLAY',{actorId:a.id,stallId:s.id,itemId:s.item,quantity:q})}
 } else if(a.location!==a.home){intent(a,'RETURN_HOME','SHIFT_ENDED');move(a,a.home,'REST_OBLIGATION')}
}
function customerTick(a,hour){
 if(a.needs.hunger>55){const s=stalls[0];intent(a,'BUY_FOOD','HUNGER_PRESSURE');move(a,s.id,'KNOWN_FOOD_STALL');
  if(s.display>0&&a.floppies>=s.price){a.floppies-=s.price;s.till+=s.price;s.display--;add(a,s.item);const tx={type:'STALL_SALE',stallId:s.id,itemId:s.item,quantity:1,unitPrice:s.price,total:s.price,seller:s.operatorId,buyer:a.id,gameMinutes};ledger.push(tx);emit('NPC_PURCHASE',{...tx,type:undefined,transactionType:tx.type});take(a,s.item);a.needs.hunger=Math.max(0,a.needs.hunger-55);emit('NPC_CONSUME',{actorId:a.id,itemId:s.item,need:'hunger'})}
  else emit('PURCHASE_FAILED',{actorId:a.id,stallId:s.id,itemId:s.item,reason:s.display<=0?'OUT_OF_STOCK':'INSUFFICIENT_FUNDS',wallet:a.floppies,price:s.price});
 }
 if(hour>=20||hour<6){intent(a,'REST','NIGHT_REST');move(a,a.home,'NIGHT_REST');a.needs.fatigue=Math.max(0,a.needs.fatigue-18)}
}
function step(minutes=60){gameMinutes+=minutes;const day=Math.floor(gameMinutes/1440),hour=Math.floor((gameMinutes%1440)/60);if(day!==lastDay){lastDay=day;emit('DAY_BOUNDARY',{day:day+1})}const night=hour>=20||hour<6;if(night!==lastNight){lastNight=night;emit('NIGHT_STATE',{night})}
 for(const a of actors){a.needs.hunger=Math.min(100,a.needs.hunger+3);a.needs.thirst=Math.min(100,a.needs.thirst+2);a.needs.fatigue=Math.min(100,a.needs.fatigue+(night?-2:2));const s=stalls.find(x=>x.operatorId===a.id);if(s)vendorTick(a,s,hour);else customerTick(a,hour);a.lastSimulationTime=gameMinutes}
 // ambient customers make all stalls economically active
 if(hour>=9&&hour<18)for(const s of stalls){if(s.display>0&&random()<.55){s.display--;s.till+=s.price;const tx={type:'STALL_SALE',stallId:s.id,itemId:s.item,quantity:1,unitPrice:s.price,total:s.price,seller:s.operatorId,buyer:'npc_ambient',gameMinutes};ledger.push(tx);emit('NPC_PURCHASE',{...tx,type:undefined,transactionType:tx.type})}}
 for(const s of stalls)s.pressure=s.display<2?'DISPLAY_LOW':s.storage<5?'STORAGE_LOW':'OK';
}
function snapshot(){const warnings=[];for(const s of stalls)if(s.pressure!=='OK')warnings.push(`${s.id}:${s.pressure}`);return{seed,gameMinutes,actors:JSON.parse(JSON.stringify(actors)),stalls:JSON.parse(JSON.stringify(stalls)),events:[...events],transactions:[...ledger],health:{warnings,eventCount:events.length,transactionCount:ledger.length}}}
return{step,run(minutes){while(minutes>0){const d=Math.min(60,minutes);step(d);minutes-=d}},snapshot,actorPosition(id){const i=actors.findIndex(a=>a.id===id);if(i<0)return null;return{x:28+(i%3)*22,y:32+Math.floor(i/3)*25}}};}
return{createLivingMarket};});