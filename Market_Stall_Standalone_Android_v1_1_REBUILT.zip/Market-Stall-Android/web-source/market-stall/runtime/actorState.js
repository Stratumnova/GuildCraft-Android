function createActorState({id,floppies=0,needs={}}={}){if(!id)throw Error('actor id required');if(floppies<0)throw Error('floppies must be nonnegative');const pack=new Map();const actor={
 id,floppies,needs:{hunger:0,thirst:0,fatigue:0,safety:0,...needs},
 addItem(itemId,qty=1){if(qty<=0)throw Error('quantity must be positive');pack.set(itemId,(pack.get(itemId)||0)+qty);return this.quantity(itemId);},
 removeItem(itemId,qty=1){if(qty<=0||this.quantity(itemId)<qty)throw Error('insufficient quantity');pack.set(itemId,this.quantity(itemId)-qty);if(!pack.get(itemId))pack.delete(itemId);return this.quantity(itemId);},
 quantity(itemId){return pack.get(itemId)||0;},
 credit(amount){if(amount<0)throw Error('amount');this.floppies+=amount;return this.floppies;},
 debit(amount){if(amount<0||amount>this.floppies)throw Error('insufficient funds');this.floppies-=amount;return this.floppies;},
 packSnapshot(){return [...pack].map(([itemId,quantity])=>({itemId,quantity}));}
};return actor;}
module.exports={createActorState};
