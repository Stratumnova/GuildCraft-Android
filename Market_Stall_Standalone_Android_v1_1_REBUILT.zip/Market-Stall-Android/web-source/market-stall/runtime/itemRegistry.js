const ITEM_SCOPE=Object.freeze({LOCAL:'LOCAL',PORTABLE:'PORTABLE',GUILDCRAFT:'GUILDCRAFT'});
function createItemRegistry(){const items=new Map();return{
 register(def){if(!def||!def.itemId)throw Error('itemId required');if(!Object.values(ITEM_SCOPE).includes(def.scope))throw Error('invalid item scope');const frozen=Object.freeze({...def});items.set(def.itemId,frozen);return frozen;},
 get(id){return items.get(id)||null;},has(id){return items.has(id);},all(){return [...items.values()];}
};}
module.exports={ITEM_SCOPE,createItemRegistry};
