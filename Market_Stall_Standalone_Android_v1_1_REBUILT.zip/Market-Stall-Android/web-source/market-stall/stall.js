function createStall({id,archetype,operatorId}){if(!id||!archetype)throw Error('stall identity and archetype required');const storage=new Map(),display=new Map();const state={id,archetype,operatorId,till:0,transactions:[],
 addStorage(itemId,qty){if(qty<=0)throw Error('quantity');storage.set(itemId,(storage.get(itemId)||0)+qty);},
 storageQty:id=>storage.get(id)||0,displayQty:id=>display.get(id)?.quantity||0,
 restockDisplay(itemId,qty,askPrice){if(qty<=0||state.storageQty(itemId)<qty)throw Error('insufficient storage');storage.set(itemId,state.storageQty(itemId)-qty);display.set(itemId,{quantity:state.displayQty(itemId)+qty,askPrice});},
 recordSale(itemId,qty,buyerId){const row=display.get(itemId);if(!row||qty<=0||row.quantity<qty)throw Error('insufficient display');row.quantity-=qty;const total=qty*row.askPrice;state.till+=total;const tx={type:'STALL_SALE',stallId:id,itemId,quantity:qty,unitPrice:row.askPrice,total,seller:operatorId,buyer:buyerId};state.transactions.push(tx);return tx;}
};return state;}
module.exports={createStall};
