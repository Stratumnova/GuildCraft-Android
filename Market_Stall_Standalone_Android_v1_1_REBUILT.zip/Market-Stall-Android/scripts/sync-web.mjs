import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
for(const entry of ['index.html','standaloneApp.js','market-stall','shared','assets','portal']){
  const from=path.join(root,'web-source',entry),to=path.join(root,'www',entry);
  if(!fs.existsSync(from))throw new Error(`Missing standalone source: ${from}`);
  const stat=fs.statSync(from);
  if(stat.isDirectory()){
    fs.mkdirSync(to,{recursive:true});
    for(const child of fs.readdirSync(from))fs.cpSync(path.join(from,child),path.join(to,child),{recursive:true,force:true});
  }else fs.cpSync(from,to,{force:true});
}
const marketHtmlPath=path.join(root,'www','market-stall','index.html');
let marketHtml=fs.readFileSync(marketHtmlPath,'utf8');
marketHtml=marketHtml.replace('id="roomPortalButton">PORTAL<','id="roomPortalButton">HOME<');
if(!marketHtml.includes('../standaloneApp.js'))marketHtml=marketHtml.replace('<script src="main.js"></script>','<script src="../standaloneApp.js"></script>\n  <script src="main.js"></script>');
fs.writeFileSync(marketHtmlPath,marketHtml);

const roomShellPath=path.join(root,'www','shared','roomShell.js');
let roomShell=fs.readFileSync(roomShellPath,'utf8');
if(!roomShell.includes('global.MARKET_STANDALONE'))roomShell=roomShell.replace("      go('../portal/index.html','portal',opts.roomId,opts.playerId)","      if(global.MARKET_STANDALONE){global.location.reload();return}\n      go('../portal/index.html','portal',opts.roomId,opts.playerId)");
fs.writeFileSync(roomShellPath,roomShell);
console.log('Synced Market Stall standalone web assets');
