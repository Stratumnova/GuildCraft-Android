package org.neocities.guildcraft.marketstall;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
