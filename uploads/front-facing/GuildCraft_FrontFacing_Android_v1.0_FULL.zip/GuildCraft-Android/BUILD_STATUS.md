# Build Status

## Completed

- Capacitor 8.5.2 project generated.
- Android native project generated under `android/`.
- GuildCraft Portal configured as the application entry point.
- Portal, Trapline, and Market Stall bundled locally.
- `@capacitor/app` 8.1.1 registered for Android Back handling.
- Activity locked to `sensorLandscape`, allowing either landscape rotation.
- Web-to-Android synchronization completed.
- Android wrapper contract test passed.
- Modified JavaScript passed Node syntax validation.

## APK assembly boundary

The debug APK was not assembled in the packaging workspace because Gradle could not reach `services.gradle.org` to download Gradle 8.14.3, and no local Android SDK or cached Gradle distribution was available.

Open this project in Android Studio or run `npm run build:debug` on a machine with the Android SDK and normal access to Gradle and Google Maven. The resulting file will be:

`android/app/build/outputs/apk/debug/app-debug.apk`
