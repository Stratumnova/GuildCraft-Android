import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source = path.join(project, 'web-source');
const www = path.join(project, 'www');
const rooms = ['portal', 'trapline', 'market-stall'];

if (!fs.existsSync(source)) {
  throw new Error(`GuildCraft web source not found: ${source}`);
}

for (const room of rooms) {
  const from = path.join(source, room);
  const to = path.join(www, room);
  fs.rmSync(to, { recursive: true, force: true });
  fs.cpSync(from, to, { recursive: true });
}

console.log(`Synced ${rooms.join(', ')} into ${www}`);
