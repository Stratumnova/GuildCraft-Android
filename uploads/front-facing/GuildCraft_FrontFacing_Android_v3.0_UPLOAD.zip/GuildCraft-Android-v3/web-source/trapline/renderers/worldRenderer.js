const WorldRenderer={
  id:'world',
  terrainKey(kind,x,y){
    const h=(x*37+y*19+x*y)%97;
    if(kind==='legacy-cut')return h%4===0?'marketPlate':'oldRoad';
    if(kind==='creek'||kind==='wet-ground')return 'sageScrub';
    if(kind==='brush')return h%5===0?'basalt':'sageScrub';
    if(h%17===0)return 'sandstone';
    return 'dryGrass';
  },
  drawTerrain(ctx){
    const b=camera.visibleCellBounds(1);
    for(let depth=b.top+b.left;depth<=b.bottom+b.right;depth++){
      for(let y=b.top;y<=b.bottom;y++){
        const x=depth-y;if(x<b.left||x>b.right)continue;
        const t=ecologyField.get(x,y);if(!t)continue;
        const p=grid.cellCenter(x,y),key=this.terrainKey(t.habitat,x,y),im=VisualRuntime.get('terrain',key);
        grid.iso.drawTile(ctx,im,p.x,p.y,{fallback:'#77734f',stroke:'rgba(239,222,163,.105)'});
        if(t.habitat==='creek'){
          ctx.save();ctx.strokeStyle='rgba(118,174,170,.46)';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(p.x-grid.iso.tileWidth*.28,p.y);ctx.quadraticCurveTo(p.x,p.y-grid.iso.tileHeight*.22,p.x+grid.iso.tileWidth*.28,p.y);ctx.stroke();ctx.restore();
        }
      }
    }
  },
  drawRoads(ctx){
    const routes=[...(mapContent.trails||[]),...(TRAPLINE_VISUAL_LAYOUT.roads||[])];
    routes.forEach(route=>{
      ctx.save();ctx.strokeStyle=route.id==='market-road'?'rgba(180,143,83,.72)':'rgba(164,139,94,.40)';ctx.lineWidth=route.id==='market-road'?18:10;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();
      route.points.forEach((pt,i)=>{const p=grid.cellCenter(pt[0],pt[1]);i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)});ctx.stroke();
      if(route.id==='market-road'){ctx.strokeStyle='rgba(45,43,37,.48)';ctx.lineWidth=2;ctx.setLineDash([9,9]);ctx.stroke();ctx.setLineDash([])}ctx.restore();
    });
  },
  drawProps(ctx){
    [...(TRAPLINE_VISUAL_LAYOUT.visualProps||[])].sort((a,b)=>(a.column+a.row)-(b.column+b.row)).forEach(o=>{
      if(!camera.isCellVisible(o.column,o.row,5))return;const p=grid.cellCenter(o.column,o.row),size=84*(o.scale||1);grid.iso.shadow(ctx,p.x,p.y,size*.48,10,.25);VisualRuntime.sprite(ctx,'props',o.kind,p.x,p.y+5,size,.98)
    })
  },
  drawLandmarks(ctx){
    [...mapContent.landmarks].sort((a,b)=>(a.column+a.row)-(b.column+b.row)).forEach(l=>{
      if(!camera.isCellVisible(l.column,l.row,2))return;const p=grid.cellCenter(l.column,l.row);let key='juniper',size=94;
      if(l.kind==='camp'){key='marketStall';size=102}else if(l.kind==='legacy'){key='novaTerminal';size=84}
      grid.iso.shadow(ctx,p.x,p.y,size*.5,11,.28);VisualRuntime.sprite(ctx,'props',key,p.x,p.y+4,size,.95);
      if(simulationBands.distance(l.column,l.row)<=5){ctx.save();ctx.font='10px Georgia';ctx.textAlign='center';const w=88;ctx.fillStyle='rgba(12,14,11,.80)';ctx.fillRect(p.x-w/2,p.y+24,w,16);ctx.fillStyle='#eee1bd';ctx.fillText(l.label,p.x,p.y+36);ctx.restore()}
    })
  },
  drawGate(ctx){
    const g=TRAPLINE_VISUAL_LAYOUT.anchors.marketRoadGate;if(!camera.isCellVisible(g.column,g.row,5))return;const p=grid.cellCenter(g.column,g.row);
    ctx.save();ctx.strokeStyle='rgba(222,190,102,.78)';ctx.lineWidth=2;ctx.setLineDash([6,5]);grid.iso.diamondPath(ctx,p.x,p.y);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='rgba(12,13,10,.84)';ctx.fillRect(p.x-66,p.y-58,132,20);ctx.fillStyle='#f2df9b';ctx.font='bold 10px ui-monospace,monospace';ctx.textAlign='center';ctx.fillText('MARKET ROAD',p.x,p.y-44);ctx.restore();
  },
  drawTarget(ctx){const selected=typeof InteractionRuntime!=='undefined'?InteractionRuntime.target(player):null;if(selected){const q=InteractionRuntime.pos(selected),sp=grid.cellCenter(q.column,q.row);ctx.save();ctx.strokeStyle='rgba(238,185,76,.95)';ctx.lineWidth=3;grid.iso.diamondPath(ctx,sp.x,sp.y);ctx.stroke();ctx.restore()}if(player.targetColumn==null||player.targetRow==null)return;const p=grid.cellCenter(player.targetColumn,player.targetRow);ctx.save();ctx.strokeStyle='rgba(240,207,116,.82)';ctx.lineWidth=2;grid.iso.diamondPath(ctx,p.x,p.y);ctx.stroke();ctx.fillStyle='rgba(240,207,116,.10)';grid.iso.diamondPath(ctx,p.x,p.y);ctx.fill();ctx.restore()},
  drawPlayer(ctx){const pp=ActorPresentation.projectedPoint(player,grid),p={x:pp.x,y:pp.y},pose=pp.pose;grid.iso.shadow(ctx,p.x,p.y,34*(pose.moving?.94:1),9,.32);if(!VisualRuntime.spritePose(ctx,'npcs','player',p.x,p.y+2,70,pose,1)){ctx.fillStyle='#ddd';ctx.fillRect(p.x-8,p.y-24+pose.bob,16,25)}if(pose.action)VisualRuntime.effect(ctx,pose.action,p.x+24,p.y-50,30,.72+.28*pose.actionStrength)},
  buildDepthQueue(){
    const q=[];
    (TRAPLINE_VISUAL_LAYOUT.visualProps||[]).forEach(o=>{if(camera.isCellVisible(o.column,o.row,5))q.push({depth:o.column+o.row+.10,kind:'prop',data:o})});
    (mapContent.landmarks||[]).forEach(l=>{if(camera.isCellVisible(l.column,l.row,2))q.push({depth:l.column+l.row+.12,kind:'landmark',data:l})});
    (animal.list||[]).forEach(u=>{const s=speciesContent[u.speciesKey];if((s.activity?.[clock.phase()]||0)>.05&&u.band===simulationBands.ACTIVE&&camera.isCellVisible(u.gridColumn,u.gridRow,2))q.push({depth:u.gridColumn+u.gridRow+.45,kind:'animal',data:u})});
    q.push({depth:player.gridColumn+player.gridRow+.7,kind:'player'});
    return q.sort((a,b)=>a.depth-b.depth);
  },
  drawDepthQueue(ctx){
    this.buildDepthQueue().forEach(it=>{
      if(it.kind==='prop'){const o=it.data,p=grid.cellCenter(o.column,o.row),size=84*(o.scale||1);grid.iso.shadow(ctx,p.x,p.y,size*.48,10,.25);VisualRuntime.sprite(ctx,'props',o.kind,p.x,p.y+5,size,.98);return;}
      if(it.kind==='landmark'){const l=it.data,p=grid.cellCenter(l.column,l.row);let key='juniper',size=94;if(l.kind==='camp'){key='marketStall';size=102}else if(l.kind==='legacy'){key='novaTerminal';size=84}grid.iso.shadow(ctx,p.x,p.y,size*.5,11,.28);VisualRuntime.sprite(ctx,'props',key,p.x,p.y+4,size,.95);if(simulationBands.distance(l.column,l.row)<=5){ctx.save();ctx.font='10px Georgia';ctx.textAlign='center';ctx.fillStyle='rgba(12,14,11,.80)';ctx.fillRect(p.x-44,p.y+24,88,16);ctx.fillStyle='#eee1bd';ctx.fillText(l.label,p.x,p.y+36);ctx.restore()}return;}
      if(it.kind==='animal'){animal.drawUnit(ctx,it.data);return;}
      if(it.kind==='player')this.drawPlayer(ctx);
    });
  },
  draw(ctx){
    CanvasRuntime.prepare(ctx);const w=CanvasRuntime.width(ctx.canvas),h=CanvasRuntime.height(ctx.canvas);ctx.clearRect(0,0,w,h);ctx.fillStyle='#14140f';ctx.fillRect(0,0,w,h);
    camera.beginWorld(ctx);this.drawTerrain(ctx);this.drawRoads(ctx);this.drawGate(ctx);resourceNodes.draw(ctx);
    player.placedTraps.forEach(trap=>{if(!camera.isCellVisible(trap.column,trap.row,2))return;const p=grid.cellCenter(trap.column,trap.row);ctx.save();ctx.translate(p.x,p.y+2);ctx.strokeStyle=trap.specialType==='longspring'?'#dec178':'#a98d58';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(0,0,13,5,0,0,Math.PI*2);ctx.stroke();ctx.restore()});
    groundDrops.draw(ctx);trackingSigns.draw(ctx);this.drawDepthQueue(ctx);uniqueBlackRabbit.drawWorld(ctx);traders.draw(ctx,false);this.drawTarget(ctx);camera.endWorld(ctx);
    const hr=(clock.totalGameMinutes%(24*60))/60,dark=hr<5||hr>=21?.34:hr<7||hr>=19?.18:0;if(dark){ctx.fillStyle=`rgba(9,14,20,${dark})`;ctx.fillRect(0,0,w,h)}
    const g=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.22,w/2,h/2,Math.max(w,h)*.72);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(2,4,3,.36)');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
    ctx.fillStyle='rgba(10,12,9,.72)';ctx.fillRect(12,h-42,190,28);ctx.fillStyle='#eee4c8';ctx.font='12px ui-monospace,monospace';ctx.textAlign='left';ctx.fillText(`${player.gridColumn},${player.gridRow} · ${clock.getFormattedTime()}`,20,h-23)
  }
};
