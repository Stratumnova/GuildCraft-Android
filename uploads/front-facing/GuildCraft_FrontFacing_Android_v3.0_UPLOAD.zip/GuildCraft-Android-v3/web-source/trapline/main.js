// main.js
// -----------------------------------------------------------------------------
// Trapline's game loop and UI glue. Tap/click to move (same pattern as
// Market Stall 1). Trap kits are placed at the player's current cell;
// gathering and trap-checking both require standing on/adjacent to the
// thing you're interacting with.
// -----------------------------------------------------------------------------

const canvas = document.getElementById("gameCanvas");
const canvasContext = canvas.getContext("2d");
let lastFrameTimestamp = null;
let hudFeedbackAccumulator=0;
let activeRenderer = new URLSearchParams(location.search).get("renderer") === "debug" ? DebugRenderer : WorldRenderer;
let marketGateArmed = true;
function resizeTraplineCanvas(){CanvasRuntime.resize(canvas,camera)}
window.addEventListener('resize',resizeTraplineCanvas);
window.visualViewport?.addEventListener('resize',resizeTraplineCanvas);
window.addEventListener('orientationchange',()=>setTimeout(resizeTraplineCanvas,60));
resizeTraplineCanvas();
RoomShell.init({roomId:'trapline',playerId:saveState?.currentPlayerId||'testPlayerOne',drawerId:'uiColumn',beforePortal:()=>{clueBridge.commitIfEligible(saveState.currentPlayerId,uniqueBlackRabbit,player.inventory);syncPortalPlayer();PortalRuntime.captureRoom(saveState.currentPlayerId,'trapline','Survival v2.6',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player));saveState.saveNow(player)}});
function gateDistance(g){return Math.max(Math.abs(player.gridColumn-g.column),Math.abs(player.gridRow-g.row))}
function checkMarketRoadGate(){const g=TRAPLINE_VISUAL_LAYOUT.anchors.marketRoadGate,d=gateDistance(g);if(d>g.radius+1){marketGateArmed=true;return}if(d<=g.radius&&marketGateArmed){marketGateArmed=false;player.targetColumn=null;player.targetRow=null;EventConsole.emit('ROOM','Market Road reached','Crossing into Market Stall.',{},'state');portalTransfer.enterMarket()}}

function resolveWildTapTarget(cell){
  const targets=[];
  groundDrops.list?.forEach(d=>targets.push({kind:'drop',id:d.id,column:d.column,row:d.row,range:1,hitRadius:1,label:'PICK UP',aria:`Pick up ${d.item}`,execute:()=>{groundDrops.takeAll(d.id);renderAll();return true}}));
  if(survivalSystem.dropCache)targets.push({kind:'cache',column:survivalSystem.dropCache.column,row:survivalSystem.dropCache.row,range:1,hitRadius:1,label:'RECOVER',aria:'Recover cache',execute:()=>{survivalSystem.recover();renderAll();return true}});
  const node=resourceNodes.getNodeAt(cell.column,cell.row);if(node)targets.push({kind:'gather',column:cell.column,row:cell.row,range:0,hitRadius:0,label:'GATHER',aria:`Gather ${node.label}`,execute:()=>{ActorPresentation.signal(player,'gather',.55);resourceNodes.attemptGather(cell.column,cell.row);renderAll();return true}});
  if(ecologyField.tiles.length&&['creek','wet-ground'].includes(ecologyField.get(cell.column,cell.row).habitat))targets.push({kind:'drink',column:cell.column,row:cell.row,range:0,hitRadius:0,label:'DRINK',aria:'Drink natural water',execute:()=>{survivalSystem.drinkNatural();renderAll();return true}});
  player.placedTraps.forEach(t=>targets.push({kind:'trap',id:t.id,column:t.column,row:t.row,range:1,hitRadius:1,label:'CHECK',aria:'Check trap',execute:()=>{ActorPresentation.signal(player,'trap',.5);trapping.checkTrap(t.id);renderAll();return true}}));
  animal.list.filter(a=>a.band===simulationBands.ACTIVE).forEach(a=>targets.push({kind:'animal',id:a.id,column:a.gridColumn,row:a.gridRow,getPosition:()=>({column:a.gridColumn,row:a.gridRow}),range:1,hitRadius:1,label:'HUNT',aria:`Hunt ${speciesContent[a.speciesKey]?.label||'animal'}`,execute:()=>{onTakeAnimal(a.id,'dead');renderAll();return true}}));
  return InteractionRuntime.nearestCellTarget(cell,targets,0);
}
function setMoveTargetFromEvent(clientX, clientY) {
  MobileFeedback.pulse(clientX,clientY);
  const point = CanvasRuntime.point(canvas, clientX, clientY);
  const targetCell = camera.screenToWorldCell(point.x, point.y);
  const clamped = grid.clampToGrid(targetCell.column, targetCell.row);
  const interactable=resolveWildTapTarget(clamped);
  if(interactable){interactable.walkable=(c,r)=>{const q=grid.clampToGrid(c,r);return q.column===c&&q.row===r};InteractionRuntime.select(player,interactable);renderPlayHud();return}
  InteractionRuntime.clear(player);
  player.targetColumn = clamped.column;
  player.targetRow = clamped.row;
}

canvas.addEventListener("mousedown", (event) => setMoveTargetFromEvent(event.clientX, event.clientY));
canvas.addEventListener("touchstart", (event) => {
  event.preventDefault();
  const touch = event.touches[0];
  setMoveTargetFromEvent(touch.clientX, touch.clientY);
}, { passive: false });

function handlePlayerMovement(deltaSeconds) {
  InteractionRuntime.retarget(player);
  if (player.targetColumn === null || player.targetRow === null) return;
  if (player.targetColumn === player.gridColumn && player.targetRow === player.gridRow) {
    player.targetColumn = null;
    player.targetRow = null;
    return;
  }
  player.movementAccumulator = (player.movementAccumulator || 0) + deltaSeconds;
  const secondsPerStep = 1 / player.moveSpeedCellsPerSecond;
  if (player.movementAccumulator >= secondsPerStep) {
    player.movementAccumulator = 0;
    const columnDelta = Math.sign(player.targetColumn - player.gridColumn);
    const rowDelta = Math.sign(player.targetRow - player.gridRow);
    const fromColumn=player.gridColumn, fromRow=player.gridRow;
    const clamped = grid.clampToGrid(player.gridColumn + columnDelta, player.gridRow + rowDelta);
    player.gridColumn = clamped.column;
    player.gridRow = clamped.row;
    ActorPresentation.move(player,fromColumn,fromRow,player.gridColumn,player.gridRow,secondsPerStep);
    ecologyField.depositScent(player.gridColumn, player.gridRow, "human", 1.2);
    ecologyField.addDanger(player.gridColumn, player.gridRow, 0.15);
    checkMarketRoadGate();
  }
}

// ---- Tabs ----
function switchTab(tabName) {
  document.getElementById("huntTab").style.display = tabName === "hunt" ? "block" : "none";
  document.getElementById("fieldGearTab").style.display = tabName === "fieldGear" ? "block" : "none";
  document.getElementById("tradeTab").style.display = tabName === "trade" ? "block" : "none";
  document.getElementById("devLogTab").style.display = tabName === "devlog" ? "block" : "none";
  document.getElementById("accountTab").style.display = tabName === "account" ? "block" : "none";
  if (tabName === "account") playerCard.renderInto("playerCardPanel", saveState.currentPlayerId);
  if (tabName === "trade") renderTraderPanel();
}

// ---- Rendering ----
function renderClockPanel() {
  document.getElementById("clockPanel").innerHTML =
    `<p><strong>${clock.getFormattedTime()}</strong> ${animal.isNightTime() ? "(night)" : "(day)"}</p>`;
}

function renderStatusPanel() {
  const inventoryList = Object.entries(player.inventory).filter(([, c]) => c > 0)
    .map(([name, count]) => `${name === "liveCottontail" ? "Cottontail (live)" : name} x${count}`).join(", ") || "empty";
  document.getElementById("statusPanel").innerHTML = `
    <h3>Trapper</h3>
    <p><strong>HP ${survivalSystem.health.toFixed(0)}</strong> · Food ${survivalSystem.food.toFixed(0)} · Water ${survivalSystem.water.toFixed(0)}</p>
    <p><small>Carry ${survivalSystem.used()}/${survivalSystem.capacity()} slots · ${clock.phase()}${clock.phase()==='night' ? (survivalSystem.nearFire()?' · fire safe':' · YOU ARE PREY') : ''}</small></p>
    <p>Position: (${player.gridColumn}, ${player.gridRow})</p>
    <p><small>Ground: ${ecologyField.tiles.length ? ecologyField.get(player.gridColumn, player.gridRow).habitat.replaceAll("-"," ") : "unknown"}</small></p>
    <p><small>World: 192×192 · Active / Aware / Passive / background ecology</small></p>
    <p><small>Local populations: rabbit ${(populationPools.getPopulationFraction("rabbit",player.gridColumn,player.gridRow)*100).toFixed(0)}% · deer ${(populationPools.getPopulationFraction("deer",player.gridColumn,player.gridRow)*100).toFixed(0)}% · wolf ${(populationPools.getPopulationFraction("wolf",player.gridColumn,player.gridRow)*100).toFixed(0)}%</small></p>
    <p>Traps active: ${player.placedTraps.length}</p>
    <p>Inventory: ${inventoryList}</p>
    ${(player.inventory.liveCottontail || 0) > 0 ? '<div class="liveSpecimen"><strong>Live Cottontail</strong><br><small>Keep alive, or process for meat and pelt.</small><button onclick="onProcessCottontail()">Process</button></div>' : ''}
    <p><small>Carried resources stay in your Portal-owned pack when you cross into Market.</small></p>
  `;
}

function renderNearbyPanel() {
  const panel = document.getElementById("nearbyPanel");
  let rows = "";
  const nodeHere = resourceNodes.getNodeAt(player.gridColumn, player.gridRow);
  if (nodeHere) {
    const depleted = nodeHere.pool.stock < 1;
    rows += `<p><strong>${nodeHere.label}</strong> <small>· ${nodeHere.rarity}</small> (${nodeHere.pool.stock.toFixed(1)}/${nodeHere.pool.capacity})
      <button ${depleted ? "disabled" : ""} onclick="onGather()">Gather</button></p>`;
  }
  if (ecologyField.tiles.length) {
    const habitat = ecologyField.get(player.gridColumn, player.gridRow).habitat;
    if (["creek","wet-ground"].includes(habitat)) rows += `<p>Natural water <button onclick="survivalSystem.drinkNatural();renderAll()">Drink</button></p>`;
  }
  if (survivalSystem.dropCache && Math.max(Math.abs(player.gridColumn-survivalSystem.dropCache.column),Math.abs(player.gridRow-survivalSystem.dropCache.row))<=1) {
    rows += `<p class="recoveryCache"><strong>Recovery cache</strong><br><small>${Object.entries(survivalSystem.dropCache.items||{}).filter(([,v])=>v>0).map(([k,v])=>`${k} ×${v}`).join(' · ')||'empty'}</small><button onclick="survivalSystem.recover();renderAll()">Recover what fits</button></p>`;
  }
  const nearbyDrops = groundDrops.nearby(1);
  nearbyDrops.forEach((drop) => {
    const age=Math.max(0,clock.totalGameMinutes-(drop.createdAtGameMinute||0));
    const remaining=Math.max(0,groundDrops.lifetimeMinutes-age);
    rows += `<p class="groundDrop"><strong>${drop.item}</strong> ×${drop.quantity} on ground<br><small>despawns in ${Math.floor(remaining/60)}h ${Math.floor(remaining%60)}m game time</small><br><button onclick="groundDrops.take('${drop.id}',1);renderAll()">Take 1</button> <button onclick="groundDrops.takeAll('${drop.id}');renderAll()">Take all</button></p>`;
  });
  const nearbyAnimals = animal.list.filter(u => u.band===simulationBands.ACTIVE && simulationBands.distance(u.gridColumn,u.gridRow)<=1.5 && (speciesContent[u.speciesKey].activity?.[clock.phase()]||0)>.05);
  nearbyAnimals.forEach(u=>{const sp=speciesContent[u.speciesKey];fieldCatalogue.mark(u.speciesKey,'seen');const gear=specimenSystem.captureGear[u.speciesKey];const ready=!gear||(player.inventory[gear]||0)>0;rows += `<p>${sp.label} nearby <small>· ${clock.phase()} · ${sp.habitatTags.join('/')}</small> <button onclick="onTakeAnimal('${u.id}','dead')">Hunt</button> <button ${ready?'':'disabled'} onclick="onTakeAnimal('${u.id}','live')">Capture alive</button>${!ready?`<br><small>Needs ${gear} from Market Stall.</small>`:''}</p>`});
  const nearbyTraps = player.placedTraps.filter((t) => Math.max(Math.abs(player.gridColumn - t.column), Math.abs(player.gridRow - t.row)) <= 1);
  nearbyTraps.forEach((trap) => {
    const tierName = trap.specialType === "longspring" ? specialTrap.name : trapTiers[trap.trapTierIndex].name;
    rows += `<p>${tierName} at (${trap.column},${trap.row}) ${trap.baited?'· <strong>baited</strong>':''}
      <button onclick="onCheckTrap('${trap.id}')">Check</button>
      <button ${(player.inventory.bait||0)<1||trap.baited?'disabled':''} onclick="onBaitTrap('${trap.id}')">Bait</button>
      <button onclick="onRemoveTrap('${trap.id}')">Remove</button></p>`;
  });
  panel.innerHTML = `<h3>Nearby</h3>${rows || "<p><small>Nothing to interact with here.</small></p>"}`;
}

function renderPlaceTrapPanel() {
  const panel = document.getElementById("placeTrapPanel");
  let rows = trapTiers.map((tier, index) => {
    const have = player.inventory[`trapKit:${index}`] || 0;
    if (have === 0) return "";
    return `<p>${tier.name} kit x${have} <button onclick="onPlaceTrap(${index})">Place here</button></p>`;
  }).join("");
  if ((player.inventory[specialTrap.inventoryKey]||0)>0) rows += `<p><strong>${specialTrap.name}</strong> x${player.inventory[specialTrap.inventoryKey]} <button onclick="onPlaceSpecialTrap()">Place here</button></p>`;
  panel.innerHTML = `<h3>Place a Trap</h3>${rows || "<p><small>No trap kits carried. Market Stall manufactures normal traps and Portal routes them here.</small></p>"}`;
}

function renderFieldGearPanel() {
  const panel = document.getElementById("fieldGearPanel");
  const invRows = Object.entries(player.inventory).filter(([,v])=>v>0).map(([k,v])=>`<div class="storageRow"><span>${k} ×${v}</span>${survivalSystem.near('tent',1)?`<button onclick="onStoreTent('${k}')">Store 1</button>`:''}</div>`).join('');
  const storeRows = Object.entries(survivalSystem.tentStorage||{}).filter(([,v])=>v>0).map(([k,v])=>`<div class="storageRow"><span>${k} ×${v}</span><button onclick="onTakeTent('${k}')">Take 1</button></div>`).join('');
  const foods=Object.keys(player.inventory).filter(k=>(player.inventory[k]||0)>0&&(k.startsWith('cooked:')||k.endsWith('Meat'))).map(k=>`<button onclick="survivalSystem.eat('${k}');renderAll()">Eat ${k}</button>`).join('');
  panel.innerHTML = `<h3>Field Gear</h3><p><small>Manufactured gear comes from Market Stall through Portal. Trapline handles use, repair-space, shelter and field survival.</small></p>
  <p><small>Market access is physical: follow the Market Road south and cross the gate.</small></p><button onclick="portalTransfer.pause()">Pause / Player Card</button><button onclick="survivalSystem.equipBestBag();renderAll()">Equip Best Bag</button>
  <h4>Camp</h4><button onclick="survivalSystem.place('tent');renderAll()">Place Tent</button><button onclick="survivalSystem.pickup('tent');renderAll()">Pack Tent</button><button onclick="survivalSystem.place('campfire');renderAll()">Place Fire</button><button onclick="survivalSystem.feedFire();renderAll()">Feed Fire (wood)</button><button onclick="survivalSystem.pickup('campfire');renderAll()">Pack Fire</button><button onclick="survivalSystem.sleep();renderAll()">Sleep → Morning</button>
  <h4>Food / Recovery</h4><small>Prepared food is made by the Market crafter. Raw meat can still be eaten in an emergency.</small>${foods||''}${(player.inventory.fieldTonic||0)>0?`<button onclick="survivalSystem.useTonic();renderAll()">Use Field Tonic (${player.inventory.fieldTonic})</button>`:''}
  <h4>Tent Storage ${survivalSystem.storageUsed()}/${survivalSystem.tentStorageSlots}</h4>${survivalSystem.near('tent',1)?(storeRows||'<small>Storage empty.</small>'):'<small>Stand next to your tent to access storage.</small>'}
  ${survivalSystem.near('tent',1)?`<details><summary>Store carried item</summary>${invRows||'<small>Pack empty.</small>'}</details>`:''}`;
}

let ledgerPurposeFilter = null;
function renderDevLogPanel() {
  const panel = document.getElementById("devLogPanel");
  const filterFn = ledgerPurposeFilter ? (e) => e.purpose === ledgerPurposeFilter : null;
  const entries = (filterFn ? EventConsole._history.filter(filterFn) : EventConsole._history).slice(-80).reverse();
  const purposeButtons = ["decision", "milestone", "state"].map((purpose) =>
    `<button onclick="onSetLedgerFilter(${ledgerPurposeFilter === purpose ? "null" : `'${purpose}'`})"
      style="opacity:${ledgerPurposeFilter === purpose || !ledgerPurposeFilter ? "1" : "0.5"}">${purpose}</button>`
  ).join("");
  const rows = entries.map((entry) => {
    let line = `<p><strong>[${entry.system}]</strong> ${entry.event}`;
    if (entry.reason) line += `<br><small>${entry.reason}</small>`;
    return line + "</p>";
  }).join("");
  panel.innerHTML = `<h3>Ledger</h3><p><small>Filter:</small> ${purposeButtons}</p><button onclick="onRunQA()">Run Foundation QA</button><div id="qaInline"></div>${rows || "<p>Nothing logged yet.</p>"}`;
}
function onSetLedgerFilter(purpose) { ledgerPurposeFilter = purpose; renderDevLogPanel(); }
function onRunQA(){ const el=document.getElementById("qaInline"); if(el) el.innerHTML=TraplineQA.html(); }

function renderTraderPanel() {
  const panel = document.getElementById("traderPanel");
  if (!panel) return;
  const present = traders.present();
  const sheet = backendApi._readTimesheet(saveState.currentPlayerId);
  let html = `<h3>Trail Traders</h3><p>Floppies: <strong>${sheet.floppyBalance || 0}</strong></p>`;
  if (!present.length) html += `<p><small>No traders are on the line right now. They come and go with the day.</small></p>`;
  present.forEach((t) => {
    const state = traders.state[t.id], route = traders.routePoint(t), canTrade = traders.canTrade(t);
    const statusText = route.status === "camp" ? (canTrade ? "at camp · in trading range" : "at Trail Camp") : `${route.status} on the trail`;
    const relation = state.relationship || {};
    const sellRows = Object.entries(t.sellPrice).map(([item, base]) => {const price=traders.adjustedPrice(t,base,"sell");return `<div>${item} x${state.stock[item] || 0} — ${price} floppies</div><button ${(!canTrade||(state.stock[item]||0)<1)?'disabled':''} onclick="onBuyTrader('${t.id}','${item}')">Buy</button>`;}).join('');
    const buyRows = Object.entries(t.buyPrice).filter(([item]) => (player.inventory[item] || 0) > 0).map(([item,base])=>{const price=traders.adjustedPrice(t,base,"buy");return `<div>${item} x${player.inventory[item]||0} — ${price} floppies</div><button ${!canTrade?'disabled':''} onclick="onSellTrader('${t.id}','${item}')">Sell</button>`;}).join('');
    const special=t.specialTrade; const specialDone=state.specialTraded;
    html += `<div class="traderCard ${t.temperament}"><h4>${t.name}</h4><p><small>${statusText}${t.temperament==='mercurial'?` · mood: ${traders.mood(t)}`:''}</small></p><p class="traderLine">“${traders.line(t)}”</p>
      <p><small>Trust ${Number(relation.TRUST||0).toFixed(1)} · Respect ${Number(relation.RESPECT||0).toFixed(1)} · Memory ${state.memories.length}</small></p>
      <button ${!canTrade?'disabled':''} onclick="onTalkTrader('${t.id}')">Talk</button>
      <div class="tradeGrid">${sellRows||'<small>Nothing for sale.</small>'}</div>
      <h5>Buying</h5><div class="tradeGrid">${buyRows||'<small>Nothing in your pack they want right now.</small>'}</div>
      <div class="specialBarter ${specialDone?'done':''}"><strong>Private barter: ${special.label}</strong><br><small>${special.description}</small><br><small>${specialDone?'Trade already made.':'Wanted: one live Cottontail. No floppies.'}</small><button ${(!canTrade||specialDone||(player.inventory.liveCottontail||0)<1)?'disabled':''} onclick="onSpecialTraderTrade('${t.id}')">${specialDone?'Gone':'Trade live Cottontail'}</button></div></div>`;
  });
  panel.innerHTML=html;
}

function renderPlayHud(){
  const g=TRAPLINE_VISUAL_LAYOUT.anchors.marketRoadGate,d=gateDistance(g);
  const node=resourceNodes.getNodeAt(player.gridColumn,player.gridRow);
  const habitat=ecologyField.tiles.length?ecologyField.get(player.gridColumn,player.gridRow).habitat:'';
  const nearby=animal.list.find(u=>Math.max(Math.abs(u.gridColumn-player.gridColumn),Math.abs(u.gridRow-player.gridRow))<=1);
  document.getElementById('vitalsChip').textContent=`HP ${survivalSystem.health.toFixed(0)} · FOOD ${survivalSystem.food.toFixed(0)} · WATER ${survivalSystem.water.toFixed(0)} · ${survivalSystem.used()}/${survivalSystem.capacity()}`;
  document.getElementById('packChip').textContent=MobileFeedback.inventorySummary(player.inventory,3);
  const prompt=MobileFeedback.wildPrompt({gateDistance:d,gateRadius:g.radius,nodeLabel:node?.label,water:['creek','wet-ground'].includes(habitat),nearbyAnimal:nearby?speciesContent[nearby.speciesKey]?.label:null});
  MobileFeedback.setPrompt(prompt,d<=g.radius+3?'route':(clock.phase()==='night'&&!survivalSystem.nearFire()?'danger':'normal'));
  const action=document.getElementById('contextAction');
  if(action){const available=contextActionState();action.disabled=!available;action.textContent=available?.label||'ACT';action.setAttribute('aria-label',available?.aria||'No nearby interaction');}
}

function renderAll() {
  renderPlayHud();
  renderClockPanel();
  renderStatusPanel();
  trackingSigns.renderPanel();
  renderNearbyPanel();
  renderPlaceTrapPanel();
  renderFieldGearPanel();
  renderTraderPanel();
}

// Direct play-surface interaction. This is deliberately conservative: ACT never hunts,
// spends currency, or destroys a trap. Those consequential choices stay in TOOLS.
function contextActionState(){
  const selected=InteractionRuntime.action(player);if(selected)return selected;
  const drop=groundDrops.nearby(1)[0];if(drop)return{kind:'drop',id:drop.id,label:'PICK UP',aria:`Pick up ${drop.item}`};
  if(survivalSystem.dropCache&&Math.max(Math.abs(player.gridColumn-survivalSystem.dropCache.column),Math.abs(player.gridRow-survivalSystem.dropCache.row))<=1)return{kind:'cache',label:'RECOVER',aria:'Recover nearby cache'};
  const node=resourceNodes.getNodeAt(player.gridColumn,player.gridRow);if(node&&node.pool.stock>=1)return{kind:'gather',label:'GATHER',aria:`Gather ${node.label}`};
  if(ecologyField.tiles.length&&['creek','wet-ground'].includes(ecologyField.get(player.gridColumn,player.gridRow).habitat))return{kind:'drink',label:'DRINK',aria:'Drink natural water'};
  const trap=player.placedTraps.find(t=>Math.max(Math.abs(player.gridColumn-t.column),Math.abs(player.gridRow-t.row))<=1);if(trap)return{kind:'trap',id:trap.id,label:'CHECK',aria:'Check nearby trap'};
  return null;
}
function performContextAction(){
  if(InteractionRuntime.execute(player)){renderAll();return true}
  const a=contextActionState();if(!a)return false;
  if(a.kind==='drop')groundDrops.takeAll(a.id);
  else if(a.kind==='cache')survivalSystem.recover();
  else if(a.kind==='gather'){ActorPresentation.signal(player,'gather',.55);resourceNodes.attemptGather(player.gridColumn,player.gridRow);}
  else if(a.kind==='drink')survivalSystem.drinkNatural();
  else if(a.kind==='trap'){ActorPresentation.signal(player,'trap',.5);trapping.checkTrap(a.id);}
  renderAll();return true;
}
document.getElementById('contextAction')?.addEventListener('click',performContextAction);

// ---- Handlers ----
function onTakeAnimal(id,state){
  ActorPresentation.signal(player,state==='live'?'trap':'hunt',.65);
  const u=animal.list.find(x=>x.id===id);if(!u)return;const sp=speciesContent[u.speciesKey];let ok=false;
  if(state==='live') ok=specimenSystem.capture(u);
  else {
    const weapon=['gun3','gun2','gun1','bow3','bow2','bow1','spear3','spear2','spear1'].find(k=>(player.inventory[k]||0)>0);
    if(!weapon){EventConsole.emit('HUNT','No weapon','Market Stall manufactures field weapons.',{},'state');return}
    if(weapon.startsWith('gun')){if((player.inventory.shot||0)<1||(player.inventory.powder||0)<1){EventConsole.emit('HUNT','Gun unloaded','Single-shot black powder requires one shot and one powder charge.',{},'state');return}player.inventory.shot--;player.inventory.powder--}
    if(weapon.startsWith('bow')){if((player.inventory.arrows||0)<1){EventConsole.emit('HUNT','No arrows','Return to Market Stall for ammunition.',{},'state');return}player.inventory.arrows--}
    const tier=Math.max(1,Number(weapon.match(/(\d)$/)?.[1]||1));
    const family=weapon.startsWith('gun')?'gun':weapon.startsWith('bow')?'bow':'spear';
    const base=GCBalance.hunting.weaponBaseChance[family];
    const tierBonus=(tier-1)*GCBalance.hunting.tierBonus, difficulty=Math.min(.24,Math.max(0,(6-(sp.fleeThreshold||4))*GCBalance.hunting.fleeDifficultyStep)+(sp.hostileToPlayer?GCBalance.hunting.hostileDifficulty:0));
    const chance=Math.max(GCBalance.hunting.minimumChance,Math.min(GCBalance.hunting.maximumChance,base+tierBonus-difficulty));
    if(Math.random()>chance){EventConsole.emit('HUNT',`${sp.label} escaped`,`${weapon.toUpperCase()} chance ${(chance*100).toFixed(0)}%.`,{species:u.speciesKey,weapon},'state');u.currentBehavior='flee';u.secondsUntilNextDecision=0;renderAll();return}
    const outputs=[]; if(sp.pelt)outputs.push(sp.pelt); if(sp.meat)outputs.push(sp.meat);
    outputs.forEach(item=>groundDrops.giveOrDrop(item,1,u.gridColumn,u.gridRow,'hunt-overflow'));
    ok=true;fieldCatalogue.mark(u.speciesKey,'dead');EventConsole.emit('HUNT',`${sp.label} taken`,`${weapon.toUpperCase()} · ${(chance*100).toFixed(0)}% field chance`,{species:u.speciesKey,weapon},'milestone')
  }
  if(!ok)return;populationPools.removeFromRegion(u.speciesKey,u.gridColumn,u.gridRow,1);animal.list=animal.list.filter(x=>x.id!==id);renderAll()
}

function onGather() {
  ActorPresentation.signal(player,'gather',.55);
  resourceNodes.attemptGather(player.gridColumn, player.gridRow);
  renderAll();
}
function onCheckTrap(trapId) { ActorPresentation.signal(player,'trap',.5); trapping.checkTrap(trapId); renderAll(); }
function onBaitTrap(trapId){ ActorPresentation.signal(player,'trap',.45); trapping.bait(trapId); renderAll(); }
function onRemoveTrap(trapId) {
  trapping.removeTrap(trapId);
  renderAll();
}
function onPlaceTrap(tierIndex) {
  ActorPresentation.signal(player,'trap',.55);
  trapping.placeTrap(tierIndex);
  renderAll();
}
function onPlaceSpecialTrap(){ ActorPresentation.signal(player,'trap',.55); trapping.placeSpecialTrap(); renderAll(); }
function onBuyTrader(traderId,item){ ActorPresentation.signal(player,'trade',.45); traders.buyFromTrader(traderId,item); renderAll(); }
function onSellTrader(traderId,item){ ActorPresentation.signal(player,'trade',.45); traders.sellToTrader(traderId,item); renderAll(); }
function onSpecialTraderTrade(traderId){ ActorPresentation.signal(player,'trade',.65); traders.specialTrade(traderId); renderAll(); saveState.saveNow(player); }
function onProcessCottontail(){ ActorPresentation.signal(player,'hunt',.6); uniqueBlackRabbit.processForMeatAndPelt(); renderAll(); }
function onClaimPortal(){ PortalRuntime.applyToRoom(saveState.currentPlayerId,player); renderAll(); }
function onStoreTent(item){survivalSystem.store(item,1);renderAll()}
function onTakeTent(item){survivalSystem.take(item,1);renderAll()}
// ---- Game loop ----
function gameLoopTick(timestamp) {
  if (lastFrameTimestamp === null) lastFrameTimestamp = timestamp;
  const deltaSeconds = (timestamp - lastFrameTimestamp) / 1000;
  lastFrameTimestamp = timestamp;

  handlePlayerMovement(deltaSeconds);
  animal.update(deltaSeconds);
  populationPools.update(deltaSeconds);
  ecologyField.tick(deltaSeconds);
  camera.update();
  resourceNodes.update(deltaSeconds);
  clock.update(deltaSeconds);
  hudFeedbackAccumulator+=deltaSeconds;if(hudFeedbackAccumulator>=.25){hudFeedbackAccumulator=0;renderPlayHud()}
  survivalSystem.tick(deltaSeconds);
  groundDrops.tick();

  uniqueBlackRabbit.update(deltaSeconds);
  activeRenderer.draw(canvasContext);

  requestAnimationFrame(gameLoopTick);
}

// ---- Startup ----
async function startGame() {
  const existingSave = await saveState.loadExistingSave();
  if (existingSave) {
    const oldWorldSave = Number(existingSave.worldSize || 96) < 192;
    player.gridColumn = oldWorldSave ? Math.min(191, Math.max(0, existingSave.gridColumn + 49)) : existingSave.gridColumn;
    player.gridRow = oldWorldSave ? Math.min(191, Math.max(0, existingSave.gridRow + 48)) : existingSave.gridRow;
    player.inventory = existingSave.inventory || {};
    PortalRuntime.bootstrap(saveState.currentPlayerId,{inventory:player.inventory,floppyBalance:backendApi._readTimesheet(saveState.currentPlayerId).floppyBalance||0});
    PortalRuntime.applyToRoom(saveState.currentPlayerId,player);
    const portalState=PortalRuntime.read(saveState.currentPlayerId);
    if(portalState.session.previousRoom==='market-stall'&&portalState.session.currentRoom==='trapline'){const a=TRAPLINE_VISUAL_LAYOUT.anchors.marketRoadGate;player.gridColumn=a.arrivalColumn;player.gridRow=a.arrivalRow;player.targetColumn=null;player.targetRow=null;marketGateArmed=false;}
    player.placedTraps = existingSave.placedTraps || [];
    if (existingSave.uniqueBlackRabbit) uniqueBlackRabbit.hydrate(existingSave.uniqueBlackRabbit);
    // Migration repair: an old save must never carry a live specimen after it was processed or traded.
    if (uniqueBlackRabbit.processed || uniqueBlackRabbit.tradedAway) player.inventory.liveCottontail = 0;
    Object.keys(player.inventory).forEach((key) => { if (!Number.isFinite(player.inventory[key]) || player.inventory[key] < 0) player.inventory[key] = 0; });
    if (Number.isFinite(existingSave.totalGameMinutes)) clock.totalGameMinutes = existingSave.totalGameMinutes;
    if(existingSave.survival) survivalSystem.hydrate(existingSave.survival);
    groundDrops.hydrate(existingSave.groundDrops);
    EventConsole.emit("SESSION", "Save loaded", "resuming previous session", { playerId: saveState.currentPlayerId }, "state");
  }

  if (!existingSave) {
    groundDrops.hydrate(null);
    PortalRuntime.bootstrap(saveState.currentPlayerId,{inventory:player.inventory,floppyBalance:backendApi._readTimesheet(saveState.currentPlayerId).floppyBalance||0});
    PortalRuntime.applyToRoom(saveState.currentPlayerId,player);
    const portalState=PortalRuntime.read(saveState.currentPlayerId);if(portalState.session.previousRoom==='market-stall'&&portalState.session.currentRoom==='trapline'){const a=TRAPLINE_VISUAL_LAYOUT.anchors.marketRoadGate;player.gridColumn=a.arrivalColumn;player.gridRow=a.arrivalRow;marketGateArmed=false;}
  }
  ecologyField.setup();
  populationPools.setup(existingSave && existingSave.populationState);
  resourceNodes.setup();
  traders.setup(existingSave && existingSave.traders);
  animal.spawnAnimals();
  if (!existingSave) uniqueBlackRabbit.resetForNewSave();
  resizeTraplineCanvas();
  camera.snapToPlayer();

  renderAll();

  setInterval(() => {
    const activeTag = document.activeElement && document.activeElement.tagName;
    if (activeTag !== "INPUT" && activeTag !== "SELECT") {
      renderAll();
    }
    renderDevLogPanel();
    syncPortalPlayer();
    PortalRuntime.captureRoom(saveState.currentPlayerId,'trapline','Survival v2.6',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player));
    saveState.saveNow(player);
  }, 3000);

  requestAnimationFrame(gameLoopTick);
}

startGame();


function setRenderer(name) {
  activeRenderer = name === "debug" ? DebugRenderer : WorldRenderer;
  document.body.dataset.renderer = activeRenderer.id;
}

window.addEventListener("pagehide", () => {
  try {
    clueBridge.commitIfEligible(saveState.currentPlayerId, uniqueBlackRabbit, player.inventory);
    syncPortalPlayer();
    PortalRuntime.captureRoom(saveState.currentPlayerId,'trapline','Survival v2.6',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player));
    saveState.saveNow(player);
  } catch (error) { console.warn("Trapline exit save failed", error); }
});
