(function(global){
  const states=new WeakMap();
  const now=()=>global.performance?.now?global.performance.now():Date.now();
  function ensure(actor){
    if(!actor||typeof actor!=='object')return null;
    if(!states.has(actor))states.set(actor,{facing:'south',visualFlipX:false,move:null,action:null,actionUntil:0,actionStarted:0,seed:(Math.random()*1000)|0});
    return states.get(actor);
  }
  function facingFor(dx,dy,current='south'){
    if(!dx&&!dy)return current;
    if(dx>0&&dy<0)return'northeast';
    if(dx<0&&dy<0)return'northwest';
    if(dx>0&&dy>0)return'southeast';
    if(dx<0&&dy>0)return'southwest';
    if(Math.abs(dx)>=Math.abs(dy))return dx>0?'east':'west';
    return dy>0?'south':'north';
  }
  function move(actor,fromColumn,fromRow,toColumn,toRow,durationSeconds=.18){
    const s=ensure(actor);if(!s)return;
    const t=now();
    const dc=toColumn-fromColumn,dr=toRow-fromRow;
    s.facing=facingFor(dc,dr,s.facing);
    // Art is side-profile. In the isometric projection screen X follows column-row,
    // so visual facing must follow projected travel rather than world-cardinal facing.
    const projectedDx=dc-dr;if(projectedDx!==0)s.visualFlipX=projectedDx<0;
    s.move={fromColumn,fromRow,toColumn,toRow,started:t,duration:Math.max(60,Number(durationSeconds||.18)*1000)};
  }
  function signal(actor,action,durationSeconds=.45){
    const s=ensure(actor);if(!s)return;
    const t=now();s.action=action;s.actionStarted=t;s.actionUntil=t+Math.max(80,Number(durationSeconds||.45)*1000);
  }
  function pose(actor){
    const s=ensure(actor);const tnow=now();if(!s)return{facing:'south',moving:false,t:1,bob:0,action:null,actionStrength:0};
    let t=1,moving=false,fromColumn=actor.gridColumn,fromRow=actor.gridRow,toColumn=actor.gridColumn,toRow=actor.gridRow;
    if(s.move){
      t=Math.max(0,Math.min(1,(tnow-s.move.started)/s.move.duration));moving=t<1;
      ({fromColumn,fromRow,toColumn,toRow}=s.move);
      if(!moving)s.move=null;
    }
    if(s.action&&tnow>=s.actionUntil){s.action=null;s.actionUntil=0;s.actionStarted=0;}
    const actionStrength=s.action?Math.max(0,Math.min(1,(s.actionUntil-tnow)/Math.max(1,s.actionUntil-s.actionStarted))):0;
    const phase=(tnow/120)+(s.seed*.13);
    const bob=moving?Math.sin(phase)*2.25:Math.sin(phase*.22)*.65;
    return{facing:s.facing,moving,t,bob,action:s.action,actionStrength,fromColumn,fromRow,toColumn,toRow,flipX:!!s.visualFlipX,squash:s.action==='hurt'?.90:s.action==='craft'||s.action==='gather'?1.04:1};
  }
  function projectedPoint(actor,grid){
    const p=pose(actor);if(!p.moving)return{...grid.cellCenter(actor.gridColumn,actor.gridRow),pose:p};
    const a=grid.cellCenter(p.fromColumn,p.fromRow),b=grid.cellCenter(p.toColumn,p.toRow);
    const ease=p.t*p.t*(3-2*p.t);
    return{x:a.x+(b.x-a.x)*ease,y:a.y+(b.y-a.y)*ease,pose:p};
  }
  global.ActorPresentation={ensure,move,signal,pose,projectedPoint,facingFor};
})(window);
