(function(global){
  const selected=new WeakMap();
  const pos=t=>typeof t?.getPosition==='function'?t.getPosition():t;
  const distance=(a,b)=>{const q=pos(b);return Math.max(Math.abs(Number(a.gridColumn)-Number(q.column)),Math.abs(Number(a.gridRow)-Number(q.row)))};
  function inRange(player,target){return !!player&&!!target&&distance(player,target)<=Number(target.range??1)}
  function approachCell(player,target){
    const q=pos(target);
    const range=Math.max(0,Number(target.range??1));
    if(inRange(player,target))return{column:player.gridColumn,row:player.gridRow};
    let best=null;
    for(let dc=-range;dc<=range;dc++)for(let dr=-range;dr<=range;dr++){
      if(Math.max(Math.abs(dc),Math.abs(dr))>range)continue;
      const c=Number(q.column)+dc,r=Number(q.row)+dr;
      if(target.walkable&& !target.walkable(c,r))continue;
      const score=Math.max(Math.abs(c-player.gridColumn),Math.abs(r-player.gridRow));
      if(!best||score<best.score)best={column:c,row:r,score};
    }
    return best?{column:best.column,row:best.row}:{column:q.column,row:q.row};
  }
  function select(player,target){if(!player||!target)return null;selected.set(player,target);const p=approachCell(player,target);player.targetColumn=p.column;player.targetRow=p.row;return target}
  function retarget(player){const t=target(player);if(!t||inRange(player,t))return false;const p=approachCell(player,t);player.targetColumn=p.column;player.targetRow=p.row;return true}
  function clear(player){if(player)selected.delete(player)}
  function target(player){return player?selected.get(player)||null:null}
  function action(player){const t=target(player);return t&&inRange(player,t)?t:null}
  function execute(player){const t=action(player);if(!t||typeof t.execute!=='function')return false;const ok=t.execute();if(ok!==false)clear(player);return ok!==false}
  function nearestCellTarget(cell,targets,tolerance=1){let best=null;for(const t of targets||[]){if(!t)continue;const d=Math.max(Math.abs(cell.column-t.column),Math.abs(cell.row-t.row));if(d<=Number(t.hitRadius??tolerance)&&(!best||d<best.d))best={t,d}}return best?.t||null}
  global.InteractionRuntime={pos,distance,inRange,approachCell,select,retarget,clear,target,action,execute,nearestCellTarget};
})(window);
