# Portal V3 — Interaction + Facing Pass

Baseline: Portal Checkpoint 1 post-checkpoint Android playtest handoff.

## Implemented in this V3 source pass
- Shared `InteractionRuntime` owns selection, range checks, approach-cell routing, persistent target state, retargeting of moving actors, and execution.
- Wild taps resolve interactables before ordinary movement: ground drops, recovery cache, resource nodes, natural water, traps, and active wildlife.
- Market taps resolve Ada, recurring NPCs, and mapped stall frontages before ordinary movement.
- Both rooms use the same mouse/touch resolver path and contextual ACT surface.
- Selected interactables get a distinct world-space target diamond while the normal movement destination remains separate.
- Moving selected NPC/animal targets can be retargeted as they move.
- Shared actor presentation retains logical facing while sprite flip follows projected isometric screen travel (`dc - dr`), preventing world-cardinal direction from driving side-profile art.
- Mobile Tools remains an overlay/drawer and does not permanently divide the world viewport.
- GCPS2 raw payload remains behind a details/recovery surface; Copy/Load controls remain primary.

## Deliberately not claimed
This is source/runtime verification, not real-device acceptance. Android touch behavior must still be exercised on the user's device before calling the blocker closed.

## V3 device acceptance sequence
1. Wild: tap ordinary ground -> movement still works.
2. Tap recovered scrap -> target highlight -> approach -> PICK UP -> inventory/state changes.
3. Tap resource -> approach -> GATHER.
4. Tap water -> approach/use -> DRINK.
5. Tap trap -> approach -> CHECK.
6. Tap wildlife -> approach -> HUNT remains explicit via ACT.
7. Market: tap Ada -> approach -> TALK -> Crafter surface.
8. Tap recurring NPC -> approach -> TALK.
9. Tap mapped stall frontage -> approach -> TRADE/browse surface.
10. Observe rabbits, larger wildlife, Market NPCs and recurring traders moving across all isometric directions; sprites must face screen travel and retain facing while idle.
11. Confirm Portal -> Wild -> Market -> Portal continuity.
12. Confirm special Cottontail remains visually ordinary.

## Integrated V3 continuation pass
- Previous-room tracking hardened: ordinary room sync/snapshots preserve transition history, and same-room transition calls no longer rewrite `previousRoom`.
- Mobile Tools is a modal overlay drawer with a tap-to-dismiss scrim; closing restores the full spatial world.
- Memory Card now leads with a short readable Card ID + Check code. Raw GCPS2 is labeled Recovery Code and remains behind a details surface.
- Portal room descriptions were rewritten as player-facing actions; the dead-end MORE/coming-later entry is removed.
- Wild build/engine language was removed from the normal player surface.
- Wild wet terrain no longer paints a repeated blue curl per creek tile; wet cells use a restrained connected tint and reduced tile seams.
- Market floor tile seams were reduced so mapped districts, stalls, roads, and infrastructure carry more of the visual read than the 64x64 board.
- These visual changes remain presentation-only: layout maps and gameplay coordinates are unchanged.

## Integrated-device acceptance
Use the earlier 12-step interaction/facing sequence, then additionally verify:
13. Portal Player Information reports the actual prior room after Portal -> Wild -> Market -> Portal transitions.
14. Open Tools in both rooms, tap outside it to dismiss, and confirm the world returns to full width.
15. Open Memory Card: Card ID + Check are immediately readable; raw recovery code is hidden until expanded; Copy/Import/Print still work.
16. Portal normal room chooser contains no dead MORE placeholder or implementation-oriented room descriptions.
17. Wild water reads as terrain rather than repeated blue marks; Market reads less like a naked logical tile board.
