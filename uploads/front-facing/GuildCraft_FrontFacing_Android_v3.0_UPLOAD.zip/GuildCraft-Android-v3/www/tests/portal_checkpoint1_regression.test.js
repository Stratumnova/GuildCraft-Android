const fs=require('fs'),vm=require('vm'),assert=require('assert');
const actorSrc=fs.readFileSync('shared/actorPresentation.js','utf8');
let now=1000; const ctx={window:{performance:{now:()=>now}},performance:{now:()=>now}};ctx.window.window=ctx.window;vm.createContext(ctx);vm.runInContext(actorSrc,ctx);const A=ctx.window.ActorPresentation;
function visualFlip(fromC,fromR,toC,toR){const u={gridColumn:fromC,gridRow:fromR};A.move(u,fromC,fromR,toC,toR,.2);return A.pose(u).flipX;}
assert.equal(visualFlip(5,5,6,5),false,'east-grid step projects right and should face sprite right');
assert.equal(visualFlip(5,5,5,6),true,'south-grid step projects left in isometric view and should face sprite left');
assert.equal(visualFlip(5,5,5,4),false,'north-grid step projects right in isometric view and should face sprite right');
assert.equal(visualFlip(5,5,4,5),true,'west-grid step projects left and should face sprite left');
const html=fs.readFileSync('trapline/index.html','utf8');const main=fs.readFileSync('trapline/main.js','utf8');
assert(html.includes('id="contextAction"'),'Wild must expose a direct ACT control without opening hidden tools');
assert(main.includes('function performContextAction()'),'Wild must bind direct contextual interaction');
assert(main.includes("groundDrops.takeAll"),'Context interaction must support pickup');
assert(main.includes('resourceNodes.attemptGather'),'Context interaction must support gathering');
console.log('portal checkpoint 1 regression PASS');
