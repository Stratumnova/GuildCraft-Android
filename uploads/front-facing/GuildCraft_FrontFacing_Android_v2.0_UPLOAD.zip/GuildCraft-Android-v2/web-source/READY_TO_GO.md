# GuildCraft Connected Rooms — Fullscreen Cibola v2.3

This package contains the three connected surfaces:

- `portal/` — Portal v2.3; player/account authority, memory card and room bridge.
- `trapline/` — Survival v2.6; full-screen Cibola/Grants Wild resource/survival room.
- `market-stall/` — Fieldworks v2.5; 64×64 Cibola settlement economy/crafting room.
- `assets/cibola/` — reusable Cibola County / Grants + restrained Nova PNG asset pack.
- `shared/` — biome registry, visual runtime and room shell/navigation.

## Current room flow

`PORTAL -> THE WILD -> MARKET ROAD -> MARKET STALL -> SOUTH ROAD -> THE WILD`

Gameplay rooms occupy the full browser/APK viewport. PORTAL and TOOLS are overlay tabs, not permanent side panels. Portal remains the account authority regardless of room.

## Locked behavior

- Player inventory/floppies follow the Portal Player Card between rooms.
- Trapline does not manufacture gear.
- Ada remains the visible Market manufacturing path.
- Player stall till remains browser/stall state until physically collected and is excluded from portable cards.
- GCPS2 compact cards omit reconstructable ecology/history noise; GCPS1 legacy cards still import.
- Local room state versus imported snapshot precedence remains intentionally hybrid for live testing.
- Hidden Black Cottontail remains visually ordinary and its market rumor remains one-shot.
- Market expansion plots remain intentionally empty/reserved until a future feature claims them.
- Biome presentation is data/theme; future rooms may use different registered biome IDs without changing shared Portal/player logic.

Historical stage reports are archived under `docs/archive/`; current release verification is at the package root.

## v2.1 player-feedback pass
Compact safe-area HUD chips, contextual route/action prompts, touch target pulse, and clearer mobile pack/survival/till feedback were added without changing room simulation or portable save semantics.
