# Runaway Cleanup Pass — Fullscreen Cibola v2.3

This pass removes release archaeology from normal play without deleting intentional compatibility.

## Removed / retired
- Player-facing debug renderer switches and stale debug instructions. Debug renderers remain code-accessible for development tests.
- Obsolete Trapline `workshop` naming. The survival/inventory surface is now consistently `Field Gear`; Trapline still does not manufacture normal gear.
- Unreferenced imported Byte My Chip source tree under Market assets. Reusable promoted Cibola assets remain in the shared asset pack.
- Stray temporary Python test file.
- Historical stage QA/release notes from the release root; retained under `docs/archive/` where they cannot be mistaken for current instructions.
- Stale Portal/Trapline/Market version labels in active runtime and current documentation.

## Intentionally retained
- GCPS1 import compatibility and old currency-field migration. These are migration paths, not active gameplay terminology.
- Debug renderer source files and event/ledger diagnostics used by automated/developer QA.
- Hidden Cottontail loss/success branches and one-shot rumor contract.
- Legacy infrastructure as an in-world/lore term where it describes old physical remains.

## Current versions
- R_D Portal v2.3
- Trapline Survival v2.6
- Market Stall Fieldworks v2.5
