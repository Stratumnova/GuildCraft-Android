# R_D Portal v2.3

Portal is the persistent Player Card/account authority and spatial bridge between GuildCraft rooms. The existing four mapped terminals remain: Game View, Player Information, Console / Log, and Games / Versions.

v1.3 keeps ordinary cargo claiming with direct room continuity. The Player Card owns carried inventory and floppies; rooms consume that shared state while owning their own local world state. Portal also provides the universal pause/memory-card surface and one portable `GCPS2` compact snapshot template (with GCPS1 legacy import) for all current and future rooms.

The legacy schema-4 transfer ledger remains present only for compatibility/audit history and is not the normal Wild ↔ Market inventory path.
