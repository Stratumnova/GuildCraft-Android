# GuildCraft Connected Rooms — Fullscreen Cibola v2.3

Authoritative connected browser build for the next APK test cycle.

- `portal/` — R_D Portal v2.3: persistent Player Card/account authority, compact GCPS2 memory-card surface, version/debug terminals, and the room host that keeps Wild ↔ Market inside one game shell.
- `trapline/` — Trapline Survival v2.6: **The Wild**, a Cibola/Grants resource-and-survival room. Hunting, trapping, gathering, specimens, camps, ground drops, Market Road transition. No normal manufacturing.
- `market-stall/` — Market Stall Fieldworks v2.5: 64×64 Cibola settlement market with Ada, player-owned stall, 24 permanent vendor stalls/keepers, lane-weighted crowd routing, roaming market actors, background need/supply/currency, Iris requests, and reserved expansion districts.
- `assets/cibola/` — reusable high-resolution PNG terrain, animal, NPC, market-dressing, prop and Nova assets.
- `shared/` — biome registry, theme-independent visual loader, lightweight actor-presentation runtime, HiDPI canvas runtime and persistent room-shell navigation.

Serve this folder from one origin and open `portal/index.html`.

## Room flow

`PORTAL → THE WILD → MARKET ROAD → MARKET STALL → ROAD TO THE WILD → THE WILD`

Portal remains loaded as the outer bridge while gameplay rooms swap inside its fullscreen room host. The same Player Card inventory/currency continues across rooms; there is no cargo-claim step for carried items.

## Current biome contract

The current connected area uses two related room profiles:

- `cibola-grants-wild` — Trapline / The Wild
- `cibola-grants-settlement` — Market Stall

Biome/theme selection is separated from player/account/gameplay logic through `shared/biomeRegistry.js`. Future rooms can register different biome asset packs without rewriting Portal continuity, save cards, inventory, or room-transition systems.

## Market layout

The 64×64 Market is arranged as a settlement rather than an open test grid: south Wild-road entrance, central pedestrian spine, cross-lanes, gathering square, prepared-goods row, makers row, player-stall district, Ada's crafter lane, loading/service edge, permanent vendor fronts, public customer stops, and eight intentionally empty expansion plots.

NPC shoppers use the mapped lanes/intersections as preferred pedestrian routes. Permanent stall keepers stay behind their counters. Reserved plots are deliberately kept free of permanent dressing so later systems can be added without rebuilding the map.

## Save card

New portable saves export as compact `GCPS2` cards. `GCPS1` remains accepted as a legacy import format. Reconstructable ecology arrays and verbose Portal history are not exported. Uncollected player-stall till remains browser/stall state and is excluded until physically collected.


## Character / animal presentation

The v1.8 presentation layer remains in place: player, wildlife and moving Market shoppers interpolate between authoritative cells, preserve facing, use subtle idle/movement motion, and display short reusable action feedback for gather/hunt/trap/trade/craft/eat/drink/hurt states. No animation state is serialized into GCPS2. See `CHARACTER_PRESENTATION_V1_8_QA.md`.

## Play balance

The v1.9 pass centralizes survival, threat, hunting, trapping, Market value, Ada fees and player-stall cadence in `shared/playBalance.js`. The goal is a first proper playthrough where survival matters without overwhelming exploration, dangerous Wild goods have meaningful economic value, advanced manufacturing costs more than entry gear, and a hired seller helps without liquidating the stall every few seconds. See `PLAY_BALANCE_V1_9_QA.md`.
