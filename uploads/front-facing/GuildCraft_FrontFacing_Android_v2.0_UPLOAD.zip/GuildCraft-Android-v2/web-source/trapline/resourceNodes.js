// resourceNodes.js — regenerating gatherable materials with regional rarity.
const resourceNodes = {
  list: [],
  setup() {
    this.list = mapContent.resourceNodeLayout.map((nodeData) => ({
      ...nodeData,
      label: nodeData.label || nodeData.resource,
      rarity: nodeData.rarity || "common",
      pool: ResourcePool.create(nodeData.id, {
        capacity: nodeData.capacity, stock: nodeData.capacity, drawLimit: 1.0, regenRate: nodeData.regenRate,
      }),
    }));
  },
  update(deltaSeconds) { this.list.forEach((node) => ResourcePool.tick(node.pool, deltaSeconds)); },
  getNodeAt(column, row) { return this.list.find((n) => n.column === column && n.row === row) || null; },
  attemptGather(column, row) {
    const node = this.getNodeAt(column, row); if (!node) return false;
    const granted = Math.floor(ResourcePool.request(node.pool, 1));
    if (granted < 1) { EventConsole.emit("GATHER", `Gather failed: ${node.label}`, "node is depleted right now", { node: node.id }, "state"); return false; }
    const result=groundDrops.giveOrDrop(node.resource,granted,column,row,"gather-overflow");
    EventConsole.emit("GATHER", `Gathered ${node.label}`, `${node.rarity} material · ${result.dropped?"left on ground — pack full":"carried"} · ${node.pool.stock.toFixed(1)} left`, { node: node.id, rarity:node.rarity, stockAfter: node.pool.stock, dropped:result.dropped }, "decision");
    return true;
  },
  draw(canvasContext) {
    const propFor=(resource)=>{if(["wood","hardwood","resin"].includes(resource))return resource==="hardwood"?"ponderosa":"juniper";if(["ironOre","copperOre","oldAlloy"].includes(resource))return "oreCluster";if(resource==="scrapMetal")return "scrapPile";if(resource==="medicinalHerb")return "medicinalHerb";return "fieldFiber"};
    this.list.forEach((node)=>{if(!camera.isCellVisible(node.column,node.row,3))return;const p=grid.cellToPixels(node.column,node.row),depleted=node.pool.stock<1,key=propFor(node.resource),size=["juniper","ponderosa"].includes(key)?76:54;VisualRuntime.sprite(canvasContext,'props',key,p.x+20,p.y+28,size,depleted?.28:1);if(node.rarity==="rare"&&!depleted){const c=grid.cellCenter(node.column,node.row);canvasContext.save();canvasContext.strokeStyle='rgba(220,177,87,.72)';canvasContext.setLineDash([4,4]);grid.iso.diamondPath(canvasContext,c.x,c.y);canvasContext.stroke();canvasContext.restore()}});
  },
};
