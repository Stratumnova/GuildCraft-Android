// grid.js — 192x192 simulation grid with an isometric presentation map.
// Simulation coordinates remain integer column/row cells; only rendering/input projection changes.
const grid = {
  columns: 192,
  rows: 192,
  cellSizePixels: 40,
  iso: IsometricRuntime.make({columns:192,rows:192,tileWidth:56,tileHeight:28}),
  cellToPixels(column,row){ const p=this.iso.center(column,row); return {x:p.x-20,y:p.y-28,cx:p.x,cy:p.y}; },
  cellCenter(column,row){ return this.iso.center(column,row); },
  pixelsToCell(x,y){ const p=this.iso.toCell(x,y); return this.clampToGrid(p.column,p.row); },
  clampToGrid(column,row){ return {column:Math.max(0,Math.min(this.columns-1,column)),row:Math.max(0,Math.min(this.rows-1,row))}; },
  worldSize(){return this.iso.worldSize()},
  draw(ctx){
    const b=camera.visibleCellBounds(2);
    ctx.save();ctx.strokeStyle='rgba(104,127,105,.38)';ctx.lineWidth=1;
    for(let r=b.top;r<=b.bottom;r++)for(let c=b.left;c<=b.right;c++){
      const p=this.cellCenter(c,r);this.iso.diamondPath(ctx,p.x,p.y);ctx.stroke();
    }
    ctx.restore();
  }
};
