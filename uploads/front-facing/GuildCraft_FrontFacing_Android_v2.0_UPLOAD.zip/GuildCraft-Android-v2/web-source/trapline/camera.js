// camera.js — player-follow camera over isometric Wild presentation.
const camera = {
  viewportWidth:800,viewportHeight:800,screenWidth:800,screenHeight:800,zoom:1.1,x:0,y:0,smoothing:.14,
  resize(width,height){this.screenWidth=Math.max(320,Number(width)||800);this.screenHeight=Math.max(240,Number(height)||800);const aspect=this.screenWidth/this.screenHeight;this.zoom=aspect>=1.55?1.38:aspect>=1.2?1.22:1.06;this.viewportWidth=this.screenWidth/this.zoom;this.viewportHeight=this.screenHeight/this.zoom;this.snapToPlayer()},
  worldWidth(){return grid.worldSize().width},worldHeight(){return grid.worldSize().height},
  maxX(){return Math.max(0,this.worldWidth()-this.viewportWidth)},maxY(){return Math.max(0,this.worldHeight()-this.viewportHeight)},
  targetFor(column,row){const p=grid.cellCenter(column,row);return{x:Math.max(0,Math.min(this.maxX(),p.x-this.viewportWidth/2)),y:Math.max(0,Math.min(this.maxY(),p.y-this.viewportHeight/2))}},
  snapToPlayer(){const t=this.targetFor(player.gridColumn,player.gridRow);this.x=t.x;this.y=t.y},
  update(){const t=this.targetFor(player.gridColumn,player.gridRow);this.x+=(t.x-this.x)*this.smoothing;this.y+=(t.y-this.y)*this.smoothing;if(Math.abs(t.x-this.x)<.25)this.x=t.x;if(Math.abs(t.y-this.y)<.25)this.y=t.y},
  screenToWorldPixel(screenX,screenY){return{x:screenX/this.zoom+this.x,y:screenY/this.zoom+this.y}},
  screenToWorldCell(screenX,screenY){const p=this.screenToWorldPixel(screenX,screenY);return grid.pixelsToCell(p.x,p.y)},
  visibleCellBounds(padding=0){const radius=Math.ceil(Math.max(this.viewportWidth/grid.iso.tileWidth,this.viewportHeight/grid.iso.tileHeight))+6+padding;return{left:Math.max(0,player.gridColumn-radius),right:Math.min(grid.columns-1,player.gridColumn+radius),top:Math.max(0,player.gridRow-radius),bottom:Math.min(grid.rows-1,player.gridRow+radius)}},
  isCellVisible(column,row,padding=1){const b=this.visibleCellBounds(padding);return column>=b.left&&column<=b.right&&row>=b.top&&row<=b.bottom},
  beginWorld(ctx){ctx.save();ctx.scale(this.zoom,this.zoom);ctx.translate(-this.x,-this.y)},endWorld(ctx){ctx.restore()}
};
