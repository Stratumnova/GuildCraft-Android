const portalTransfer={
  deposit(){EventConsole.emit('PORTAL','No cargo shipment needed','Carried inventory belongs to the Portal Player Card and follows the player between rooms.',{},'state');return false},
  claim(){PortalRuntime.applyToRoom(saveState.currentPlayerId,player);return {claimed:0}},
  pendingToMarket(){return[]},pendingToTrap(){return[]},
  enterMarket(){syncPortalPlayer(); clueBridge.commitIfEligible(saveState.currentPlayerId,uniqueBlackRabbit,player.inventory); PortalRuntime.captureRoom(saveState.currentPlayerId,'trapline','Survival v2.6',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player)); saveState.saveNow(player); RoomShell.go('../market-stall/index.html','market-stall','trapline',saveState.currentPlayerId)},
  pause(){syncPortalPlayer();PortalRuntime.showPause(saveState.currentPlayerId)}
};
function syncPortalPlayer(){const bag=typeof survivalSystem!=='undefined'?survivalSystem.bagTier||0:0;PortalRuntime.syncFromRoom(saveState.currentPlayerId,'trapline',player,{roomVersion:'Survival v2.6',bagTier:bag,progression:{catalogue:(typeof fieldCatalogue!=='undefined'?fieldCatalogue.read()||{}:{})}})}