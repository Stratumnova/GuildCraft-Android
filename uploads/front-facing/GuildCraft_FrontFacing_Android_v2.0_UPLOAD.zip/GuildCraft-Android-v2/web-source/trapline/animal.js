// animal.js — local representatives over regional population truth.
// Animals outside the passive band are not rendered or individually simulated;
// their region remains alive through populationPools background ticks.
const animal = {
  list: [],
  nextId: 1,
  reconcileAccumulator: 0,

  isNightTime(){const h=(clock.totalGameMinutes%(24*60))/60;return h<6||h>=20;},

  spawnAnimals() {
    this.list = [];
    this.nextId = 1;
    this.reconcileRepresentatives(true);
  },

  nearbyRegionIndices() {
    const minColumn = Math.max(0, player.gridColumn - simulationBands.passiveRadius - 8);
    const maxColumn = Math.min(grid.columns - 1, player.gridColumn + simulationBands.passiveRadius + 8);
    const minRow = Math.max(0, player.gridRow - simulationBands.passiveRadius - 8);
    const maxRow = Math.min(grid.rows - 1, player.gridRow + simulationBands.passiveRadius + 8);
    const minRx = Math.floor(minColumn / populationPools.regionSize);
    const maxRx = Math.floor(maxColumn / populationPools.regionSize);
    const minRy = Math.floor(minRow / populationPools.regionSize);
    const maxRy = Math.floor(maxRow / populationPools.regionSize);
    const out = [];
    for (let ry = minRy; ry <= maxRy; ry++) for (let rx = minRx; rx <= maxRx; rx++) out.push(rx + ry * populationPools.regionColumns);
    return out;
  },

  targetForRegion(speciesKey, regionIndex) {
    const region = populationPools.regions[speciesKey] && populationPools.regions[speciesKey][regionIndex];
    if (!region || region.stock < .4) return 0;
    const species = speciesContent[speciesKey];
    const fraction = region.stock / Math.max(.001, region.capacity);
    const density = Number(species.representativeDensity || 1);
    const regionMax = Number(species.regionMax || 2);
    return Math.max(0, Math.min(regionMax, Math.round(fraction * density)));
  },

  createRepresentative(speciesKey, regionIndex) {
    const b = populationPools.regionBounds(regionIndex);
    const center = { column: Math.floor((b.left + b.right) / 2), row: Math.floor((b.top + b.bottom) / 2) };
    const radius = Math.max(4, Math.floor(populationPools.regionSize * .65));
    const p = ecologyField.findSpawn(speciesContent[speciesKey].habitatTags, center, radius);
    return {
      id: `${speciesKey}_rep_${this.nextId++}`,
      speciesKey,
      homeRegionIndex: regionIndex,
      gridColumn: p.column,
      gridRow: p.row,
      currentBehavior: "wander",
      hunger: Math.random() * 2,
      ageTicks: Math.floor(Math.random() * 400),
      secondsUntilNextDecision: Math.random() * simulationBands.intervals.aware,
      band: simulationBands.bandFor(p.column, p.row),
    };
  },

  reconcileRepresentatives(force = false) {
    const near = new Set(this.nearbyRegionIndices());
    // Drop representatives that have become deep-background. Regional counts persist.
    this.list = this.list.filter((unit) => near.has(populationPools.regionIndexFor(unit.gridColumn, unit.gridRow)));

    Object.keys(speciesContent).forEach((speciesKey) => {
      near.forEach((regionIndex) => {
        const wanted = this.targetForRegion(speciesKey, regionIndex);
        const existing = this.list.filter((u) => u.speciesKey === speciesKey && populationPools.regionIndexFor(u.gridColumn, u.gridRow) === regionIndex);
        for (let i = existing.length; i < wanted; i++) this.list.push(this.createRepresentative(speciesKey, regionIndex));
        if (!force && existing.length > wanted + 1) {
          let excess = existing.length - wanted;
          this.list = this.list.filter((u) => {
            if (excess > 0 && u.speciesKey === speciesKey && populationPools.regionIndexFor(u.gridColumn, u.gridRow) === regionIndex && u.band !== simulationBands.ACTIVE) { excess -= 1; return false; }
            return true;
          });
        }
      });
    });
  },

  decideBehavior(unit){
    const species=speciesContent[unit.speciesKey],distance=simulationBands.distance(unit.gridColumn,unit.gridRow),tile=ecologyField.get(unit.gridColumn,unit.gridRow),activityMatch=(species.activity?.[clock.phase()]??.5),humanScent=tile?(tile.scent.human||0):0,hungerScore=Math.min(5,unit.hunger);
    const weaponPressure=(unit.speciesKey==="wolf"&&(player.inventory.wolfspike||0)>0&&distance<=8)?(10-distance)*1.2:0; const candidates=[{id:"flee",score:(distance<=species.fleeThreshold?species.fleeThreshold-distance+2:0)+humanScent*species.dangerWeight+weaponPressure},{id:"forage",score:(activityMatch*2)+hungerScore},{id:"wander",score:.8}];
    const result=DecisionEngine.weightedPick(candidates,3);if(result)unit.currentBehavior=result.chosen;
  },

  moveStep(unit,band){
    const species=speciesContent[unit.speciesKey],step=band===simulationBands.PASSIVE?2:1;let target=null;
    if(unit.currentBehavior==="flee")target=ecologyField.bestNeighbor(unit.gridColumn,unit.gridRow,(x,y)=>simulationBands.distance(x,y)-ecologyField.scentScore(x,y,"human")*2,true,step);
    else if(unit.currentBehavior==="forage")target=ecologyField.bestNeighbor(unit.gridColumn,unit.gridRow,(x,y)=>{const t=ecologyField.get(x,y);return t?t.foodStock-t.danger*10-ecologyField.scentScore(x,y,"human")*5:-999;},true,step);
    else{const dirs=[[0,-step],[0,step],[-step,0],[step,0],[0,0]],d=dirs[Math.floor(Math.random()*dirs.length)],p=grid.clampToGrid(unit.gridColumn+d[0],unit.gridRow+d[1]);target={x:p.column,y:p.row};}
    if(target){const fromColumn=unit.gridColumn,fromRow=unit.gridRow;unit.gridColumn=target.x;unit.gridRow=target.y;if(fromColumn!==unit.gridColumn||fromRow!==unit.gridRow)ActorPresentation.move(unit,fromColumn,fromRow,unit.gridColumn,unit.gridRow,unit.currentBehavior==='flee'?.12:.24);}
    ecologyField.depositScent(unit.gridColumn,unit.gridRow,species.scentKey,band===simulationBands.ACTIVE?.55:.18);
    if(unit.currentBehavior==="forage"){const eaten=ecologyField.requestFood(unit.gridColumn,unit.gridRow,species.foodNeed*(band===simulationBands.PASSIVE?.6:1));unit.hunger=Math.max(0,unit.hunger-eaten*.8);}else unit.hunger=Math.min(7,unit.hunger+.04*simulationBands.coarseStepsFor(band));
    unit.ageTicks+=simulationBands.coarseStepsFor(band);
  },

  update(dt){
    this.attackAccumulator=(this.attackAccumulator||0)+dt;
    if(this.attackAccumulator>=GCBalance.threat.attackIntervalSeconds){this.attackAccumulator=0;this.list.forEach(u=>{const s=speciesContent[u.speciesKey];if(!s.hostileToPlayer||u.band!==simulationBands.ACTIVE)return;const d=simulationBands.distance(u.gridColumn,u.gridRow),active=(s.activity?.[clock.phase()]||0);if(d<=1.5&&active>.5&&!survivalSystem.nearFire()){const base=u.speciesKey==='wolf'?GCBalance.threat.wolfDamage:GCBalance.threat.boarDamage,night=clock.phase()==='night'?GCBalance.threat.nightDamageMultiplier:1;survivalSystem.health=Math.max(0,survivalSystem.health-base*night);ActorPresentation.signal(u,'hunt',.35);ActorPresentation.signal(player,'hurt',.55);EventConsole.emit('PREDATOR',`${s.label} attack`,clock.phase()==='night'?'You are prey after dark. A lit fire creates a safe radius.':'The animal turns on you.',{},'state')}})}
    this.reconcileAccumulator += dt;
    if (this.reconcileAccumulator >= 3.5) { this.reconcileAccumulator = 0; this.reconcileRepresentatives(false); }
    this.list.forEach(unit=>{
      const newBand=simulationBands.bandFor(unit.gridColumn,unit.gridRow);unit.band=newBand;
      if (newBand === simulationBands.BACKGROUND) return; // population engine owns deep background life
      unit.secondsUntilNextDecision-=dt;
      if(unit.secondsUntilNextDecision>0)return;
      this.decideBehavior(unit);this.moveStep(unit,newBand);
      unit.secondsUntilNextDecision=simulationBands.intervalFor(newBand)*(.7+Math.random()*.65);
    });
  },

  drawUnit(ctx,unit){const species=speciesContent[unit.speciesKey];const pp=ActorPresentation.projectedPoint(unit,grid),p={x:pp.x,y:pp.y},pose=pp.pose;const size=unit.speciesKey==='deer'||unit.speciesKey==='boar'?72:unit.speciesKey==='wolf'?68:58;const fleeLift=unit.currentBehavior==='flee'&&pose.moving?2:0;grid.iso.shadow(ctx,p.x,p.y,size*.38*(pose.moving?.94:1),7,.22);if(!VisualRuntime.spritePose(ctx,'animals',unit.speciesKey,p.x,p.y+3,size,{...pose,lift:fleeLift},1)){ctx.fillStyle=species.color;ctx.beginPath();ctx.arc(p.x,p.y-8+pose.bob,14,0,Math.PI*2);ctx.fill();}},
  draw(ctx){this.list.forEach(unit=>{const species=speciesContent[unit.speciesKey];if((species.activity?.[clock.phase()]||0)<=0.05||unit.band!==simulationBands.ACTIVE||!camera.isCellVisible(unit.gridColumn,unit.gridRow,2))return;this.drawUnit(ctx,unit);});
  },
  bandCounts(){return this.list.reduce((a,u)=>(a[u.band]=(a[u.band]||0)+1,a),{});}
};
