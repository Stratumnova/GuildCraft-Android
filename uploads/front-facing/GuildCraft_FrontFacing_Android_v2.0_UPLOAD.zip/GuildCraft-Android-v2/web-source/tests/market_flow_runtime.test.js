const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..');
const ctx={console,Math};vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root,'market-stall/visualLayout.js'),'utf8'),ctx);
const layout=vm.runInContext('MARKET_VISUAL_LAYOUT',ctx);ctx.MARKET_VISUAL_LAYOUT=layout;
ctx.grid={
  inBounds:(c,r)=>c>=0&&r>=0&&c<64&&r<64,
  isWalkable:(c,r)=>c>=0&&r>=0&&c<64&&r<64&&!layout.isBlocked(c,r),
  closestWalkable(c,r){c=Math.max(0,Math.min(63,Math.round(c)));r=Math.max(0,Math.min(63,Math.round(r)));if(this.isWalkable(c,r))return{column:c,row:r};for(let rad=1;rad<8;rad++)for(let dc=-rad;dc<=rad;dc++)for(let dr=-rad;dr<=rad;dr++)if(Math.max(Math.abs(dc),Math.abs(dr))===rad&&this.isWalkable(c+dc,r+dr))return{column:c+dc,row:r+dr};return{column:c,row:r}},
  nextWalkStep(fc,fr,tc,tr){return {column:fc+Math.sign(tc-fc),row:fr+Math.sign(tr-fr)}}
};
ctx.clock={totalGameMinutes:0};
vm.runInContext(fs.readFileSync(path.join(root,'market-stall/marketFlow.js'),'utf8'),ctx);
const flow=vm.runInContext('marketFlow',ctx);
const target=layout.customerStops.find(s=>s.stallId==='vendor_01');
const pathOut=flow.findPath(32,59,target.column,target.row);
assert(pathOut.length>10,'route should cross market');
for(const p of pathOut){assert(ctx.grid.isWalkable(p.column,p.row),'path crossed blocked cell');assert(!layout.isReserved(p.column,p.row),'path crossed reserved expansion plot')}
const laneCells=pathOut.filter(p=>layout.isRoadCell(p.column,p.row)||layout.isGatheringSquare(p.column,p.row)).length;
assert(laneCells/pathOut.length>.45,'route should substantially favor public lanes');
const stops=layout.customerStopsFor('vendor_01');assert(stops.length===2,'vendor should expose two customer stops');
assert(layout.vendorKeepers.length===24,'every permanent stall should have a keeper');
console.log('market_flow runtime: PASS', {steps:pathOut.length,laneShare:(laneCells/pathOut.length).toFixed(2)});
