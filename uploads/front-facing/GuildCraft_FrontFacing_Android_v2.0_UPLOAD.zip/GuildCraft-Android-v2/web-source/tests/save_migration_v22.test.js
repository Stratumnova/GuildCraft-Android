const fs=require('fs'),vm=require('vm'),assert=require('assert');
function storage(){const m=new Map();return{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),_m:m}}
const localStorage=storage(),sessionStorage=storage();
const ctx={console,localStorage,sessionStorage,Date,JSON,Math,encodeURIComponent,decodeURIComponent,escape,unescape,btoa:s=>Buffer.from(s,'binary').toString('base64'),atob:s=>Buffer.from(s,'base64').toString('binary')};ctx.globalThis=ctx;ctx.window=ctx;vm.createContext(ctx);
vm.runInContext(fs.readFileSync('portal/shared/portalRuntime.js','utf8'),ctx);
const P=ctx.PortalRuntime;assert(P,'PortalRuntime loads');
// GCPS2 round trip preserves portable player state and excludes till.
P.bootstrap('p',{avatarName:'Tester',floppyBalance:17,inventory:{wood:3,liveCottontail:1}});P.captureRoom('p','market-stall','Fieldworks v2.4',{marketBusiness:{owned:true,till:99,lifetimeSales:4}},'test');
const code=P.exportCode('p');assert(code.startsWith('GCPS2.'));localStorage.clear();let r=P.importCode(code,'p');assert(r.ok);let restored=P.read('p');assert.equal(restored.player.floppyBalance,17);assert.equal(restored.player.inventory.liveCottontail,1);assert.equal(restored.rooms['market-stall'].state.marketBusiness.till,undefined);
// Tampering is rejected without replacing existing state.
const before=JSON.stringify(P.read('p'));const bad=code.slice(0,-1)+(code.endsWith('0')?'1':'0');r=P.importCode(bad,'p');assert(!r.ok);assert.equal(JSON.stringify(P.read('p')),before);
// Legacy GCPS1 snapshots without history must migrate rather than crash.
const legacy={schema:P.SCHEMA,schemaVersion:1,playerId:'old',player:{avatarName:'Old',floppyBalance:8,inventory:{fiber:2}},rooms:{},versions:{},session:{currentRoom:'portal',previousRoom:null}};
const payload=JSON.stringify(legacy);function hashText(str){let h=2166136261;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)}return(h>>>0).toString(16).padStart(8,'0')};const enc=Buffer.from(unescape(encodeURIComponent(payload)),'binary').toString('base64').replace(/=+$/,'');
r=P.importCode(`GCPS1.${enc}.${hashText(payload)}`,'migrated');assert(r.ok,'legacy GCPS1 without history should import');assert.equal(P.read('migrated').player.floppyBalance,8);
console.log('PASS save migration/card torture tests');
