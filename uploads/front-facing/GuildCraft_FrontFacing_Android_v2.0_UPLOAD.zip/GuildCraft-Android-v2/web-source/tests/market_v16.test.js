const fs=require('fs');
const vm=require('vm');
const assert=require('assert');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

// Static contract checks for the next market-life pass.
const layoutSrc=read('market-stall/visualLayout.js');
assert(layoutSrc.includes('marketDressing'), 'expected mapped market dressing');
assert(layoutSrc.includes('customerStops'), 'expected customer stop positions');
assert(layoutSrc.includes('flowNodes'), 'expected market flow nodes');
assert(layoutSrc.includes('cibola-grants-settlement'), 'expected Cibola settlement biome id');


assert(layoutSrc.includes('vendorKeepers'), 'expected permanent stall keepers');
const marketHtml=read('market-stall/index.html');
const wildHtml=read('trapline/index.html');
assert(marketHtml.includes('data-biome="cibola-grants-settlement"'),'market should declare settlement biome');
assert(wildHtml.includes('data-biome="cibola-grants-wild"'),'Wild should declare Wild biome');
assert(read('shared/biomeRegistry.js').includes('function register(id,pack)'),'biome registry should be extensible');
const districtLayout=JSON.parse(read('market-stall/MARKET_LAYOUT_MAP.json'));
assert.equal(districtLayout.vendorKeepers.length,24,'every permanent stall should have a keeper');
const operator=districtLayout.anchors.playerStallOperator;
for(const s of districtLayout.customerStops.filter(x=>x.stallId==='player')) assert(!(s.column===operator.column&&s.row===operator.row),'customer stop must not occupy player operator cell');
const inRect=(z,c,r)=>c>=z.x&&c<z.x+z.w&&r>=z.y&&r<z.y+z.h;
for(const d of districtLayout.marketDressing){
  assert(!districtLayout.zones.reservedExpansion.some(z=>inRect(z,d.column,d.row)),`dressing ${d.kind} invaded reserved expansion`);
}

const flowPath=path.join(root,'market-stall/marketFlow.js');
assert(fs.existsSync(flowPath),'marketFlow.js should exist');
const flowSrc=fs.readFileSync(flowPath,'utf8');
assert(flowSrc.includes('findPath'), 'market flow should provide pathfinding');
assert(flowSrc.includes('movementCost'), 'market flow should weight movement cells');
assert(flowSrc.includes('reservedExpansion'), 'market flow should avoid reserved expansion plots');

const renderer=read('market-stall/renderers/worldRenderer.js');
for(const key of ['marketDressing','marketLocal1','marketLocal2','marketLocal3','marketLocal4','districtSign','shadeTarp','marketBench','waterBarrel','novaWayfinder']){
  assert(renderer.includes(key),`renderer should use ${key}`);
}

const npcSrc=read('market-stall/npc.js');
assert(npcSrc.includes('marketFlow.nextStep'), 'NPC walking should use marketFlow');
assert(npcSrc.includes('secondsAtStop'), 'NPCs should dwell at market stops');
assert(npcSrc.includes('visualVariant'), 'generic NPCs should have stable visual variants');

const manifest=JSON.parse(read('assets/cibola/ASSET_MANIFEST.json'));
for(const key of ['marketLocal1','marketLocal2','marketLocal3','marketLocal4']) assert(manifest.npcs[key],`missing NPC asset ${key}`);
for(const key of ['districtSign','shadeTarp','marketBench','waterBarrel','novaWayfinder']) assert(manifest.props[key],`missing prop asset ${key}`);

const marketMap=JSON.parse(read('market-stall/config/MARKET_WORLD_MAP.json'));
assert.equal(marketMap.biomeId,'cibola-grants-settlement');
assert.equal(marketMap.columns,64);
assert.equal(marketMap.rows,64);
assert(Array.isArray(marketMap.districts) && marketMap.districts.length>=6,'market world map should declare districts');
assert(Array.isArray(marketMap.expansionPlots) && marketMap.expansionPlots.length>=8,'expansion plots preserved');

console.log('market_v16 static contracts: PASS');
