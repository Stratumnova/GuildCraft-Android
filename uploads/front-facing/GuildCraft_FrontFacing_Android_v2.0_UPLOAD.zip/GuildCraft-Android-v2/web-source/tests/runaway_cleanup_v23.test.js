const fs=require('fs'), path=require('path');
const root=path.resolve(__dirname,'..');
function read(p){return fs.readFileSync(path.join(root,p),'utf8')}
let fail=[]; function check(ok,msg){if(!ok)fail.push(msg)}
check(!read('portal/portal.js').includes('PORTAL v1.6'),'portal console still announces v1.6');
check(read('READY_TO_GO.md').includes('Portal v2.3'),'READY_TO_GO current Portal version stale');
check(!fs.existsSync(path.join(root,'tests/test_market_expansion.py.tmp')),'temporary test file remains');
check(!read('market-stall/index.html').includes('instrumented debug renderer'),'Market exposes debug renderer in player instructions');
check(!read('trapline/index.html').includes('id="rendererSwitch"'),'Trapline exposes debug renderer switch in normal play');
check(!read('trapline/index.html').includes("switchTab('workshop')"),'Trapline still calls Field Gear a workshop internally');
check(!read('trapline/main.js').includes('renderWorkshopPanel'),'Trapline still uses obsolete workshop naming');
check(!read('shared/playBalance.js').includes('legacyCraftingFee'),'active balance API still uses legacy crafting name');
const stale=['VISUAL_FULLSCREEN_QA.md','BUILD_AUDIT_V1_1.md','MARKET_EXPANSION_V1_5_QA.md','ISOMETRIC_CIBOLA_V1_4_QA.md','FULLSCREEN_CIBOLA_V1_3_QA.md','TRAPLINE_WILD_LIFE_V1_7_QA.md','CHARACTER_PRESENTATION_V1_8_QA.md','PLAY_BALANCE_V1_9_QA.md','NPC_BEHAVIOR_V2_0_QA.md'];
check(stale.every(f=>!fs.existsSync(path.join(root,f))),'historical stage QA files remain at release root');
if(fail.length){console.error('FAIL runaway cleanup\n- '+fail.join('\n- '));process.exit(1)}
console.log('PASS runaway cleanup contract');
