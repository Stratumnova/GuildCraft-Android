const fs=require('fs'),assert=require('assert');
const read=p=>fs.readFileSync(p,'utf8');
for(const html of ['trapline/index.html','market-stall/index.html']){
  const s=read(html);assert(s.includes('../shared/actorPresentation.js'),`${html} missing actorPresentation runtime`);
}
const trapMain=read('trapline/main.js');
const marketMain=read('market-stall/main.js');
assert(trapMain.includes('ActorPresentation.move(player'),'Trapline player movement must animate');
assert(marketMain.includes('ActorPresentation.move(player'),'Market player movement must animate');
assert(read('trapline/animal.js').includes('ActorPresentation.move(unit'),'animal movement must animate');
assert(read('market-stall/npc.js').includes('ActorPresentation.move(npcUnit'),'market NPC movement must animate');
const tr=read('trapline/renderers/worldRenderer.js'), mr=read('market-stall/renderers/worldRenderer.js');
assert(tr.includes('ActorPresentation.projectedPoint'),'Trapline renderer must interpolate actor positions');
assert(mr.includes('ActorPresentation.projectedPoint'),'Market renderer must interpolate actor positions');
assert(tr.includes('VisualRuntime.spritePose'),'Trapline renderer must render actor pose');
assert(mr.includes('VisualRuntime.spritePose'),'Market renderer must render actor pose');
console.log('presentation integration: PASS');
