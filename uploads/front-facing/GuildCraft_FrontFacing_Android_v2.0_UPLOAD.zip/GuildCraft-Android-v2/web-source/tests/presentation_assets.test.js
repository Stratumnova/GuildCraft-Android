const fs=require('fs'),assert=require('assert');
const manifest=JSON.parse(fs.readFileSync('assets/cibola/ASSET_MANIFEST.json','utf8'));
for(const key of ['gather','hunt','craft','trade','hurt','eat','drink','trap']){
  assert(manifest.fx&&manifest.fx[key],`missing fx manifest ${key}`);
  assert(fs.existsSync(manifest.fx[key]),`missing fx png ${manifest.fx[key]}`);
}
const biome=fs.readFileSync('shared/biomeRegistry.js','utf8');
assert(biome.includes("fx:{gather:"),'biome pack should expose presentation fx');
const vr=fs.readFileSync('shared/visualRuntime.js','utf8');
assert(vr.includes('spritePose'),'visual runtime needs pose-aware sprite drawing');
assert(vr.includes('function effect'),'visual runtime needs reusable fx drawing');
console.log('presentation assets: PASS');
