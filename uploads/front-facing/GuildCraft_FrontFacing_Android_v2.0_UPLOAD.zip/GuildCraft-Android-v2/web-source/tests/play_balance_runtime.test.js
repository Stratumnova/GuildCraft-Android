const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const ctx={console,Math,Date,
  player:{gridColumn:0,gridRow:0,inventory:{},addToInventory(){return true},targetColumn:null,targetRow:null},
  clock:{skipToMorning(){},phase(){return 'day'}},
  ActorPresentation:{signal(){}},EventConsole:{emit(){}},
  ecologyField:{tiles:[1],get(){return {habitat:'creek'}}}
};
vm.createContext(ctx);
vm.runInContext(read('shared/playBalance.js'),ctx);
vm.runInContext(read('trapline/survivalSystem.js'),ctx);
const surv=vm.runInContext('survivalSystem',ctx);
surv.food=100;surv.water=100;surv.health=100;surv.fireFuel=0;surv.tick(36*60);
assert(Math.abs(surv.food-76.24)<0.02,`food after day ${surv.food}`);
assert(Math.abs(surv.water-63.28)<0.02,`water after day ${surv.water}`);
assert.equal(surv.health,100,'healthy fed/hydrated player should not lose health');
surv.water=40;assert(surv.drinkNatural());assert.equal(surv.water,85,'creek refill should use balance profile');
ctx.player.inventory.rabbitMeat=1;surv.food=40;assert(surv.eat('rabbitMeat'));assert.equal(surv.food,50,'raw meat value should use balance profile');
ctx.player.inventory['cooked:rabbitMeat']=1;surv.food=40;surv.health=90;assert(surv.eat('cooked:rabbitMeat'));assert.equal(surv.food,74);assert.equal(surv.health,94);

const econCtx={console};vm.createContext(econCtx);vm.runInContext(read('shared/playBalance.js'),econCtx);econCtx.getFinishedItemLookup=()=>({});vm.runInContext(read('market-stall/pricing.js'),econCtx);const pricing=vm.runInContext('pricing',econCtx);assert.equal(pricing.getSweetSpotForItem('wood'),2);assert.equal(pricing.getSweetSpotForItem('oldAlloy'),12);assert.equal(pricing.getSweetSpotForItem('wolfPelt'),14);
console.log('play balance runtime: PASS');
