const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

assert(fs.existsSync(path.join(root,'shared/playBalance.js')),'shared playBalance.js must exist');
const ctx={console}; vm.createContext(ctx);
vm.runInContext(read('shared/playBalance.js'),ctx);
const balance=vm.runInContext('GCBalance',ctx);

// Survival should matter without ending a first exploration session too early.
const daySeconds=36*60;
const foodAfterDay=100-daySeconds*balance.survival.foodDrainPerSecond;
const waterAfterDay=100-daySeconds*balance.survival.waterDrainPerSecond;
assert(foodAfterDay>=72 && foodAfterDay<=85,`one game day food target out of range: ${foodAfterDay}`);
assert(waterAfterDay>=55 && waterAfterDay<=72,`one game day water target out of range: ${waterAfterDay}`);
assert(balance.survival.cookedFoodValue>balance.survival.rawFoodValue*2,'cooking should materially outperform raw meat');
assert(balance.survival.naturalWaterValue>=40,'natural water should be a meaningful refill');

// Hostiles should be dangerous but leave reaction time at full health.
const wolfNight=balance.threat.wolfDamage*balance.threat.nightDamageMultiplier;
assert(wolfNight*5<100,'five wolf night hits should not instantly consume a full health bar');
assert(balance.threat.attackIntervalSeconds>=2,'hostile attacks need readable reaction time');

// Weapon progression must be monotonic.
for(const family of ['spear','bow','gun']){
  const base=balance.hunting.weaponBaseChance[family];
  assert(base>0 && base<1,`${family} base chance invalid`);
}
assert(balance.hunting.weaponBaseChance.spear<balance.hunting.weaponBaseChance.bow);
assert(balance.hunting.weaponBaseChance.bow<balance.hunting.weaponBaseChance.gun);
assert(balance.hunting.tierBonus>0,'weapon tiers must improve success');

// Economy should distinguish common and rare field goods.
assert(balance.market.sellSweetSpot.oldAlloy>balance.market.sellSweetSpot.wood*3,'old-world alloy should not sell like firewood');
assert(balance.market.sellSweetSpot.wolfPelt>balance.market.sellSweetSpot.rabbitPelt,'dangerous pelts need higher value');
assert(balance.market.materialBuyCost('copperOre')>balance.market.materialBuyCost('wood'),'scarcer materials should cost more to source');

// Ada remains accessible but advanced work costs more service labor.
assert.equal(balance.market.craftingFee('bag4'),1,'entry gear should keep a low service fee');
assert(balance.market.craftingFee('bag10')>balance.market.craftingFee('bag4'),'expedition gear should cost more service labor');
assert(balance.market.craftingFee('gun3')>=3,'advanced gun service fee should be meaningful');
assert.equal(balance.market.stageCraftingFee(0),1,'entry crafting fee should remain low');
assert(balance.market.stageCraftingFee(5)>=3,'late crafting fee should scale with stage');

// Hired seller is useful but should not liquidate stock every few seconds.
assert(balance.market.sellerBackgroundAttemptChance<=0.05,'seller background attempt rate too fast');
assert(balance.market.sellerCatchupIntervalMs>=60000,'offline seller cadence should be measured in minutes');
assert(balance.market.liquidityForegroundBuyChance<=0.04,'liquidity trader foreground cadence too aggressive');

console.log('play balance v1.9 contracts: PASS');
