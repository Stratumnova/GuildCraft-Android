import json, pathlib, re, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class MarketExpansionTests(unittest.TestCase):
    def test_visual_layout_is_64_square_and_has_real_market_zones(self):
        data=json.loads((ROOT/'market-stall/MARKET_LAYOUT_MAP.json').read_text())
        self.assertEqual(data['canonical']['worldColumns'],64)
        self.assertEqual(data['canonical']['worldRows'],64)
        zones=data.get('zones',{})
        for key in ['entranceRoad','centralSpine','crossLanes','vendorRows','playerStallDistrict','crafterLane','foodCourt','loadingEdge','gatheringSquare','reservedExpansion']:
            self.assertIn(key,zones)
        self.assertGreaterEqual(len(data.get('stallPlots',[])),16)
        self.assertGreaterEqual(len(data['zones']['reservedExpansion']),6)


    def test_active_vendor_plots_do_not_overlap_player_or_reserved_expansion(self):
        data=json.loads((ROOT/'market-stall/MARKET_LAYOUT_MAP.json').read_text())
        def inside(rect,c,r): return rect['x']<=c<rect['x']+rect['w'] and rect['y']<=r<rect['y']+rect['h']
        player_zone=data['zones']['playerStallDistrict']
        reserved=data['zones']['reservedExpansion']
        for stall in data['stallPlots']:
            self.assertFalse(inside(player_zone,stall['column'],stall['row']), stall['id'])
            self.assertFalse(any(inside(rect,stall['column'],stall['row']) for rect in reserved), stall['id'])

    def test_runtime_grid_is_64_square(self):
        text=(ROOT/'market-stall/grid.js').read_text()
        self.assertRegex(text,r'columns\s*:\s*64')
        self.assertRegex(text,r'rows\s*:\s*64')
        self.assertIn('columns:64,rows:64',text.replace(' ',''))

    def test_other_stalls_use_layout_plots_not_legacy_positions(self):
        text=(ROOT/'market-stall/otherStalls.js').read_text()
        self.assertIn('MARKET_VISUAL_LAYOUT.stallPlots',text)
        self.assertNotIn('positions: [',text)

    def test_depth_queue_exists_and_sorts(self):
        text=(ROOT/'market-stall/renderers/worldRenderer.js').read_text()
        self.assertIn('buildDepthQueue',text)
        self.assertRegex(text,r'\.sort\s*\(')
        for token in ['player','crafterAda','marketActors','otherStalls','visualProps']:
            self.assertIn(token,text)

    def test_walkability_contract_is_data_driven(self):
        text=(ROOT/'market-stall/grid.js').read_text()
        self.assertIn('isWalkable',text)
        self.assertIn('nextWalkStep',text)
        self.assertIn('closestWalkable',text)
        main=(ROOT/'market-stall/main.js').read_text()
        self.assertIn('grid.nextWalkStep',main)
        npc=(ROOT/'market-stall/npc.js').read_text()
        self.assertIn('grid.nextWalkStep',npc)
        self.assertIn('frontageColumn',npc)

    def test_player_stall_uses_mapped_operator_cell(self):
        text=(ROOT/'market-stall/marketBusiness.js').read_text()
        self.assertIn('playerStallOperator',text)
        self.assertNotIn('const s=this.salesTable()',text)

    def test_state_validator_expects_64(self):
        text=(ROOT/'market-stall/runtime/stateValidator.js').read_text()
        self.assertIn('grid 64x64',text)
        self.assertIn('grid.columns===64',text)
        self.assertIn('grid.rows===64',text)
if __name__=='__main__': unittest.main()
