const fs=require('fs'),vm=require('vm'),assert=require('assert');
function store(){const m=new Map();return{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear()}}
// Hidden route branch matrix.
let localStorage=store();let c={console,localStorage,Date};vm.createContext(c);vm.runInContext(fs.readFileSync('trapline/clueBridge.js','utf8')+';globalThis.cb=clueBridge;',c);const b=c.cb;
const live={captured:true,processed:false,tradedAway:false};assert.equal(b.isEligible(live,{liveCottontail:1}),true);assert.equal(b.isEligible({...live,processed:true},{liveCottontail:1}),false);assert.equal(b.isEligible({...live,tradedAway:true},{liveCottontail:1}),false);assert.equal(b.isEligible(live,{liveCottontail:0}),false);assert.equal(b.commitIfEligible('p',live,{liveCottontail:1}),true);let sheet=JSON.parse(localStorage.getItem('timesheet_p'));assert(sheet.routeMarkers['portal/black cottontail'].unlocked);const first=sheet.routeMarkers['portal/black cottontail'].firstRecordedAt;b.commitIfEligible('p',live,{liveCottontail:1});sheet=JSON.parse(localStorage.getItem('timesheet_p'));assert.equal(sheet.routeMarkers['portal/black cottontail'].firstRecordedAt,first,'route marker must be one-shot');
// Active Trapline must never load its dormant workshop implementation.
const th=fs.readFileSync('trapline/index.html','utf8');assert(!/workshop\.js/.test(th));
// Portable cards must exclude local ecology noise and stall till by contract.
const pr=fs.readFileSync('portal/shared/portalRuntime.js','utf8');assert(/populationState:null/.test(pr));assert(/delete out\.marketBusiness\.till/.test(pr));
// Room crossings capture before transition.
const tm=fs.readFileSync('trapline/portalTransfer.js','utf8'),mm=fs.readFileSync('market-stall/main.js','utf8');assert(tm.indexOf("captureRoom(saveState.currentPlayerId,'trapline'")>=0&&tm.indexOf("captureRoom(saveState.currentPlayerId,'trapline'")<tm.indexOf("RoomShell.go('../market-stall/index.html'"));assert(mm.indexOf("captureRoom(saveState.currentPlayerId,'market-stall'")<mm.indexOf("RoomShell.go('../trapline/index.html'"));
console.log('PASS playthrough regression contracts');
