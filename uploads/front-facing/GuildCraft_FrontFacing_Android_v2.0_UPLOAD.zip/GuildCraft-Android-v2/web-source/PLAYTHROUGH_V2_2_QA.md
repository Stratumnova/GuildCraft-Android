# Playthrough Regression QA — v2.2

Fresh release verification is recorded in `PLAYTHROUGH_V2_2_VERIFICATION.md`.

Two state-continuity defects were targeted by this pass:
1. Old GCPS1 snapshots without a `history` array failed during import when the import audit entry was appended. Import now normalizes missing history to an empty array before auditing.
2. Wild → Market relied on pagehide/autosave for the full Trapline room snapshot. The crossing now captures the room snapshot synchronously before `RoomShell.go`, matching the Market → Wild contract.

The hidden Cottontail remains an ordinary-looking Cottontail. Its clue branch is tested as state only; no new visual signal was introduced.
