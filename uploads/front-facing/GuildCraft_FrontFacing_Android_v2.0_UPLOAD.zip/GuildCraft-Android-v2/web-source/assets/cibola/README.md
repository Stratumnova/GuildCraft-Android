# Cibola / Grants + Nova Visual Asset Pack

Reusable room art for GuildCraft. These PNGs are independent from gameplay logic and are addressed through `ASSET_MANIFEST.json` and the shared biome/visual runtime.

Folders:
- `terrain/` — grid-floor textures for Wild and Market.
- `animals/` — separate smooth sprites for the ten current field species. The hidden cottontail intentionally uses the ordinary `cottontail.png`.
- `npcs/` — player, Ada, Kerr Voss, Mira Quill, Rook Fen, generic market actors, and four reusable local-market visual variants.
- `props/` — Cibola vegetation, resource props, market stalls/dressing, and restrained Nova/legacy infrastructure.

The simulation grid remains authoritative. Art can be replaced later without rewriting room logic as long as manifest keys stay stable.

## Market category stalls

- `props/market_stall_food.png`
- `props/market_stall_blacksmith.png`
- `props/market_stall_alchemy.png`
- `props/market_stall_carpenter.png`
- `props/market_stall_tannery.png`

## Market settlement dressing

- `props/district_sign.png`
- `props/shade_tarp.png`
- `props/market_bench.png`
- `props/water_barrel.png`
- `props/market_lantern.png`
- `props/nova_wayfinder.png`

These are reusable renderer assets. District placement lives in `market-stall/MARKET_LAYOUT_MAP.json`; gameplay and account logic do not depend on their appearance.

## Biome scope

This pack serves the current Cibola/Grants connected area. `shared/biomeRegistry.js` distinguishes `cibola-grants-wild` from `cibola-grants-settlement`, and later rooms can register unrelated biome packs without turning Cibola art into a global assumption.

## Presentation feedback assets

`fx/` contains reusable transparent action markers used by the shared actor-presentation layer:
`gather`, `hunt`, `craft`, `trade`, `hurt`, `eat`, `drink`, and `trap`.
They are presentation-only and never own gameplay state.

`shared/actorPresentation.js` provides lightweight procedural motion (interpolated grid steps, facing, idle bob, action pulses) over the existing sprites. This keeps animation mobile-friendly and lets later biome packs replace character art without rewriting simulation logic.
