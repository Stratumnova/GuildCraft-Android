# GuildCraft Fullscreen Cibola v2.2 — Playthrough Readiness

This pass is the save/migration and room-continuity hardening stage before a human proper playthrough.

## Torture coverage
- GCPS2 round-trip preserves portable player state.
- Portable cards exclude uncollected Market till and reconstructable ecology population state.
- Tampered Player Cards are rejected without replacing the current save.
- Legacy GCPS1 cards that predate the history array migrate safely.
- Wild → Market now captures the authoritative Trapline room snapshot before the room transition, rather than relying on pagehide timing.
- Market → Wild already captures the Market room snapshot before transition and remains covered by regression tests.
- Hidden Cottontail route-marker matrix covers alive/carried, processed, traded-away, absent, and one-shot marker behavior.
- Active Trapline still does not load the dormant workshop implementation.

## Release versions
- R_D Portal v2.2
- Trapline Survival v2.5
- Market Stall Fieldworks v2.4
- Portable Player Card GCPS2; GCPS1 import retained.

## Boundary
Automated regression can prove state contracts and deterministic branches. It cannot replace the upcoming human-feel playthrough for pacing, touch comfort, visual readability, and whether progression is understandable without developer knowledge.
