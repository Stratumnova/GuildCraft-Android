// vendor.js
// -----------------------------------------------------------------------------
// Buying base materials from an NPC vendor, and bartering for trade goods
// (Section 6: "some higher stages require trade, not money" - and "a
// player's own specialization stage can be used as trade leverage").
//
// AI BUILD: material stock is no longer infinite. Each (category, material)
// pair gets its own ResourcePool (GuildCraft toolkit) - finite stock, a
// regen rate, and a hard per-purchase draw limit as a fraction of current
// stock, so a stall can't be bought dry in one go even at full price. Pools
// are created lazily on first purchase attempt and regenerate every game
// tick via vendor.update(deltaSeconds), called from the main game loop.
// -----------------------------------------------------------------------------

const vendor = {

  baseMaterialCost: 2, // compatibility fallback; item-aware cost comes from GCBalance

  _pools: {}, // "categoryKey:materialName" -> ResourcePool instance

  _getPool(vendorCategory, materialName) {
    const key = `${vendorCategory}:${materialName}`;
    if (!this._pools[key]) {
      // Capacity/regen numbers are first-pass placeholders (fix-it-add-it
      // list already flags the whole pricing/economy layer for tuning) -
      // 50 capacity, half a unit per second regen, no single purchase can
      // take more than half of whatever's currently in stock.
      this._pools[key] = ResourcePool.create(key, {
        capacity: 50, stock: 50, drawLimit: 0.5, regenRate: 0.5,
      });
    }
    return this._pools[key];
  },

  // Call every game tick so vendor stock regenerates over time. regenRate
  // is "units per second" - passing deltaSeconds straight through as
  // ResourcePool.tick()'s seasonMultiplier makes that unit conversion work.
  update(deltaSeconds) {
    Object.values(this._pools).forEach((pool) => ResourcePool.tick(pool, deltaSeconds));
  },

  // Vendor access rule (Section 6): start buying only from your own
  // path's vendor, capped to your unlocked stage. Unlocking a worker
  // (Section 6) opens buying from other specializations' vendors too.
  canBuyFrom(vendorCategory) {
    if (vendorCategory === player.chosenCategory) return true;
    return player.workerLevel > 0;
  },

  buyMaterial(vendorCategory, materialName) {
    if (!this.canBuyFrom(vendorCategory)) {
      EventConsole.emit(
        "VENDOR", `Buy blocked: ${materialName}`, `vendor locked - unlock a worker to buy from ${vendorCategory}`,
        { category: vendorCategory, material: materialName }, "state"
      );
      return false;
    }
    const cost=GCBalance.market.materialBuyCost(materialName);
    if (player.floppyBalance < cost) {
      EventConsole.emit(
        "VENDOR", `Buy failed: ${materialName}`, "not enough stall-local floppies",
        { material: materialName, cost }, "state"
      );
      return false;
    }

    const pool = this._getPool(vendorCategory, materialName);
    const granted = Math.floor(ResourcePool.request(pool, 1));

    if (granted < 1) {
      // Stock was too low for a whole unit - the fractional draw still
      // happened inside ResourcePool (represents spoilage/inefficiency
      // buying from an almost-empty stall), but no floppies changes hands
      // since nothing usable was actually received.
      EventConsole.emit(
        "VENDOR", `Buy failed: ${materialName}`, `${vendorCategory} vendor is nearly out of stock`,
        { material: materialName, poolStock: pool.stock }, "state"
      );
      return false;
    }

    player.floppyBalance -= cost;
    player.addToInventory(materialName, granted);
    EventConsole.emit(
      "VENDOR", `Bought ${materialName}`, `${vendorCategory} vendor, ${pool.stock.toFixed(1)} left in stock`,
      { material: materialName, category: vendorCategory, stockAfter: pool.stock }, "decision"
    );
    return true;
  },

  // Finds the highest-stage finished item the player currently holds in
  // their own path (checking all 4 items at each stage) - this is what
  // gets offered as trade leverage.
  findBestTradeOffer() {
    const pathData = player.getCurrentPathData();
    if (!pathData) return null;

    for (let stageIndex = pathData.stages.length - 1; stageIndex >= 0; stageIndex--) {
      const stageItems = pathData.stages[stageIndex].items;
      for (const item of stageItems) {
        if ((player.inventory[item.name] || 0) > 0) {
          return { itemName: item.name, stageIndex };
        }
      }
    }
    return null;
  },

  // Attempts to barter for a trade good using the player's best available
  // finished item. Acceptance uses the same sweet-spot model as sales -
  // the closer your offered item's stage is to what the vendor wants,
  // the better the odds.
  attemptTrade(tradeGoodName) {
    const offer = this.findBestTradeOffer();
    if (!offer) {
      EventConsole.emit("VENDOR", `Trade failed: ${tradeGoodName}`, "nothing to offer - craft something first", { tradeGood: tradeGoodName }, "state");
      return false;
    }

    const stageData = player.getCurrentStageData();
    const sweetSpotIndex = stageData ? player.currentStageIndex : offer.stageIndex;
    const sweetSpotPrice = pricing.npcBasePriceByStage[sweetSpotIndex] || 10;
    const offerValue = pricing.npcBasePriceByStage[offer.stageIndex] || 5;

    const acceptChance = pricing.calculateAcceptChance(offerValue, sweetSpotPrice);

    if (Math.random() < acceptChance) {
      player.inventory[offer.itemName] -= 1;
      player.addToInventory(tradeGoodName, 1);
      EventConsole.emit(
        "VENDOR", `Trade accepted: ${tradeGoodName}`, `gave ${offer.itemName}`,
        { gave: offer.itemName, received: tradeGoodName, acceptChance }, "decision"
      );
      return true;
    }

    EventConsole.emit(
      "VENDOR", `Trade rejected: ${tradeGoodName}`, `${offer.itemName} wasn't close enough to what's needed`,
      { offered: offer.itemName, acceptChance }, "decision"
    );
    return false;
  },
};
