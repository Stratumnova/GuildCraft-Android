const WorldRenderer={
  // Reusable Cibola market dressing keys. Kept explicit so asset audits can
  // verify the market never falls back to generic fantasy set dressing.
  DRESSING_KEYS:['districtSign','shadeTarp','marketBench','waterBarrel','novaWayfinder','marketLantern'],
  LOCAL_NPC_KEYS:['marketLocal1','marketLocal2','marketLocal3','marketLocal4'],
  id:'world',
  _staticActors:new Map(),
  stableActor(id,column,row,name=null,visualVariant=null){let a=this._staticActors.get(id);if(!a){a={id,gridColumn:column,gridRow:row,name,visualVariant};this._staticActors.set(id,a)}a.gridColumn=column;a.gridRow=row;a.name=name;a.visualVariant=visualVariant;return a},
  terrainKey(c,r){
    const h=(c*29+r*47+c*r)%31;
    if(MARKET_VISUAL_LAYOUT.isRoadCell(c,r))return'oldRoad';
    if(MARKET_VISUAL_LAYOUT.isGatheringSquare(c,r))return h%5===0?'marketPlate':'marketConcrete';
    if(MARKET_VISUAL_LAYOUT.isPlayerDistrict(c,r)||MARKET_VISUAL_LAYOUT.isCrafterLane(c,r))return h%4===0?'marketPlate':'packedDirt';
    if(MARKET_VISUAL_LAYOUT.isLoadingEdge(c,r))return h%3===0?'marketPlate':'packedDirt';
    if(MARKET_VISUAL_LAYOUT.isReserved(c,r))return h%5===0?'sageScrub':'dryGrass';
    if(c<5||r<4||c>59||r>59)return h%4===0?'sageScrub':'dryGrass';
    if(h%17===0)return'packedDirt';
    return'marketConcrete';
  },
  drawTerrain(ctx){
    const maxDepth=grid.columns+grid.rows-2;
    for(let depth=0;depth<=maxDepth;depth++)for(let r=0;r<grid.rows;r++){
      const c=depth-r;if(c<0||c>=grid.columns)continue;
      const p=grid.cellCenter(c,r),k=this.terrainKey(c,r),im=VisualRuntime.get('terrain',k);
      grid.iso.drawTile(ctx,im,p.x,p.y,{fallback:'#6e6855',stroke:MARKET_VISUAL_LAYOUT.isRoadCell(c,r)?'rgba(231,211,159,.15)':'rgba(244,221,158,.075)'})
    }
  },
  drawGroundMarkings(ctx){
    ctx.save();ctx.font='bold 13px ui-monospace,monospace';ctx.textAlign='center';
    const labels=[
      ['GATHERING SQUARE',MARKET_VISUAL_LAYOUT.anchors.marketCenter,'rgba(237,216,157,.42)'],
      ['PLAYER STALL',MARKET_VISUAL_LAYOUT.anchors.playerStallOperator,'rgba(237,200,105,.52)'],
      ['ADA · CRAFTER',MARKET_VISUAL_LAYOUT.anchors.crafterAda,'rgba(200,216,181,.46)']
    ];
    labels.forEach(([label,a,color])=>{const p=grid.cellCenter(a.column,a.row);ctx.fillStyle='rgba(15,14,11,.64)';ctx.fillRect(p.x-72,p.y+14,144,20);ctx.fillStyle=color;ctx.fillText(label,p.x,p.y+28)});
    ctx.restore();
  },
  npcKey(u){if(u.visualVariant&&this.LOCAL_NPC_KEYS.includes(u.visualVariant))return u.visualVariant;const n=String(u.name||'').toLowerCase();if(n.includes('kerr'))return'agitator';if(n.includes('mira'))return'liquidity';if(n.includes('rook'))return'wildRunner';return'generic'},
  drawNpc(ctx,u,key){
    const pp=ActorPresentation.projectedPoint(u,grid),p={x:pp.x,y:pp.y},pose=pp.pose;grid.iso.shadow(ctx,p.x,p.y,38*(pose.moving?.94:1),10,.30);VisualRuntime.spritePose(ctx,'npcs',key||this.npcKey(u),p.x,p.y+2,90,pose,1);
    if(pose.action)VisualRuntime.effect(ctx,pose.action,p.x+29,p.y-59,30,.72+.28*pose.actionStrength);
    if(u.name){ctx.save();ctx.font='bold 11px Georgia';ctx.textAlign='center';const w=96;ctx.fillStyle='rgba(16,16,13,.72)';ctx.fillRect(p.x-w/2,p.y-61+pose.bob,w,17);ctx.fillStyle='#f0e1b5';ctx.fillText(u.name,p.x,p.y-48+pose.bob);ctx.restore()}
  },
  drawProp(ctx,o){const p=grid.cellCenter(o.column,o.row),size=112*(o.scale||1);grid.iso.shadow(ctx,p.x,p.y,size*.48,12,.28);VisualRuntime.sprite(ctx,'props',o.kind,p.x,p.y+5,size,o.alpha??.98);if(o.kind==='districtSign'&&o.label){ctx.save();ctx.translate(p.x,p.y-size*.29);ctx.fillStyle='rgba(232,216,168,.92)';ctx.font=`bold ${Math.max(7,Math.round(size*.085))}px ui-monospace,monospace`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(o.label,0,0,size*.58);ctx.restore()}},
  drawDressing(ctx,o){this.drawProp(ctx,o)},
  drawStall(ctx,st,isPlayer=false){
    const p=grid.cellCenter(st.column,st.row),category=isPlayer?player.chosenCategory:st.categoryKey,key=MARKET_VISUAL_LAYOUT.stallAssetKey(category),size=isPlayer?126:122;
    grid.iso.shadow(ctx,p.x,p.y,size*.54,13,.30);VisualRuntime.sprite(ctx,'props',key,p.x,p.y+6,size,1);
  },
  drawPlayerFurniture(ctx,piece){
    const p=grid.cellCenter(piece.column,piece.row),storage=piece.type==='storageBoxOne'||piece.type==='storageBoxTwo';
    if(storage){grid.iso.shadow(ctx,p.x,p.y,36,9,.25);VisualRuntime.sprite(ctx,'props','supplyCrate',p.x,p.y+3,74,1);return}
    this.drawStall(ctx,{column:piece.column,row:piece.row},true)
  },
  depthOf(item){const p=grid.cellCenter(item.column,item.row);return p.y+Number(item.depthBias||0)},
  buildDepthQueue(){
    const queue=[];
    // visualProps are mapped world objects, including Nova remnants and loading-edge dressing.
    (MARKET_VISUAL_LAYOUT.visualProps||[]).forEach((o,i)=>queue.push({kind:'visualProps',column:o.column,row:o.row,depthBias:o.depthBias||0,order:i,draw:ctx=>this.drawProp(ctx,o)}));
    // marketDressing adds the human settlement layer without consuming future expansion plots.
    (MARKET_VISUAL_LAYOUT.marketDressing||[]).forEach((o,i)=>queue.push({kind:'marketDressing',column:o.column,row:o.row,depthBias:o.depthBias||2,order:50+i,draw:ctx=>this.drawDressing(ctx,o)}));
    // Permanent NPC vendor stalls.
    otherStalls.list.forEach((st,i)=>queue.push({kind:'otherStalls',column:st.column,row:st.row,depthBias:4,order:100+i,draw:ctx=>this.drawStall(ctx,st,false)}));
    // Each permanent stall has a mapped keeper behind the counter. They are
    // visual/economic residents, not cloned shoppers, and their cells are
    // blocked so foot traffic respects the stall workspace.
    (MARKET_VISUAL_LAYOUT.vendorKeepers||[]).forEach((v,i)=>queue.push({kind:'vendorKeeper',column:v.column,row:v.row,depthBias:7,order:150+i,draw:ctx=>this.drawNpc(ctx,this.stableActor(v.id,v.column,v.row,null,v.visualVariant),v.visualVariant)}));
    // Player furniture is its own physical footprint, not a UI-only abstraction.
    player.furniturePlacement.forEach((piece,i)=>queue.push({kind:'playerStall',column:piece.column,row:piece.row,depthBias:5,order:200+i,draw:ctx=>this.drawPlayerFurniture(ctx,piece)}));
    // Ambient market shoppers.
    npc.list.forEach((u,i)=>queue.push({kind:'npc',column:u.gridColumn,row:u.gridRow,depthBias:9,order:300+i,draw:ctx=>this.drawNpc(ctx,u)}));
    // Three special marketActors use mapped gathering-square stops when present.
    const marketActorsAnchors=MARKET_VISUAL_LAYOUT.anchors.marketActors||{};
    if(typeof marketActors!=='undefined'&&marketActors.state)Object.entries({agitator:'agitator',liquidity:'liquidity',wildRunner:'wildRunner'}).forEach(([id,key],i)=>{
      const state=marketActors.state[id],a=marketActorsAnchors[id];if(!state||state.present===false||!a)return;
      state.gridColumn=a.column;state.gridRow=a.row;queue.push({kind:'marketActors',column:a.column,row:a.row,depthBias:10,order:500+i,draw:ctx=>this.drawNpc(ctx,state,key)});
    });
    // Ada is physically separate from the player's stall.
    const crafterAda=MARKET_VISUAL_LAYOUT.anchors.crafterAda;
    crafterNpc.gridColumn=crafterAda.column;crafterNpc.gridRow=crafterAda.row;queue.push({kind:'crafterAda',column:crafterAda.column,row:crafterAda.row,depthBias:11,order:600,draw:ctx=>this.drawNpc(ctx,crafterNpc,'ada')});
    // Compatibility worker system currently draws nothing, but keep a hook for future seller sprites.
    if(worker?.list?.length)worker.list.forEach((w,i)=>queue.push({kind:'worker',column:w.gridColumn||19,row:w.gridRow||42,depthBias:10,order:650+i,draw:ctx=>this.drawNpc(ctx,w,'generic')}));
    queue.push({kind:'player',column:player.gridColumn,row:player.gridRow,depthBias:12,order:700,draw:ctx=>this.drawNpc(ctx,{gridColumn:player.gridColumn,gridRow:player.gridRow},'player')});
    return queue.sort((a,b)=>this.depthOf(a)-this.depthOf(b)||a.column-b.column||a.order-b.order);
  },
  drawSpeech(ctx){
    npc.list.forEach(u=>{if(!u.currentSpeech)return;const p=grid.cellCenter(u.gridColumn,u.gridRow),text=u.currentSpeech;ctx.save();ctx.font='14px Georgia';ctx.textAlign='center';const bw=Math.min(430,Math.max(150,ctx.measureText(text).width+26)),x=p.x,y=p.y-78;ctx.fillStyle='rgba(20,18,14,.92)';ctx.fillRect(x-bw/2,y-25,bw,31);ctx.strokeStyle='rgba(212,175,55,.7)';ctx.strokeRect(x-bw/2,y-25,bw,31);ctx.fillStyle='#eee5cf';ctx.fillText(text,x,y-5,bw-16);ctx.restore()})
  },
  drawTarget(ctx){if(player.targetColumn==null||player.targetRow==null)return;const p=grid.cellCenter(player.targetColumn,player.targetRow);ctx.save();ctx.strokeStyle='rgba(240,207,116,.84)';ctx.lineWidth=2;grid.iso.diamondPath(ctx,p.x,p.y);ctx.stroke();ctx.fillStyle='rgba(240,207,116,.10)';grid.iso.diamondPath(ctx,p.x,p.y);ctx.fill();ctx.restore()},
  drawGate(ctx){const g=MARKET_VISUAL_LAYOUT.anchors.wildRoadGate,p=grid.cellCenter(g.column,g.row);ctx.save();ctx.strokeStyle='rgba(224,192,107,.82)';ctx.lineWidth=3;ctx.setLineDash([8,6]);grid.iso.diamondPath(ctx,p.x,p.y);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='rgba(12,13,10,.84)';ctx.fillRect(p.x-82,p.y-66,164,22);ctx.fillStyle='#f0dfa5';ctx.font='bold 11px ui-monospace,monospace';ctx.textAlign='center';ctx.fillText('ROAD TO THE WILD',p.x,p.y-50);ctx.restore()},
  draw(ctx){
    CanvasRuntime.prepare(ctx);const w=CanvasRuntime.width(ctx.canvas),h=CanvasRuntime.height(ctx.canvas);ctx.clearRect(0,0,w,h);ctx.fillStyle='#1a1914';ctx.fillRect(0,0,w,h);
    camera.begin(ctx);this.drawTerrain(ctx);this.drawGroundMarkings(ctx);this.drawGate(ctx);this.buildDepthQueue().forEach(item=>item.draw(ctx));this.drawSpeech(ctx);this.drawTarget(ctx);camera.end(ctx);
    ctx.save();ctx.fillStyle='rgba(13,14,11,.78)';ctx.fillRect(14,h-58,186,42);ctx.fillStyle='#f0dfac';ctx.font='bold 18px Georgia';ctx.fillText(`Floppies ${player.floppyBalance||0}`,28,h-31);ctx.restore()
  }
};
