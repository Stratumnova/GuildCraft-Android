// pricing.js
// -----------------------------------------------------------------------------
// One shared pricing model used by both the display table (player selling)
// and vendor trades (player buying/bartering), so the same sweet-spot logic
// governs every transaction in the game.
//
// VALUE TIER RULE (Section 6 of the master doc): a player-made/gathered item
// is worth one tier below an NPC item of the same nominal stage.
// The "crossing window" is the price band between the NPC's lowest normal
// offer for that lower tier and the player's highest reasonable ask for
// their own item - trading inside that band is where a sharp player can
// out-earn the flat conversion rate. Numbers below are first-pass estimates,
// tune during playtesting (Section 13 of the master doc).
// -----------------------------------------------------------------------------

const pricing = {

  // Base NPC price by stage index (0 = stage 1 ... 5 = stage 6/mastery).
  npcBasePriceByStage: [5, 10, 18, 30, 50, 80],

  // The core anti-exploit sweet-spot model (Section 8): purchase/accept
  // chance falls off the further the asking price is from the sweet spot,
  // in either direction.
  calculateAcceptChance(askingPrice, sweetSpotPrice) {
    if (sweetSpotPrice <= 0) return 0;
    const distance = Math.abs(askingPrice - sweetSpotPrice);
    const chance = 1 - distance / sweetSpotPrice;
    return Math.max(0, Math.min(1, chance));
  },

  // Player-made items are valued at the NPC price of one stage lower.
  // Returns the floor (NPC's lowest normal offer), ceiling (player's
  // highest reasonable ask), and the sweet spot where they cross.
  getPlayerItemValueWindow(stageIndex) {
    const lowerTierIndex = Math.max(0, stageIndex - 1);
    const lowerTierPrice = this.npcBasePriceByStage[lowerTierIndex];
    return {
      floor: Math.round(lowerTierPrice * 0.7),
      ceiling: Math.round(lowerTierPrice * 1.3),
      sweetSpot: lowerTierPrice,
    };
  },

  // Flat sweet spot for reselling an unprocessed base material (Section 5:
  // "I should be able to place anything in my inventory there").
  rawMaterialSweetSpot: GCBalance.market.defaultRawSweetSpot,

  // One lookup that works for ANY inventory item - finished goods use the
  // tiered value-window sweet spot, anything else (raw materials) uses the
  // flat rate above. Items tagged " [NPC]" (commission.js) were crafted by
  // an NPC, not the player, so they price at the FULL NPC rate instead of
  // the discounted player-made rate - that's where a commissioned item's
  // resale margin comes from.
  getSweetSpotForItem(itemName) {
    const npcSuffix = " [NPC]";
    const isNpcMade = itemName.endsWith(npcSuffix);
    const baseName = isNpcMade ? itemName.slice(0, -npcSuffix.length) : itemName;

    const lookup = getFinishedItemLookup();
    const itemInfo = lookup[baseName];
    if (itemInfo) {
      return isNpcMade
        ? this.npcBasePriceByStage[itemInfo.stageIndex]
        : this.getPlayerItemValueWindow(itemInfo.stageIndex).sweetSpot;
    }
    return GCBalance.market.sellSweetSpot[baseName] ?? this.rawMaterialSweetSpot;
  },
};
