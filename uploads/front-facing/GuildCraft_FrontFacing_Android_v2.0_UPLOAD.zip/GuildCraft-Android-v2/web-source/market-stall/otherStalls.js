// otherStalls.js — background vendors sourced from the authoritative market layout map.
const otherStalls = {
  list: [],
  setup() {
    this.list = (MARKET_VISUAL_LAYOUT.stallPlots || []).map((plot, index) => {
      const aiStall = {
        id: plot.id || `stall_${index}`,
        categoryKey: plot.categoryKey || "food",
        district: plot.district || "vendorRows",
        facing: plot.facing || "south",
        column: plot.column,
        row: plot.row,
        frontageColumn: plot.frontageColumn,
        frontageRow: plot.frontageRow,
        slots: [null, null],
        restockTimer: 0,
      };
      this.restock(aiStall);
      return aiStall;
    });
  },
  restock(aiStall) {
    const categoryData = techTree[aiStall.categoryKey];
    if (!categoryData || !categoryData.paths) return;
    const pathKeys = Object.keys(categoryData.paths);
    const chosenPathKey = pathKeys[Math.floor(Math.random() * pathKeys.length)];
    const pathData = categoryData.paths[chosenPathKey];
    const maxStageToStock = Math.min(3, pathData.stages.length);
    const stageIndex = Math.floor(Math.random() * maxStageToStock);
    const stageData = pathData.stages[stageIndex];
    const itemData = stageData.items[Math.floor(Math.random() * stageData.items.length)];
    const sweetSpot = pricing.npcBasePriceByStage[stageIndex];
    for (let i = 0; i < aiStall.slots.length; i++) {
      if (!aiStall.slots[i]) { aiStall.slots[i] = { itemName: itemData.name, askingPrice: sweetSpot, sweetSpot }; break; }
    }
  },
  attemptPurchaseFromStall(aiStall) {
    const occupiedIndexes = aiStall.slots.map((slot,index)=>(slot?index:null)).filter(index=>index!==null);
    if (!occupiedIndexes.length) return false;
    const chosenIndex = occupiedIndexes[Math.floor(Math.random() * occupiedIndexes.length)];
    const slot = aiStall.slots[chosenIndex];
    if (Math.random() < pricing.calculateAcceptChance(slot.askingPrice, slot.sweetSpot)) { this.completeSale(aiStall, chosenIndex); return true; }
    return false;
  },
  completeSale(aiStall, slotIndex) {
    const slot = aiStall.slots[slotIndex]; if (!slot) return false;
    salesLog.logSale(aiStall.id, slot.itemName, slot.askingPrice); aiStall.slots[slotIndex]=null; aiStall.restockTimer=5; return true;
  },
  pickRandomOccupiedSlotIndex(aiStall) {
    const occupiedIndexes=aiStall.slots.map((slot,index)=>(slot?index:null)).filter(index=>index!==null);
    return occupiedIndexes.length?occupiedIndexes[Math.floor(Math.random()*occupiedIndexes.length)]:null;
  },
  update(deltaSeconds) {
    this.list.forEach(aiStall=>{ if(aiStall.restockTimer>0){ aiStall.restockTimer-=deltaSeconds; if(aiStall.restockTimer<=0)this.restock(aiStall); } });
  },
  draw(canvasContext) {
    this.list.forEach(aiStall=>stall.drawHalfBlockTable(canvasContext,aiStall.column,aiStall.row,stall.categoryColors[aiStall.categoryKey]||"#999"));
  },
};
