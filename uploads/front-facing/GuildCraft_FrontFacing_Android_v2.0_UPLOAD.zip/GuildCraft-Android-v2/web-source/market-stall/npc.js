// npc.js
// -----------------------------------------------------------------------------
// NPCs travel toward a chosen stall (the player's, or one of the mapped
// background stalls in otherStalls.js) and only attempt a purchase once
// they arrive. Each NPC also has a personality (npcPersonality.js) that
// biases their price tolerance, whether they haggle, and - for loyalists -
// which category they prefer to shop at.
//
// VISUAL LANGUAGE: NPCs render as circles colored to match whichever stall
// they're currently walking toward. A gold dot appears above their head at
// tier-3 interest (67%+ personal accept chance). Named NPCs (a small
// recurring roster) show their name as a small label above the dot.
// -----------------------------------------------------------------------------

const npc = {
  list: [],

  interestTierThresholds: { tier2: 0.34, tier3: 0.67 },

  spawnNpcs(count) {
    this.list = [];
    for (let i = 0; i < count; i++) {
      const npcUnit = {
        id: i < namedNpcRoster.length ? `named_${namedNpcRoster[i].name.toLowerCase().replace(/[^a-z0-9]+/g,"_")}` : `npc_${i}`,
        gridColumn: 0,
        gridRow: 0,
        secondsUntilNextMove: Math.random() * 2,
        secondsUntilNextBuyAttempt: 2 + Math.random() * 3,
        secondsAtStop: 0,
        interestChance: 0,
        targetStallId: null,
        targetColumn: 0,
        targetRow: 0,
      };
      { const spawn=(typeof marketFlow!=='undefined'?marketFlow.spawnPoint(npcUnit.id):grid.randomWalkable()); npcUnit.gridColumn=spawn.column; npcUnit.gridRow=spawn.row; }
      npcUnit.visualVariant=`marketLocal${1+((typeof marketFlow!=='undefined'?marketFlow.stableIndex(npcUnit.id,4):i%4))}`;
      npcPersonality.assignPersonality(npcUnit, i);
      if (typeof NpcSocial !== "undefined") NpcSocial.hydrate(npcUnit, i);
      if (typeof NpcPersistence !== "undefined" && npcUnit.name) {
        const savedSocial = NpcPersistence.load(typeof saveState !== "undefined" ? saveState.currentPlayerId : "player_1");
        NpcPersistence.apply(npcUnit, savedSocial[npcUnit.id]);
      }
      this.pickNewTarget(npcUnit);
      this.list.push(npcUnit);
    }
  },

  // Every stall on the map right now: the player's own, plus all 10
  // background stalls. Used for target picking and interest display.
  getAllStallTargets() {
    const targets = [];
    const playerSalesTable = player.furniturePlacement.find((f) => f.type === "salesTable");
    if (playerSalesTable && typeof marketBusiness!=='undefined' && marketBusiness.state.owned && marketBusiness.playerAtStall()) {
      const f=MARKET_VISUAL_LAYOUT.anchors.playerStallOperator; targets.push({ id: "player", column: f.column, row: f.row, frontageColumn:f.column, frontageRow:f.row, categoryKey: player.chosenCategory });
    }
    if (typeof otherStalls !== "undefined") {
      otherStalls.list.forEach((aiStall) => {
        targets.push({ id: aiStall.id, column: aiStall.frontageColumn, row: aiStall.frontageRow, frontageColumn:aiStall.frontageColumn, frontageRow:aiStall.frontageRow, categoryKey: aiStall.categoryKey });
      });
    }
    return targets;
  },

  // Every candidate stall gets a real score - personality-adjusted appeal
  // of its best occupied slot, plus a loyalist bonus for a matching
  // category - then DecisionEngine.weightedPick (GuildCraft toolkit) makes
  // the actual choice: the best-scoring stall is MOST likely, not
  // guaranteed, so an NPC's shopping still reads as a judgment call rather
  // than a lookup table. Replaces the old uniform-random-plus-loyalist-hack.
  pickNewTarget(npcUnit) {
    const targets = this.getAllStallTargets();
    if (targets.length === 0) return;

    const candidates = targets.map((target) => {
      let occupiedSlots;
      if (target.id === "player") {
        occupiedSlots = displayTable.getOccupiedSlotIndexes().map((i) => displayTable.slots[i]);
      } else {
        const aiStall = otherStalls.list.find((s) => s.id === target.id);
        occupiedSlots = aiStall ? aiStall.slots.filter((s) => s) : [];
      }

      let appeal = 0;
      occupiedSlots.forEach((slot) => {
        const personalSweetSpot = npcPersonality.getPersonalSweetSpot(npcUnit, slot.sweetSpot);
        appeal = Math.max(appeal, pricing.calculateAcceptChance(slot.askingPrice, personalSweetSpot));
      });

      let score = appeal;
      if (npcUnit.personalityKey === "loyalist" && npcUnit.preferredCategory && target.categoryKey === npcUnit.preferredCategory) {
        score += 0.5; // loyalists weight their preferred trade heavily regardless of what's currently on display
      }

      return { id: target.id, score, target };
    });

    const result = DecisionEngine.weightedPick(candidates.map((c) => ({ id: c.id, score: c.score })), 4.0);
    if (!result) return;

    const chosen = candidates.find((c) => c.id === result.chosen).target;
    npcUnit.targetStallId = chosen.id;
    const stop=(typeof marketFlow!=='undefined'?marketFlow.chooseStopForStall(chosen.id,npcUnit.id):null);
    npcUnit.targetColumn = stop?.column ?? chosen.column;
    npcUnit.targetRow = stop?.row ?? chosen.row;
    npcUnit.secondsAtStop=0;
    npcUnit.marketRoute=null;

    // Throttled: pickNewTarget fires every purchase cycle per NPC (up to a
    // dozen-plus NPCs), so this would flood the log unthrottled.
    EventConsole.emitThrottled(
      `npc-target-${npcUnit.id}`, 4000,
      "NPC_TARGETING", `${npcUnit.name || npcUnit.id} heading to ${chosen.id}`,
      DecisionEngine.describePick(result),
      { npc: npcUnit.name || npcUnit.id, personality: npcUnit.personalityKey, breakdown: result.breakdown },
      "decision"
    );
  },

  // Personality-adjusted interest in whatever stall this NPC is heading to.
  calculateInterestForNpc(npcUnit) {
    let occupiedSlots;
    if (npcUnit.targetStallId === "player") {
      occupiedSlots = displayTable.getOccupiedSlotIndexes().map((i) => displayTable.slots[i]);
    } else if (typeof otherStalls !== "undefined") {
      const aiStall = otherStalls.list.find((s) => s.id === npcUnit.targetStallId);
      occupiedSlots = aiStall ? aiStall.slots.filter((s) => s) : [];
    } else {
      occupiedSlots = [];
    }

    if (occupiedSlots.length === 0) return 0;
    return occupiedSlots.reduce((best, slot) => {
      const personalSweetSpot = npcPersonality.getPersonalSweetSpot(npcUnit, slot.sweetSpot);
      return Math.max(best, pricing.calculateAcceptChance(slot.askingPrice, personalSweetSpot));
    }, 0);
  },

  attemptPurchase(npcUnit) {
    if (!npcUnit.targetStallId) { this.pickNewTarget(npcUnit); return; }

    const distance = Math.max(
      Math.abs(npcUnit.gridColumn - npcUnit.targetColumn),
      Math.abs(npcUnit.gridRow - npcUnit.targetRow)
    );
    if (distance > 1) return; // still walking there, try again next cycle
    if ((npcUnit.secondsAtStop||0) < 0.75) return; // shoppers visibly pause before deciding

    if (npcUnit.targetStallId === "player") {
      const occupiedSlotIndexes = displayTable.getOccupiedSlotIndexes();
      if (occupiedSlotIndexes.length > 0) {
        const chosenIndex = occupiedSlotIndexes[Math.floor(Math.random() * occupiedSlotIndexes.length)];
        const slot = displayTable.slots[chosenIndex];
        let personalSweetSpot = npcPersonality.getPersonalSweetSpot(npcUnit, slot.sweetSpot);
        if(typeof marketActors!=='undefined')personalSweetSpot=marketActors.sellPressure(personalSweetSpot);
        let chance = pricing.calculateAcceptChance(slot.askingPrice, personalSweetSpot);
        chance = npcPersonality.attemptHaggleImprovedChance(npcUnit, chance);
        const bought = Math.random() < chance;
        if (bought) { displayTable.completeSale(chosenIndex); ActorPresentation.signal(npcUnit,'trade',.55); }
        if (typeof NpcSocial !== "undefined") NpcSocial.onPurchase(npcUnit, bought, slot.itemName, slot.askingPrice);
        EventConsole.emitThrottled(
          `npc-decision-${npcUnit.id}`, 1500, "NPC_PURCHASE",
          `${npcUnit.name || npcUnit.id} ${bought ? "bought" : "passed on"} ${slot.itemName}`,
          `${(chance * 100).toFixed(0)}% personal accept chance`,
          { npc: npcUnit.name || npcUnit.id, item: slot.itemName, price: slot.askingPrice, chance }, "decision"
        );
      }
    } else if (typeof otherStalls !== "undefined") {
      const aiStall = otherStalls.list.find((s) => s.id === npcUnit.targetStallId);
      if (aiStall) {
        const chosenIndex = otherStalls.pickRandomOccupiedSlotIndex(aiStall);
        if (chosenIndex !== null) {
          const slot = aiStall.slots[chosenIndex];
          const personalSweetSpot = npcPersonality.getPersonalSweetSpot(npcUnit, slot.sweetSpot);
          let chance = pricing.calculateAcceptChance(slot.askingPrice, personalSweetSpot);
          chance = npcPersonality.attemptHaggleImprovedChance(npcUnit, chance);
          if (Math.random() < chance) otherStalls.completeSale(aiStall, chosenIndex);
        }
      }
    }

    // Done browsing this stall either way - move on to a new one.
    npcUnit.secondsAtStop=0;
    this.pickNewTarget(npcUnit);
  },

  update(deltaSeconds) {
    if (typeof NpcSocial !== "undefined") NpcSocial.update(deltaSeconds);
    this.list.forEach((npcUnit) => {
      const distanceToStop=Math.max(Math.abs(npcUnit.gridColumn-npcUnit.targetColumn),Math.abs(npcUnit.gridRow-npcUnit.targetRow));
      if(distanceToStop<=1) npcUnit.secondsAtStop=(npcUnit.secondsAtStop||0)+deltaSeconds;
      else npcUnit.secondsAtStop=0;
      npcUnit.secondsUntilNextMove -= deltaSeconds;
      if (npcUnit.secondsUntilNextMove <= 0) {
        if(distanceToStop>1 || (npcUnit.secondsAtStop||0)>2.6) this.wanderStep(npcUnit);
        npcUnit.secondsUntilNextMove = 0.3 + Math.random() * 0.7;
      }

      npcUnit.interestChance = this.calculateInterestForNpc(npcUnit);

      const archetype = npcPersonality.getArchetype(npcUnit);
      const speedMultiplier = archetype.buyAttemptSpeedMultiplier || 1;
      npcUnit.secondsUntilNextBuyAttempt -= deltaSeconds * speedMultiplier;
      if (npcUnit.secondsUntilNextBuyAttempt <= 0) {
        this.attemptPurchase(npcUnit);
        npcUnit.secondsUntilNextBuyAttempt = 2 + Math.random() * 3;
      }
    });
  },

  // Routes shoppers through mapped market lanes and intersections. Occasional
  // detours choose another public flow node instead of stepping through future
  // expansion plots or cutting behind vendor footprints.
  wanderStep(npcUnit) {
    let goalColumn=npcUnit.targetColumn, goalRow=npcUnit.targetRow;
    if((Math.random()>=0.92||!npcUnit.targetStallId)&&typeof marketFlow!=='undefined'){
      const detour=marketFlow.ambientDestination(npcUnit.id);goalColumn=detour.column;goalRow=detour.row;
    }
    const step=(typeof marketFlow!=='undefined')
      ? marketFlow.nextStep(npcUnit,goalColumn,goalRow)
      : grid.nextWalkStep(npcUnit.gridColumn,npcUnit.gridRow,goalColumn,goalRow);
    const fromColumn=npcUnit.gridColumn,fromRow=npcUnit.gridRow;
    npcUnit.gridColumn=step.column;npcUnit.gridRow=step.row;
    if(fromColumn!==npcUnit.gridColumn||fromRow!==npcUnit.gridRow)ActorPresentation.move(npcUnit,fromColumn,fromRow,npcUnit.gridColumn,npcUnit.gridRow,.30);
  },

  getColorForNpc(npcUnit) {
    if (npcUnit.targetStallId === "player") return stall.getStallColor();
    if (typeof otherStalls === "undefined") return "#999999";
    const aiStall = otherStalls.list.find((s) => s.id === npcUnit.targetStallId);
    return aiStall ? (stall.categoryColors[aiStall.categoryKey] || "#999999") : "#999999";
  },

  draw(canvasContext) {
    this.list.forEach((npcUnit) => {
      const pixels = grid.cellToPixels(npcUnit.gridColumn, npcUnit.gridRow);
      const centerX = pixels.x + grid.cellSizePixels / 2;
      const centerY = pixels.y + grid.cellSizePixels / 2;
      const radius = grid.cellSizePixels / 2 - 3;

      canvasContext.fillStyle = this.getColorForNpc(npcUnit);
      canvasContext.beginPath();
      canvasContext.arc(centerX, centerY, radius, 0, Math.PI * 2);
      canvasContext.fill();

      if (npcUnit.interestChance >= this.interestTierThresholds.tier3) {
        canvasContext.fillStyle = "#d4af37";
        canvasContext.beginPath();
        canvasContext.arc(centerX, pixels.y - 2, 3, 0, Math.PI * 2);
        canvasContext.fill();
      }

      if (npcUnit.name) {
        canvasContext.fillStyle = "#e8e8e8";
        canvasContext.font = "12px Georgia";
        canvasContext.textAlign = "center";
        canvasContext.fillText(npcUnit.name, centerX, pixels.y - 8);
      }
    });
  },
};
