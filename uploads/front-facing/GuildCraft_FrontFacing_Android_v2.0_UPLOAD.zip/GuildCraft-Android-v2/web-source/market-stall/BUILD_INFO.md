# Market Stall Fieldworks v2.5

64×64 Cibola/Grants settlement market with lane-weighted crowd routing, mapped customer frontage, permanent stall keepers, reusable district dressing, expansion plots, Ada crafting, player stall economy, and Portal-owned player continuity.
