// accountMigration.js — shared Timesheet schema migration.
// Compatibility migration for pre-floppy currency saves. Current play uses floppy disks only.
const AccountMigration = {
  CURRENT_SCHEMA: 2,
  migrateTimesheet(account) {
    const next = { ...(account || {}) };
    if (!Number.isFinite(next.floppyBalance)) {
      next.floppyBalance = Number.isFinite(next.agagetBalance) ? next.agagetBalance : 0;
    }
    delete next.agagetBalance;
    next.currencySchema = this.CURRENT_SCHEMA;
    next.activeSaves = next.activeSaves || {};
    return next;
  },
  migrateMarketSave(save) {
    if (!save) return save;
    const next = { ...save };
    if (!Number.isFinite(next.floppyBalance)) {
      next.floppyBalance = Number.isFinite(next.stallLocalCurrency) ? next.stallLocalCurrency : 20;
    }
    delete next.stallLocalCurrency;
    next.marketSaveSchema = 2;
    return next;
  }
};
