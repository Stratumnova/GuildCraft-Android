// dialogueEngine.js — relationship + memory aware Market dialogue.
// Lines describe live simulation state only; they do not create new Stratumnova canon.
const DialogueEngine = {
  templates:{
    greeting:["{greeting}, {address}.","{filler}. Didn't expect to see you {place_clause}.","{greeting}. You holding up?"],
    trade:["I'll give you {offer} for {want}.","{want} for {offer}. Fair?","{filler}, I need {want}. I can trade {offer}."],
    refusal:["No. {reason_clause}.","{filler}, I can't do that. {reason_clause}.","Not happening. {boundary_clause}."]
  },
  voices:{
    old_neighbor:{fillers:["well","anyway"],greeting:"Morning",address:"neighbor",formal:false},
    hardcase:{fillers:["listen"],greeting:"Yeah",address:"trader",formal:false},
    plain_survivor:{fillers:["look","well"],greeting:"Hey",address:"friend",formal:false},
    nervous_scavenger:{fillers:["uh","maybe","look"],greeting:"Hey",address:"friend",formal:false},
    educated_medic:{fillers:["however"],greeting:"Good day",address:"merchant",formal:true}
  },
  pick(a){return a[Math.floor(Math.random()*a.length)]},
  profile(unit){return this.voices[unit.voice]||this.voices.plain_survivor},
  fill(t,v){return t.replace(/\{(\w+)\}/g,(_,k)=>v[k]??"")},
  recentMemory(unit,kind){const m=(unit.memoryRecords||[]).slice().reverse();return kind?m.find(x=>x.kind===kind):m[0]},
  greeting(unit){
    const v=this.profile(unit),r=NpcSocial.relationship(unit,"player"),last=this.recentMemory(unit);
    if(r.SUSPICION>=5)return `${v.greeting}. Keep your hands where I can see them.`;
    if(r.RESPECT>=6&&r.TRUST>=5)return v.formal?`${v.greeting}. Your word has held so far.`:`${v.greeting}. You deal straight. I remember that.`;
    if(last?.kind==='PURCHASE')return `${v.greeting}. Back after the ${last.itemName||'last deal'}?`;
    if(last?.kind==='PASS'&&r.NEED>=3)return `${v.greeting}. Still thinking about ${last.itemName||'that price'}?`;
    const place=r.TRUST>=3?"back here":"at this stall";
    return this.fill(this.pick(this.templates.greeting),{greeting:v.greeting,address:v.address,filler:this.pick(v.fillers),place_clause:place});
  },
  trade(unit,bought,itemName,price){
    const v=this.profile(unit),r=NpcSocial.relationship(unit,"player"),prior=this.recentMemory(unit,bought?'PURCHASE':'PASS');
    if(!bought){
      if(r.SUSPICION>=6)return `No. Not with you pushing it at ${price} floppies.`;
      const reason=r.NEED>3?`I need ${itemName}, just not at ${price} floppies`:`Not at ${price} floppies`;
      let line=this.fill(this.pick(this.templates.refusal),{filler:this.pick(v.fillers),reason_clause:reason,boundary_clause:"Try me another time"});
      if(prior?.itemName===itemName)line+=` Same answer as last time.`;
      return line;
    }
    let line=this.fill(this.pick(this.templates.trade),{filler:this.pick(v.fillers),want:itemName,offer:`${price} floppies`});
    if(r.RESPECT>=5)line+=v.formal?" Your terms have been reliable.":" You've earned a clean deal.";
    else if(r.TRUST>=4)line+=v.formal?" We have dealt well before.":" You deal straight.";
    return line;
  }
};
