// main.js
// -----------------------------------------------------------------------------
// Starts the game, runs the loop, and wires up the UI panels to the systems
// in the other files. This is the "glue" file - most real logic lives
// elsewhere (crafting.js, npc.js, specialization.js, etc).
// -----------------------------------------------------------------------------

const canvas = document.getElementById("gameCanvas");
const canvasContext = canvas.getContext("2d");

let lastFrameTimestamp = null;
let hudFeedbackAccumulator=0;
let wildGateArmed=true;
function resizeMarketCanvas(){CanvasRuntime.resize(canvas,camera)}
window.addEventListener('resize',resizeMarketCanvas);
window.visualViewport?.addEventListener('resize',resizeMarketCanvas);window.addEventListener('orientationchange',()=>setTimeout(resizeMarketCanvas,60));resizeMarketCanvas();
RoomShell.init({roomId:'market-stall',playerId:saveState?.currentPlayerId||'testPlayerOne',drawerId:'uiColumn',beforePortal:()=>{marketBusiness.markAway();syncMarketPortal();PortalRuntime.captureRoom(saveState.currentPlayerId,'market-stall','Fieldworks v2.5',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player));saveState.saveNow(player);if(typeof NpcPersistence!=='undefined')NpcPersistence.saveAll(saveState.currentPlayerId)}});
function marketGateDistance(){const g=MARKET_VISUAL_LAYOUT.anchors.wildRoadGate;return Math.max(Math.abs(player.gridColumn-g.column),Math.abs(player.gridRow-g.row))}
function checkWildRoadGate(){const g=MARKET_VISUAL_LAYOUT.anchors.wildRoadGate,d=marketGateDistance();if(d>g.radius+1){wildGateArmed=true;return}if(d<=g.radius&&wildGateArmed){wildGateArmed=false;player.targetColumn=null;player.targetRow=null;EventConsole.emit('ROOM','Wild road reached','Leaving Market for the Wild.',{},'state');enterWild()}}

// ---- Input: tap/click a grid cell to move toward it. Works for mouse
// (desktop) and touch (phone) with the same handler logic. ----

function setMoveTargetFromEvent(clientX, clientY) {
  MobileFeedback.pulse(clientX,clientY);
  const point = CanvasRuntime.point(canvas, clientX, clientY);
  const xInCanvas = point.x;
  const yInCanvas = point.y;

  const targetCell = camera.screenToWorldCell(xInCanvas, yInCanvas);
  const clamped = grid.closestWalkable(targetCell.column, targetCell.row);
  player.targetColumn = clamped.column;
  player.targetRow = clamped.row;
}

canvas.addEventListener("mousedown", (event) => {
  setMoveTargetFromEvent(event.clientX, event.clientY);
});

canvas.addEventListener("touchstart", (event) => {
  event.preventDefault();
  const touch = event.touches[0];
  setMoveTargetFromEvent(touch.clientX, touch.clientY);
}, { passive: false });

function handlePlayerMovement(deltaSeconds) {
  if (player.targetColumn === null || player.targetRow === null) return;
  if (player.targetColumn === player.gridColumn && player.targetRow === player.gridRow) {
    player.targetColumn = null;
    player.targetRow = null;
    return;
  }

  player.movementAccumulator = (player.movementAccumulator || 0) + deltaSeconds;
  const secondsPerStep = 1 / player.moveSpeedCellsPerSecond;

  if (player.movementAccumulator >= secondsPerStep) {
    player.movementAccumulator = 0;
    const fromColumn=player.gridColumn, fromRow=player.gridRow;
    const step = grid.nextWalkStep(player.gridColumn, player.gridRow, player.targetColumn, player.targetRow);
    if(step.column===player.gridColumn&&step.row===player.gridRow){ player.targetColumn=null; player.targetRow=null; return; }
    player.gridColumn = step.column;
    player.gridRow = step.row;
    ActorPresentation.move(player,fromColumn,fromRow,player.gridColumn,player.gridRow,secondsPerStep);
    checkWildRoadGate();
  }
}

// ---- Tabs ----

function switchTab(tabName) {
  document.getElementById("stallTab").style.display = tabName === "stall" ? "block" : "none";
  document.getElementById("storageTab").style.display = tabName === "storage" ? "block" : "none";
  document.getElementById("commissionTab").style.display = tabName === "commission" ? "block" : "none";
  document.getElementById("fieldworksTab").style.display = tabName === "fieldworks" ? "block" : "none";
  document.getElementById("requestsTab").style.display = tabName === "requests" ? "block" : "none";
  if(tabName === "requests") fieldQuestBoard.render();
  if(tabName === "fieldworks") portalFieldworks.render();
  document.getElementById("devLogTab").style.display = tabName === "devlog" ? "block" : "none";
  document.getElementById("peopleTab").style.display = tabName === "people" ? "block" : "none";
  document.getElementById("accountTab").style.display = tabName === "account" ? "block" : "none";
  if (tabName === "people") renderPeoplePanel();
  if (tabName === "account") playerCard.renderInto("playerCardPanel", saveState.currentPlayerId);
}

// ---- UI panel rendering ----

function renderClockPanel() {
  const panel = document.getElementById("clockPanel");
  panel.innerHTML = `<p><strong>${clock.getFormattedTime()}</strong></p>`;
}

function renderSpecializationPanel() {
  const panel = document.getElementById("specializationPanel");

  if (!player.chosenCategory) {
    const availableCategories = specialization.getAvailableCategories();
    panel.innerHTML = "<h3>Choose a Category</h3>" +
      availableCategories.map((categoryKey) =>
        `<button onclick="onChooseCategory('${categoryKey}')">${techTree[categoryKey].label}</button>`
      ).join("");
    return;
  }

  if (!player.chosenPath) {
    const categoryData = techTree[player.chosenCategory];
    if (categoryData.isCapstone) {
      panel.innerHTML = `<h3>${categoryData.label}</h3><p>All five trees unlocked for this run.</p>`;
      return;
    }
    const availablePathKeys = specialization.getAvailablePaths(player.chosenCategory);
    panel.innerHTML = `<h3>${categoryData.label} - Choose a Path</h3>` +
      availablePathKeys.map((pathKey) =>
        `<button onclick="onChoosePath('${pathKey}')">${categoryData.paths[pathKey].label}</button>`
      ).join("") +
      `<p><small>Choosing a path locks its opposed path, if any, for this save. Some paths (like a capstone) stay locked until you've made progress elsewhere.</small></p>`;
    return;
  }

  const stageData = player.getCurrentStageData();
  const itemButtons = stageData.items.map((item, itemIndex) => {
    const haveAll = player.hasComponents(item.components);
    const componentList = item.components.map((c) => `${c} (${player.inventory[c] || 0})`).join(", ");
    return `<p><strong>${item.name}</strong><br><small>${componentList}</small><br>
      <button ${haveAll ? "" : "disabled"} onclick="onAttemptCraft(${itemIndex})">Ask Ada to make ${item.name}</button></p>`;
  }).join("");

  // Switch-path section: other paths in this category the player could
  // hop to mid-run, each showing whatever progress they already have there.
  const categoryData = techTree[player.chosenCategory];
  const otherAvailablePaths = categoryData.isCapstone
    ? []
    : specialization.getAvailablePaths(player.chosenCategory).filter((k) => k !== player.chosenPath);
  const switchButtons = otherAvailablePaths.map((pathKey) => {
    const savedStage = player.getStageIndexForPath(pathKey);
    return `<button onclick="onSwitchPath('${pathKey}')">${categoryData.paths[pathKey].label} (stage ${savedStage + 1})</button>`;
  }).join("");

  panel.innerHTML = `
    <h3>${techTree[player.chosenCategory].label} - ${player.getCurrentPathData().label}</h3>
    <p>Stage ${player.currentStageIndex + 1}${stageData.isMasteryStage ? " (MASTERY STAGE)" : ""}</p>
    <p>Progress: ${player.craftsCompletedThisStage} / ${stageData.craftsToAdvance} completed orders (any of the 4 items below count)</p>
    ${itemButtons}
    ${switchButtons ? `<p><small>Switch path (keeps this path's progress):</small><br>${switchButtons}</p>` : ""}
    <button onclick="onRestartStall()">Restart with new category</button>
  `;
}

function renderStatusPanel() {
  const panel = document.getElementById("statusPanel");
  panel.innerHTML = `
    <p>Floppies: ${player.floppyBalance}</p>
    <p>Mastered categories: ${player.masteredCategories.length ? player.masteredCategories.join(", ") : "none yet"}</p>
    <p>Inventory: ${Object.entries(player.inventory).map(([name, count]) => `${name} x${count}`).join(", ") || "empty"}</p>
    <p>Stall seller: ${marketBusiness.state.hiredSeller?.name||"none"}</p>
    <p><small>Leave Market through the south road gate to return to The Wild.</small></p><p><button onclick="pauseGuildCraft()">Pause / Player Card</button></p>
  `;
}

function renderMaterialsPanel() {
  const panel = document.getElementById("materialsPanel");
  const stageData = player.getCurrentStageData();
  if (!stageData) { panel.innerHTML = ""; return; }

  // Union of components across all 4 items in this stage - buying/trading
  // is shared inventory, not tied to whichever item you end up crafting.
  const allComponents = [...new Set(stageData.items.flatMap((item) => item.components))];

  const rows = allComponents.map((componentName) => {
    const haveCount = player.inventory[componentName] || 0;
    const isTradeGood = componentName.startsWith("trade");

    if (isTradeGood) {
      return `<p>${componentName} (have ${haveCount})
        <button onclick="onAttemptTrade('${componentName}')">Trade for it</button></p>`;
    }
    return `<p>${componentName} (have ${haveCount}) - ${GCBalance.market.materialBuyCost(componentName)} floppies
      <button onclick="onBuyMaterial('${player.chosenCategory}', '${componentName}')">Buy</button></p>`;
  }).join("");

  panel.innerHTML = `<h3>Materials Needed (any of the 4 items)</h3>${rows}`;
}

function renderOtherVendorsPanel() {
  const panel = document.getElementById("otherVendorsPanel");
  if (!player.chosenCategory) { panel.innerHTML = ""; return; }

  const otherCategoryKeys = Object.keys(techTree).filter(
    (key) => key !== player.chosenCategory && !techTree[key].isCapstone
  );

  const sections = otherCategoryKeys.map((categoryKey) => {
    const categoryData = techTree[categoryKey];
    const unlocked = vendor.canBuyFrom(categoryKey);

    if (!unlocked) {
      return `<p><strong>${categoryData.label}</strong> - locked (recruit a worker to unlock)</p>`;
    }

    const materials = getBaseMaterialsForCategory(categoryKey);
    const buttons = materials.map((materialName) =>
      `<button onclick="onBuyMaterial('${categoryKey}', '${materialName}')">${materialName} (${GCBalance.market.materialBuyCost(materialName)})</button>`
    ).join("");
    return `<p><strong>${categoryData.label}</strong><br>${buttons}</p>`;
  }).join("");

  panel.innerHTML = `<h3>Other Vendors</h3>${sections}`;
}

// Display table: any inventory item can be placed (fix for "can only place
// current stage item"). Price input defaults to the real suggested sweet
// spot for whichever item is currently selected (fix for "nothing sells" -
// the old flat default of 10 was often way off the real sweet spot).
function renderDisplayPanel() {
  const panel = document.getElementById("displayPanel");

  const sellableItems = Object.keys(player.inventory).filter((name) => player.inventory[name] > 0);

  const slotRows = displayTable.slots.map((slot, index) => {
    if (slot) {
      return `<p>Slot ${index + 1}: ${slot.itemName} @ ${slot.askingPrice} (suggested ${slot.sweetSpot})
        <button onclick="onRemoveFromDisplay(${index})">Take back</button></p>`;
    }
    if (sellableItems.length === 0) {
      return `<p>Slot ${index + 1}: empty (nothing in inventory yet)</p>`;
    }
    const itemOptions = sellableItems.map((name) =>
      `<option value="${name}">${name} (have ${player.inventory[name]})</option>`
    ).join("");
    const firstItemSuggested = pricing.getSweetSpotForItem(sellableItems[0]);
    return `<p>Slot ${index + 1}: empty
      <select id="itemSelect${index}" onchange="onDisplayItemChanged(${index})">${itemOptions}</select>
      <input type="number" id="priceInput${index}" value="${firstItemSuggested}" min="1" style="width:50px">
      <button onclick="onPlaceOnDisplay(${index})">Place</button></p>`;
  }).join("");

  panel.innerHTML = `
    <h3>Display Table</h3>${slotRows}
    <button onclick="onExpandDisplaySlots()">Add another slot (${displayTable.expandSlotCost} floppies)</button>
  `;
}

function renderWorkerPanel() {
  const panel = document.getElementById("workerPanel"); if(!panel)return;
  panel.innerHTML = `<h3>Stall Seller</h3><p><small>Market workers do not gather Wild resources. After ${marketBusiness.hireSalesThreshold} stall sales you may hire a seller to operate your stall while you are elsewhere.</small></p><p>${marketBusiness.state.hiredSeller?`Hired: ${marketBusiness.state.hiredSeller.name}`:`Progress: ${marketBusiness.state.lifetimeSales}/${marketBusiness.hireSalesThreshold} sales`}</p>`;
}

// Carried inventory is Portal-owned and follows the player directly between rooms.

// Storage tab: every item in inventory, with sold count / average price
// stats and a one-click "Add to Table" that finds the next open slot.
function renderStoragePanel() {
  const panel = document.getElementById("storagePanel");
  const entries = Object.entries(player.inventory).filter(([, qty]) => qty > 0);

  if (entries.length === 0) {
    panel.innerHTML = "<h3>Storage</h3><p>Empty.</p>";
    return;
  }

  const rows = entries.map(([name, qty]) => {
    const stats = salesLog.getStatsForItem(name);
    const suggestedPrice = pricing.getSweetSpotForItem(name);
    return `<p><strong>${name}</strong> x${qty} - sold ${stats.totalSold}, avg price ${stats.averagePrice}
      <input type="number" id="storagePriceInput_${name}" value="${suggestedPrice}" min="1" style="width:50px">
      <button onclick="onAddToTableFromStorage('${name}')">Add to Table</button></p>`;
  }).join("");

  panel.innerHTML = `<h3>Storage</h3>${rows}`;
}

// Ledger tab: every notable event across the whole session - crafting,
// sales, vendor activity, drops/receipts, sealed traits, NPC decisions -
// via EventConsole (GuildCraft toolkit), not just sales. A checkbox row
// filters by purpose ("decision" vs "milestone" vs "state"), matching the
// toolkit's own demo.html pattern.
let ledgerPurposeFilter = null; // null = everything

function renderDevLogPanel() {
  const panel = document.getElementById("devLogPanel");
  const filterFn = ledgerPurposeFilter ? (e) => e.purpose === ledgerPurposeFilter : null;
  const entries = (filterFn ? EventConsole._history.filter(filterFn) : EventConsole._history).slice(-80).reverse();

  const purposeButtons = ["decision", "milestone", "state"].map((purpose) =>
    `<button onclick="onSetLedgerFilter(${ledgerPurposeFilter === purpose ? "null" : `'${purpose}'`})"
      style="opacity:${ledgerPurposeFilter === purpose || !ledgerPurposeFilter ? "1" : "0.5"}">${purpose}</button>`
  ).join("");

  const rows = entries.map((entry) => {
    let line = `<p><strong>[${entry.system}]</strong> ${entry.event}`;
    if (entry.reason) line += `<br><small>${entry.reason}</small>`;
    line += "</p>";
    return line;
  }).join("");

  panel.innerHTML = `
    <h3>Ledger</h3>
    <p><small>Filter by purpose:</small> ${purposeButtons}</p>
    ${rows || "<p>Nothing logged yet.</p>"}
  `;
}

function onSetLedgerFilter(purpose) {
  ledgerPurposeFilter = purpose;
  renderDevLogPanel();
}

// Commission tab: pick any category/path/stage and pay an NPC to craft one
// of that stage's 4 items for you, using materials you've already collected.
function renderCommissionPanel() {
  const panel = document.getElementById("commissionPanel");
  const categoryKeys = Object.keys(techTree).filter((key) => techTree[key].paths);
  const categoryOptions = categoryKeys.map((key) =>
    `<option value="${key}">${techTree[key].label}</option>`
  ).join("");

  panel.innerHTML = `
    <h3>Commission Crafting</h3>
    <p><small>Pay an NPC to craft something for you from materials you've collected. Doesn't count toward your own mastery progress.</small></p>
    <select id="commissionCategorySelect" onchange="onCommissionCategoryChanged()">${categoryOptions}</select>
    <div id="commissionPathRow"></div>
    <div id="commissionItemsRow"></div>
  `;
  onCommissionCategoryChanged();
}

function onCommissionCategoryChanged() {
  const categoryKey = document.getElementById("commissionCategorySelect").value;
  const categoryData = techTree[categoryKey];
  const pathKeys = Object.keys(categoryData.paths);
  const pathOptions = pathKeys.map((key) =>
    `<option value="${key}">${categoryData.paths[key].label}</option>`
  ).join("");

  const unlocked = commission.canCommissionFrom(categoryKey);
  const lockNote = unlocked ? "" : "<p><small>Locked - recruit a worker to unlock other vendors.</small></p>";

  document.getElementById("commissionPathRow").innerHTML = `
    ${lockNote}
    <select id="commissionPathSelect" onchange="renderCommissionItems()">${pathOptions}</select>
    <select id="commissionStageSelect" onchange="renderCommissionItems()">
      ${[0, 1, 2, 3, 4, 5].map((i) => `<option value="${i}">Stage ${i + 1}</option>`).join("")}
    </select>
  `;
  renderCommissionItems();
}

function renderCommissionItems() {
  const categoryKey = document.getElementById("commissionCategorySelect").value;
  const pathKey = document.getElementById("commissionPathSelect").value;
  const stageIndex = parseInt(document.getElementById("commissionStageSelect").value, 10);
  const stageData = techTree[categoryKey].paths[pathKey].stages[stageIndex];
  const fee = commission.getFee(stageIndex);
  const unlocked = commission.canCommissionFrom(categoryKey);

  const rows = stageData.items.map((item, itemIndex) => {
    const haveAll = player.hasComponents(item.components);
    const componentList = item.components.map((c) => `${c} (have ${player.inventory[c] || 0})`).join(", ");
    return `<p><strong>${item.name}</strong><br><small>${componentList}</small><br>
      <button ${(!unlocked || !haveAll) ? "disabled" : ""}
        onclick="onCommissionCraft('${categoryKey}','${pathKey}',${stageIndex},${itemIndex})">
        Commission (fee: ${fee})</button></p>`;
  }).join("");

  document.getElementById("commissionItemsRow").innerHTML = rows;
}

function onCommissionCraft(categoryKey, pathKey, stageIndex, itemIndex) {
  commission.craftForHire(categoryKey, pathKey, stageIndex, itemIndex);
  renderStatusPanel();
  renderCommissionItems();
  renderDisplayPanel();
  renderStoragePanel();
}

function renderPlayHud(){
  const g=MARKET_VISUAL_LAYOUT.anchors.wildRoadGate,d=marketGateDistance();
  document.getElementById('vitalsChip').textContent=`FLOPPIES ${player.floppyBalance} · TILL ${marketBusiness.state.till||0}`;
  document.getElementById('packChip').textContent=MobileFeedback.inventorySummary(player.inventory,3);
  const atStall=marketBusiness.playerAtStall();
  MobileFeedback.setPrompt(MobileFeedback.marketPrompt({nearExit:d<=g.radius+3,till:marketBusiness.state.till,atStall}),d<=g.radius+3?'route':'normal');
}
function renderAllPanels(){
  renderPlayHud();renderStatusPanel();renderSpecializationPanel();renderMaterialsPanel();renderOtherVendorsPanel();renderDisplayPanel();renderWorkerPanel();renderStoragePanel();
  marketBusiness.render();marketActors.render();portalFieldworks.render();
}
function syncMarketPortal(){PortalRuntime.syncFromRoom(saveState.currentPlayerId,'market-stall',player,{roomVersion:'Fieldworks v2.5',market:{stallOwned:marketBusiness.state.owned,stallTier:marketBusiness.state.tier,lifetimeSales:marketBusiness.state.lifetimeSales,hiredSeller:marketBusiness.state.hiredSeller}})}
function enterWild(){marketBusiness.markAway();syncMarketPortal();PortalRuntime.captureRoom(saveState.currentPlayerId,'market-stall','Fieldworks v2.5',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player));saveState.saveNow(player);RoomShell.go('../trapline/index.html','trapline','market-stall',saveState.currentPlayerId)}
function pauseGuildCraft(){syncMarketPortal();PortalRuntime.showPause(saveState.currentPlayerId)}

// ---- Button handlers ----

function onChooseCategory(categoryKey) {
  specialization.chooseCategory(categoryKey);
  renderSpecializationPanel();
}

function onChoosePath(pathKey) {
  specialization.choosePath(pathKey);
  renderSpecializationPanel();
  renderStatusPanel();
  renderMaterialsPanel();
  renderOtherVendorsPanel();
  renderDisplayPanel();
}

function onSwitchPath(pathKey) {
  specialization.switchPath(pathKey);
  renderSpecializationPanel();
  renderStatusPanel();
  renderMaterialsPanel();
  renderOtherVendorsPanel();
  renderDisplayPanel();
}

function onAttemptCraft(itemIndex) {
  ActorPresentation.signal(player,'craft',.8);
  const stage=player.getCurrentStageData(); const item=stage&&stage.items[itemIndex];
  if(!item)return false;
  if(!player.hasComponents(item.components))return false;
  item.components.forEach(c=>player.inventory[c]=Math.max(0,(player.inventory[c]||0)-1));
  const fee=GCBalance.market.stageCraftingFee(player.currentStageIndex);
  if(player.floppyBalance<fee){item.components.forEach(c=>player.addToInventory(c,1));return false}
  player.floppyBalance-=fee;player.addToInventory(item.name+' [NPC]',1);
  ActorPresentation.signal(crafterNpc,'craft',.9);
  EventConsole.emit('CRAFTER',`${crafterNpc.name} crafted ${item.name}`,`NPC service fee ${fee} floppy${fee===1?'':'s'}; player did not manufacture it`,{item:item.name,fee},'milestone');
  renderAllPanels();saveState.saveNow(player);return true;
}

function onBuyMaterial(vendorCategory, materialName) {
  vendor.buyMaterial(vendorCategory, materialName);
  renderStatusPanel();
  renderMaterialsPanel();
  renderOtherVendorsPanel();
}

function onAttemptTrade(tradeGoodName) {
  vendor.attemptTrade(tradeGoodName);
  renderStatusPanel();
  renderMaterialsPanel();
  renderOtherVendorsPanel();
}

function onDisplayItemChanged(slotIndex) {
  const itemSelect = document.getElementById(`itemSelect${slotIndex}`);
  const priceInput = document.getElementById(`priceInput${slotIndex}`);
  priceInput.value = pricing.getSweetSpotForItem(itemSelect.value);
}

function onPlaceOnDisplay(slotIndex) {
  const itemSelect = document.getElementById(`itemSelect${slotIndex}`);
  const priceInput = document.getElementById(`priceInput${slotIndex}`);
  const itemName = itemSelect.value;
  const askingPrice = parseInt(priceInput.value, 10) || 1;
  displayTable.placeItem(slotIndex, itemName, askingPrice);
  renderStatusPanel();
  renderDisplayPanel();
}

function onRemoveFromDisplay(slotIndex) {
  displayTable.removeItem(slotIndex);
  renderStatusPanel();
  renderDisplayPanel();
}

function onExpandDisplaySlots() {
  displayTable.expandSlots();
  renderStatusPanel();
  renderDisplayPanel();
}

function onAddToTableFromStorage(itemName) {
  const emptyIndex = displayTable.slots.findIndex((slot) => slot === null);
  if (emptyIndex === -1) {
    console.log("No empty display slot - buy another slot first.");
    return;
  }
  const priceInput = document.getElementById(`storagePriceInput_${itemName}`);
  const askingPrice = parseInt(priceInput.value, 10) || 1;
  displayTable.placeItem(emptyIndex, itemName, askingPrice);
  renderStatusPanel();
  renderStoragePanel();
  renderDisplayPanel();
}

function onSpawnWorker() {
  worker.spawnWorker();
  renderStatusPanel();
  renderWorkerPanel();
  renderOtherVendorsPanel();
}

function onRestartStall() {
  player.restartWithNewCategory();
  renderSpecializationPanel();
  renderStatusPanel();
  renderMaterialsPanel();
  renderOtherVendorsPanel();
  renderDisplayPanel();
  renderWorkerPanel();
}


function renderPeoplePanel() {
  const panel=document.getElementById("peoplePanel"); if(!panel || typeof npc==="undefined") return;
  panel.innerHTML = `<h3>Market People</h3><p><small>Recurring simulation actors. Relationship values and memories come from actual market interactions.</small></p>` + npc.list.map((u,i)=>{
    const r=NpcSocial.relationship(u,"player"); const last=(u.memoryRecords||[]).slice(-1)[0];
    return `<details><summary><strong>${u.name||u.id}</strong> — ${u.voice.replaceAll("_"," ")}</summary>`+
      `<p>Personality: ${u.personalityKey}<br>Target: ${u.targetStallId||"browsing"}<br>Goals: ${(u.goals||[]).join(", ")}</p>`+
      `<p>Like ${r.LIKE} · Trust ${r.TRUST} · Respect ${r.RESPECT} · Need ${r.NEED} · Suspicion ${r.SUSPICION}</p>`+
      `<p>Memory: ${last ? `${last.kind}${last.itemName?" — "+last.itemName:""}` : "none yet"}</p>`+
      `<button onclick="onTalkToNpc(${i})">Talk</button></details>`;
  }).join("");
}
function onTalkToNpc(index){ const u=npc.list[index]; if(!u)return; NpcSocial.say(u,DialogueEngine.greeting(u)); NpcSocial.remember(u,"PLAYER_GREETING",{}); if(typeof NpcPersistence!=="undefined") NpcPersistence.saveAll(saveState.currentPlayerId); renderPeoplePanel(); }

// ---- Game loop ----

function gameLoopTick(timestamp) {
  if (lastFrameTimestamp === null) lastFrameTimestamp = timestamp;
  const deltaSeconds = (timestamp - lastFrameTimestamp) / 1000;
  lastFrameTimestamp = timestamp;

  handlePlayerMovement(deltaSeconds);
  npc.update(deltaSeconds);
  worker.update(deltaSeconds);
  if(typeof marketActors!=="undefined")marketActors.update(deltaSeconds);
  if(typeof marketEconomy!=="undefined"&&Math.random()<.01)marketEconomy.tick();
  otherStalls.update(deltaSeconds);
  vendor.update(deltaSeconds);
  clock.update(deltaSeconds);
  hudFeedbackAccumulator+=deltaSeconds;if(hudFeedbackAccumulator>=.25){hudFeedbackAccumulator=0;renderPlayHud()}

  CanvasRuntime.prepare(canvasContext);
  canvasContext.clearRect(0, 0, CanvasRuntime.width(canvas), CanvasRuntime.height(canvas));
  camera.update();
  RendererManager.draw(canvasContext);

  requestAnimationFrame(gameLoopTick);
}

// ---- Startup ----

async function startGame() {
  RendererManager.init();
  const existingSave = await saveState.loadExistingSave();
  if (existingSave) {
    Object.assign(player, existingSave);
    if (existingSave.displaySlots) displayTable.slots = existingSave.displaySlots;
    console.log("Loaded existing save:", existingSave);
  } else {
    player.setupStartingFurniture();
  }
  MARKET_VISUAL_LAYOUT.migrateLegacyFurniture(player);
  if(!grid.isWalkable(player.gridColumn,player.gridRow)){const safe=grid.closestWalkable(player.gridColumn,player.gridRow);player.gridColumn=safe.column;player.gridRow=safe.row;}

  player.masteredCategories = await backendApi.getGameMasteredCategories(saveState.currentPlayerId);

  otherStalls.setup();
  npc.spawnNpcs(24); // expanded market: enough foot traffic for mapped vendor rows without crowding every lane
  PortalRuntime.bootstrap(saveState.currentPlayerId,{inventory:player.inventory,floppyBalance:player.floppyBalance});
  PortalRuntime.applyToRoom(saveState.currentPlayerId,player);
  {const ps=PortalRuntime.read(saveState.currentPlayerId);if(ps.session.previousRoom==='trapline'&&ps.session.currentRoom==='market-stall'){const a=MARKET_VISUAL_LAYOUT.anchors.wildRoadGate;player.gridColumn=a.arrivalColumn;player.gridRow=a.arrivalRow;player.targetColumn=null;player.targetRow=null;wildGateArmed=false;}}
  if(existingSave?.marketBusiness)marketBusiness.hydrate(existingSave.marketBusiness);
  if(existingSave?.marketActors)marketActors.hydrate(existingSave.marketActors);
  if(existingSave?.marketEconomy)marketEconomy.state=Object.assign(marketEconomy.state,existingSave.marketEconomy);
  renderSpecializationPanel();
  renderStatusPanel();
  renderMaterialsPanel();
  renderOtherVendorsPanel();
  renderDisplayPanel();
  renderWorkerPanel();
  renderStoragePanel();
  renderDevLogPanel();
  renderClockPanel();
  renderCommissionPanel();
  renderPeoplePanel();
  playerCard.renderInto("playerCardPanel", saveState.currentPlayerId);

  // Passive changes (sales, worker gathering, the clock) happen outside
  // button clicks, so refresh periodically. Skip re-rendering panels that
  // contain inputs while the player is actively typing/selecting in one -
  // this is what was causing the price box to reset while editing.
  // Also picks up new Trapline deliveries if that game is open in another tab.
  setInterval(() => {
    const activeTag = document.activeElement && document.activeElement.tagName;
    const isEditingSomething = activeTag === "INPUT" || activeTag === "SELECT";
    if (!isEditingSomething) {
      renderStatusPanel();
      renderDisplayPanel();
      renderStoragePanel();
          renderCommissionItems();
    }
    renderClockPanel();
    marketBusiness.render();marketActors.render();
    renderDevLogPanel();
    if(typeof NpcPersistence!=="undefined") NpcPersistence.saveAll(saveState.currentPlayerId);
  }, 1000);

  // Persist passive economy/simulation changes without saving every frame.
  setInterval(() => {syncMarketPortal();PortalRuntime.captureRoom(saveState.currentPlayerId,'market-stall','Fieldworks v2.5',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player));saveState.autosave(player)}, 10000);
  window.addEventListener("pagehide", () => {
    // localStorage-backed stub writes synchronously before the returned Promise resolves.
    syncMarketPortal();
    PortalRuntime.captureRoom(saveState.currentPlayerId,'market-stall','Fieldworks v2.5',saveState.buildSaveSnapshot(player),saveState.buildDisplaySummary(player));
    saveState.autosave(player);
    if(typeof NpcPersistence!=="undefined") NpcPersistence.saveAll(saveState.currentPlayerId);
  });

  resizeMarketCanvas();camera.snapToPlayer();
  requestAnimationFrame(gameLoopTick);
}

startGame();

// v0.7 controlled focus: mapped restore/focus state, never free dragging.
function toggleMarketFocus(){
  const stage=document.getElementById("marketStage");
  stage.classList.toggle("panelFocus");
  const b=document.getElementById("focusToggle"); if(b)b.textContent=stage.classList.contains("panelFocus")?"Restore":"Focus";
}
function renderFoundationQA(){
  if(typeof StateValidator==="undefined")return;
  const result=StateValidator.run(), panel=document.getElementById("devLogPanel"); if(!panel)return;
  const old=panel.querySelector(".qaBox"); if(old)old.remove();
  const box=document.createElement("div");box.className="qaBox";
  box.innerHTML=`<h3>Foundation QA ${result.ok?'<span class="qaPass">PASS</span>':'<span class="qaFail">FAIL</span>'}</h3>`+result.checks.map(c=>`<p class="${c.ok?'qaPass':'qaFail'}">${c.ok?'✓':'✕'} ${c.label}${c.detail?` <small>${c.detail}</small>`:''}</p>`).join("");
  panel.appendChild(box);
}
window.addEventListener("load",()=>setTimeout(renderFoundationQA,900));
