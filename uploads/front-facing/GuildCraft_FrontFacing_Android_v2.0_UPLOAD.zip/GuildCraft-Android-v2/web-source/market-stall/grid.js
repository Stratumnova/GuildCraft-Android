// grid.js — 64x64 market simulation grid with isometric presentation and mapped walkability.
const grid={
  columns:64,rows:64,cellSizePixels:60,
  iso:IsometricRuntime.make({columns:64,rows:64,tileWidth:84,tileHeight:42}),
  cellToPixels(column,row){const p=this.iso.center(column,row);return{x:p.x-30,y:p.y-43,cx:p.x,cy:p.y}},
  cellCenter(column,row){return this.iso.center(column,row)},
  pixelsToCell(x,y){const p=this.iso.toCell(x,y);return this.clampToGrid(p.column,p.row)},
  clampToGrid(column,row){return{column:Math.max(0,Math.min(this.columns-1,Math.round(column))),row:Math.max(0,Math.min(this.rows-1,Math.round(row)))}},
  inBounds(column,row){return column>=0&&row>=0&&column<this.columns&&row<this.rows},
  isWalkable(column,row){return this.inBounds(column,row)&&!(MARKET_VISUAL_LAYOUT?.isBlocked?.(column,row))},
  closestWalkable(column,row,maxRadius=8){
    const p=this.clampToGrid(column,row);if(this.isWalkable(p.column,p.row))return p;
    for(let radius=1;radius<=maxRadius;radius++){
      const cells=[];
      for(let dc=-radius;dc<=radius;dc++)for(let dr=-radius;dr<=radius;dr++)if(Math.max(Math.abs(dc),Math.abs(dr))===radius)cells.push({column:p.column+dc,row:p.row+dr});
      cells.sort((a,b)=>Math.hypot(a.column-column,a.row-row)-Math.hypot(b.column-column,b.row-row));
      const hit=cells.find(c=>this.isWalkable(c.column,c.row));if(hit)return this.clampToGrid(hit.column,hit.row);
    }
    return p;
  },
  randomWalkable(){for(let i=0;i<160;i++){const column=Math.floor(Math.random()*this.columns),row=Math.floor(Math.random()*this.rows);if(this.isWalkable(column,row))return{column,row}}return{column:32,row:32}},
  nextWalkStep(fromColumn,fromRow,toColumn,toRow){
    const dc=Math.sign(toColumn-fromColumn),dr=Math.sign(toRow-fromRow);
    const candidates=[
      {column:fromColumn+dc,row:fromRow+dr},
      {column:fromColumn+dc,row:fromRow},
      {column:fromColumn,row:fromRow+dr}
    ];
    const neighbors=[];for(let x=-1;x<=1;x++)for(let y=-1;y<=1;y++)if(x||y)neighbors.push({column:fromColumn+x,row:fromRow+y});
    neighbors.sort((a,b)=>Math.hypot(a.column-toColumn,a.row-toRow)-Math.hypot(b.column-toColumn,b.row-toRow));
    for(const c of [...candidates,...neighbors])if(this.isWalkable(c.column,c.row))return this.clampToGrid(c.column,c.row);
    return{column:fromColumn,row:fromRow};
  },
  worldSize(){return this.iso.worldSize()},
  draw(ctx){ctx.save();ctx.strokeStyle='rgba(94,112,89,.34)';ctx.lineWidth=1;for(let r=0;r<this.rows;r++)for(let c=0;c<this.columns;c++){const p=this.cellCenter(c,r);this.iso.diamondPath(ctx,p.x,p.y);ctx.stroke()}ctx.restore()}
};
