// marketFlow.js — shared pedestrian routing for the Cibola/Grants market room.
// The room simulation remains a 64x64 logical grid. This layer only changes
// how market actors choose routes: primary lanes and gathering areas are
// cheaper to traverse, while reservedExpansion plots are deliberately avoided
// so future districts stay open without becoming pedestrian shortcuts.
const marketFlow = {
  cache: new Map(),
  key(c,r){return `${c},${r}`},
  movementCost(c,r){
    if(!grid.isWalkable(c,r)) return Infinity;
    if(MARKET_VISUAL_LAYOUT.isReserved(c,r)) return 8;
    if(MARKET_VISUAL_LAYOUT.isRoadCell(c,r)) return .58;
    if(MARKET_VISUAL_LAYOUT.isGatheringSquare(c,r)) return .72;
    if(MARKET_VISUAL_LAYOUT.isCrafterLane(c,r)||MARKET_VISUAL_LAYOUT.isPlayerDistrict(c,r)) return .92;
    if(MARKET_VISUAL_LAYOUT.isLoadingEdge(c,r)) return 1.08;
    return 1.35;
  },
  heuristic(c,r,tc,tr){return Math.max(Math.abs(tc-c),Math.abs(tr-r))*.55},
  neighbors(c,r){
    const out=[];
    for(let dc=-1;dc<=1;dc++)for(let dr=-1;dr<=1;dr++){
      if(!dc&&!dr)continue;
      const nc=c+dc,nr=r+dr;if(!grid.inBounds(nc,nr)||!grid.isWalkable(nc,nr))continue;
      out.push({column:nc,row:nr,diag:dc!==0&&dr!==0});
    }
    return out;
  },
  findPath(sc,sr,tc,tr,maxVisited=2400){
    const start=grid.closestWalkable(sc,sr),target=grid.closestWalkable(tc,tr),targetKey=this.key(target.column,target.row);
    const open=[{column:start.column,row:start.row,g:0,f:this.heuristic(start.column,start.row,target.column,target.row)}];
    const best=new Map([[this.key(start.column,start.row),0]]),came=new Map();
    let visited=0;
    while(open.length&&visited++<maxVisited){
      open.sort((a,b)=>a.f-b.f);const cur=open.shift(),ck=this.key(cur.column,cur.row);
      if(ck===targetKey){
        const path=[];let k=ck,node={column:cur.column,row:cur.row};path.push(node);
        while(came.has(k)){node=came.get(k);k=this.key(node.column,node.row);path.push(node)}
        path.reverse();return path;
      }
      for(const n of this.neighbors(cur.column,cur.row)){
        const nk=this.key(n.column,n.row),step=this.movementCost(n.column,n.row)*(n.diag?1.16:1),ng=cur.g+step;
        if(ng>=(best.get(nk)??Infinity))continue;
        best.set(nk,ng);came.set(nk,{column:cur.column,row:cur.row});
        open.push({column:n.column,row:n.row,g:ng,f:ng+this.heuristic(n.column,n.row,target.column,target.row)});
      }
    }
    return [start,grid.nextWalkStep(start.column,start.row,target.column,target.row)];
  },
  cacheKey(unit,tc,tr){return `${unit.id||'u'}:${unit.gridColumn},${unit.gridRow}->${tc},${tr}`},
  nextStep(unit,tc,tr){
    const target=grid.closestWalkable(tc,tr),id=unit.id||'unit';
    const state=unit.marketRoute||{};
    const sameTarget=state.targetColumn===target.column&&state.targetRow===target.row;
    let path=sameTarget?state.path:null;
    if(!Array.isArray(path)||path.length<2||path[0].column!==unit.gridColumn||path[0].row!==unit.gridRow){
      path=this.findPath(unit.gridColumn,unit.gridRow,target.column,target.row);
    }
    if(path.length>1)path.shift();
    const step=path[0]||{column:unit.gridColumn,row:unit.gridRow};
    unit.marketRoute={targetColumn:target.column,targetRow:target.row,path:[{column:step.column,row:step.row},...path.slice(1)]};
    return step;
  },
  stableIndex(value,count){
    let h=2166136261;const s=String(value||'');for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}
    return Math.abs(h>>>0)%Math.max(1,count);
  },
  chooseStopForStall(stallId,npcId){
    const stops=MARKET_VISUAL_LAYOUT.customerStopsFor(stallId);
    if(!stops.length)return null;
    return stops[this.stableIndex(`${npcId}:${stallId}`,stops.length)];
  },
  spawnPoint(id){
    const nodes=(MARKET_VISUAL_LAYOUT.flowNodes||[]).filter(n=>['entry','lane','intersection'].includes(n.kind));
    const n=nodes[this.stableIndex(id,nodes.length)]||MARKET_VISUAL_LAYOUT.anchors.wildRoadGate;
    return grid.closestWalkable(n.column,n.row);
  },
  ambientDestination(id){
    const nodes=(MARKET_VISUAL_LAYOUT.flowNodes||[]).filter(n=>['square','intersection','district','lane','service'].includes(n.kind));
    const salt=`${id}:${Math.floor((clock?.totalGameMinutes||0)/20)}:${Math.random()}`;
    const n=nodes[this.stableIndex(salt,nodes.length)]||MARKET_VISUAL_LAYOUT.anchors.marketCenter;
    return grid.closestWalkable(n.column,n.row);
  }
};
