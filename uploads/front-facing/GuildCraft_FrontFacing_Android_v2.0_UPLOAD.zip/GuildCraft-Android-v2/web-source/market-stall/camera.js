const camera={
  viewportWidth:1280,viewportHeight:720,screenWidth:1280,screenHeight:720,zoom:1.04,x:0,y:0,smoothing:.16,
  worldWidth(){return grid.worldSize().width},worldHeight(){return grid.worldSize().height},
  resize(w,h){this.screenWidth=Math.max(320,Number(w)||1280);this.screenHeight=Math.max(240,Number(h)||720);const aspect=this.screenWidth/this.screenHeight;this.zoom=aspect>=1.55?1.18:1.04;this.viewportWidth=this.screenWidth/this.zoom;this.viewportHeight=this.screenHeight/this.zoom;this.snapToPlayer()},
  maxX(){return Math.max(0,this.worldWidth()-this.viewportWidth)},maxY(){return Math.max(0,this.worldHeight()-this.viewportHeight)},
  targetFor(c,r){const p=grid.cellCenter(c,r);return{x:Math.max(0,Math.min(this.maxX(),p.x-this.viewportWidth/2)),y:Math.max(0,Math.min(this.maxY(),p.y-this.viewportHeight/2))}},
  snapToPlayer(){const t=this.targetFor(player.gridColumn,player.gridRow);this.x=t.x;this.y=t.y},
  update(){const t=this.targetFor(player.gridColumn,player.gridRow);this.x+=(t.x-this.x)*this.smoothing;this.y+=(t.y-this.y)*this.smoothing},
  screenToWorldCell(x,y){return grid.pixelsToCell(x/this.zoom+this.x,y/this.zoom+this.y)},
  begin(ctx){ctx.save();ctx.scale(this.zoom,this.zoom);ctx.translate(-this.x,-this.y)},end(ctx){ctx.restore()}
};
