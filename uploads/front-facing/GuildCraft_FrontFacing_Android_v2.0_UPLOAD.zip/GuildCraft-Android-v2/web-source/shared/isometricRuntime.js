(function(global){
  function make(opts={}){
    const tileWidth=Number(opts.tileWidth||56),tileHeight=Number(opts.tileHeight||28),columns=Number(opts.columns||32),rows=Number(opts.rows||32);
    const originX=(rows-1)*tileWidth/2+tileWidth/2,originY=tileHeight/2;
    function center(column,row){return{x:(column-row)*tileWidth/2+originX,y:(column+row)*tileHeight/2+originY}}
    function topLeft(column,row){const p=center(column,row);return{x:p.x-tileWidth/2,y:p.y-tileHeight/2,cx:p.x,cy:p.y}}
    function worldSize(){return{width:(columns+rows)*tileWidth/2+tileWidth,height:(columns+rows)*tileHeight/2+tileHeight*4}}
    function toCell(x,y){
      const a=(x-originX)/(tileWidth/2),b=(y-originY)/(tileHeight/2);
      return{column:Math.floor((a+b)/2+.5),row:Math.floor((b-a)/2+.5)};
    }
    function diamondPath(ctx,cx,cy){ctx.beginPath();ctx.moveTo(cx,cy-tileHeight/2);ctx.lineTo(cx+tileWidth/2,cy);ctx.lineTo(cx,cy+tileHeight/2);ctx.lineTo(cx-tileWidth/2,cy);ctx.closePath()}
    function drawTile(ctx,image,cx,cy,opts2={}){
      const alpha=opts2.alpha==null?1:opts2.alpha;
      ctx.save();diamondPath(ctx,cx,cy);ctx.clip();ctx.globalAlpha=alpha;ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
      if(image&&image.complete&&image.naturalWidth)ctx.drawImage(image,cx-tileWidth/2,cy-tileHeight/2,tileWidth,tileHeight);
      else{ctx.fillStyle=opts2.fallback||'#756c4d';ctx.fillRect(cx-tileWidth/2,cy-tileHeight/2,tileWidth,tileHeight)}
      const grad=ctx.createLinearGradient(cx,cy-tileHeight/2,cx,cy+tileHeight/2);grad.addColorStop(0,'rgba(255,255,230,.08)');grad.addColorStop(1,'rgba(20,14,8,.12)');ctx.fillStyle=grad;ctx.fillRect(cx-tileWidth/2,cy-tileHeight/2,tileWidth,tileHeight);ctx.restore();
      ctx.save();diamondPath(ctx,cx,cy);ctx.strokeStyle=opts2.stroke||'rgba(239,222,163,.10)';ctx.lineWidth=1;ctx.stroke();ctx.restore();
    }
    function shadow(ctx,cx,cy,w=34,h=10,alpha=.28){ctx.save();ctx.fillStyle=`rgba(0,0,0,${alpha})`;ctx.beginPath();ctx.ellipse(cx,cy+tileHeight*.22,w/2,h/2,0,0,Math.PI*2);ctx.fill();ctx.restore()}
    return{tileWidth,tileHeight,columns,rows,originX,originY,center,topLeft,worldSize,toCell,diamondPath,drawTile,shadow};
  }
  global.IsometricRuntime={make};
})(window);
