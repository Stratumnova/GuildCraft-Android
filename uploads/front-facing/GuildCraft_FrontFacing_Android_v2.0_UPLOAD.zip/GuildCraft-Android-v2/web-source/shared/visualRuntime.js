(function(global){
  const cache=new Map();
  const prefixFromRoom=()=>location.pathname.includes('/portal/')?'../':location.pathname.includes('/trapline/')||location.pathname.includes('/market-stall/')?'../':'';
  const fallback={terrain:{},animals:{},npcs:{},props:{},fx:{}};
  function paths(){return global.GuildCraftBiomes?.current?.()||fallback}
  function src(group,key){return prefixFromRoom()+(paths()[group]?.[key]||'')}
  function get(group,key){const source=src(group,key),k=`${group}:${key}:${source}`;if(cache.has(k))return cache.get(k);const im=new Image();im.decoding='async';im.src=source;cache.set(k,im);return im}
  function draw(ctx,group,key,x,y,w,h,alpha=1){const im=get(group,key);if(!im.complete||!im.naturalWidth)return false;ctx.save();ctx.globalAlpha=alpha;ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(im,x,y,w,h);ctx.restore();return true}
  function sprite(ctx,group,key,cx,cy,size=72,alpha=1){const im=get(group,key);if(!im.complete||!im.naturalWidth)return false;ctx.save();ctx.globalAlpha=alpha;ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.shadowColor='rgba(0,0,0,.42)';ctx.shadowBlur=Math.max(2,size*.055);ctx.shadowOffsetY=Math.max(2,size*.045);ctx.drawImage(im,cx-size/2,cy-size*.78,size,size);ctx.restore();return true}

  function spritePose(ctx,group,key,cx,cy,size=72,pose={},alpha=1){
    const im=get(group,key);if(!im.complete||!im.naturalWidth)return false;
    const flip=pose.flipX?-1:1,bob=Number(pose.bob||0),squash=Number(pose.squash||1),lift=Number(pose.lift||0);
    ctx.save();ctx.translate(cx,cy+bob-lift);ctx.scale(flip,squash);ctx.globalAlpha=alpha;ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.shadowColor='rgba(0,0,0,.42)';ctx.shadowBlur=Math.max(2,size*.055);ctx.shadowOffsetY=Math.max(2,size*.045);ctx.drawImage(im,-size/2,-size*.78,size,size);ctx.restore();return true
  }
  function effect(ctx,key,cx,cy,size=34,alpha=1){return spritePose(ctx,'fx',key,cx,cy,size,{lift:0},alpha)}
  function preload(){const p=paths();Object.entries(p).forEach(([g,items])=>Object.keys(items||{}).forEach(k=>get(g,k)))}
  global.VisualRuntime={get paths(){return paths()},get,draw,sprite,spritePose,effect,preload,biome:()=>global.GuildCraftBiomes?.currentId?.()||null};
  preload();
})(window);
