(function(global){
  function inventorySummary(inv={},limit=4){
    const rows=Object.entries(inv).filter(([,v])=>Number(v)>0).map(([k,v])=>({k,label:k==='liveCottontail'?'Cottontail (live)':k,v:Number(v)}));
    rows.sort((a,b)=>(a.k==='liveCottontail'?-1:b.k==='liveCottontail'?1:a.label.localeCompare(b.label)));
    if(!rows.length)return 'Pack empty';
    const shown=rows.slice(0,limit).map(x=>`${x.label} ×${x.v}`).join(' · ');
    return shown+(rows.length>limit?` · +${rows.length-limit} more`:'');
  }
  function wildPrompt(s={}){
    if(Number.isFinite(s.gateDistance)&&Number.isFinite(s.gateRadius)){
      if(s.gateDistance<=s.gateRadius)return 'Cross Market Road → Market Stall';
      if(s.gateDistance<=s.gateRadius+3)return 'Market Road nearby';
    }
    if(s.nodeLabel)return `Gather ${s.nodeLabel}`;
    if(s.water)return 'Natural water · drink';
    if(s.nearbyAnimal)return `${s.nearbyAnimal} nearby`;
    return 'Tap the ground to move';
  }
  function marketPrompt(s={}){
    if(s.nearExit)return 'South road → The Wild';
    if((s.till||0)>0)return `Stall till: ${s.till} floppies waiting`;
    if(s.atStall)return 'Your stall · open TOOLS to trade';
    return 'Tap the market to move';
  }
  function setPrompt(text,tone='normal'){
    const el=document.getElementById('contextPrompt');if(!el)return;
    if(el.textContent!==text)el.textContent=text;
    el.dataset.tone=tone;
  }
  function pulse(x,y){
    const el=document.getElementById('touchPulse');if(!el)return;
    el.style.left=`${x}px`;el.style.top=`${y}px`;el.classList.remove('show');void el.offsetWidth;el.classList.add('show');
  }
  global.MobileFeedback={inventorySummary,wildPrompt,marketPrompt,setPrompt,pulse};
})(window);
