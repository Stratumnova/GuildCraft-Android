(function(global){
  function go(relative,roomId,fromRoom,playerId='testPlayerOne'){
    try{if(global.PortalRuntime&&roomId)PortalRuntime.transition(playerId,roomId,fromRoom)}catch{}
    if(global.parent&&global.parent!==global)return;
    setTimeout(()=>{global.location.href=relative},20);
  }
  async function toggleFullscreen(){
    try{
      if(!document.fullscreenElement){
        const el=document.documentElement;
        if(el.requestFullscreen)await el.requestFullscreen({navigationUI:'hide'});
        try{if(screen.orientation?.lock)await screen.orientation.lock('landscape')}catch{}
      }else if(document.exitFullscreen){await document.exitFullscreen()}
    }catch(err){console.info('Fullscreen request unavailable',err)}
  }
  function updateFullscreenButton(){
    const b=document.getElementById('roomFullscreenButton');
    if(!b)return;
    b.textContent=document.fullscreenElement?'EXIT':'FULL';
    b.setAttribute('aria-label',document.fullscreenElement?'Exit fullscreen':'Enter fullscreen');
  }
  function init(opts={}){
    const portalBtn=document.getElementById('roomPortalButton');
    const toolsBtn=document.getElementById('roomToolsButton');
    const fullBtn=document.getElementById('roomFullscreenButton');
    const drawer=document.getElementById(opts.drawerId||'uiColumn');
    if(portalBtn)portalBtn.addEventListener('click',()=>{
      try{opts.beforePortal?.()}catch(err){console.warn('Portal pre-save failed',err)}
      go('../portal/index.html','portal',opts.roomId,opts.playerId)
    });
    if(toolsBtn&&drawer){toolsBtn.addEventListener('click',()=>{const open=document.body.classList.toggle('toolsOpen');toolsBtn.setAttribute('aria-expanded',String(open))})}
    if(fullBtn)fullBtn.addEventListener('click',toggleFullscreen);
    const close=document.getElementById('roomToolsClose');if(close&&drawer)close.addEventListener('click',()=>{document.body.classList.remove('toolsOpen');toolsBtn?.setAttribute('aria-expanded','false')});
    document.addEventListener('fullscreenchange',updateFullscreenButton);
    global.addEventListener('message',event=>{
      if(event.data?.type!=='GC_ANDROID_BACK')return;
      if(document.body.classList.contains('toolsOpen')){
        document.body.classList.remove('toolsOpen');
        toolsBtn?.setAttribute('aria-expanded','false');
        global.parent?.postMessage({type:'GC_ANDROID_BACK_HANDLED'},'*');
        return;
      }
      try{opts.beforePortal?.()}catch(err){console.warn('Portal pre-save failed',err)}
      go('../portal/index.html','portal',opts.roomId,opts.playerId);
    });
    updateFullscreenButton();
  }
  global.RoomShell={init,go,toggleFullscreen};
})(window);
