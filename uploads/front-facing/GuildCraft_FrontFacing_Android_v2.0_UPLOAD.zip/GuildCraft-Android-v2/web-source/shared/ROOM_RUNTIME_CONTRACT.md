# GuildCraft Room Runtime Contract

Portal is the persistent outer shell and account authority. A room owns its local simulation and renderer, but consumes the Portal-owned Player Card.

## Required room surface

Each gameplay room provides:

- full usable viewport playfield;
- persistent `PORTAL`, room title, `FULL`, and `TOOLS` rail;
- a layout map for functional world anchors;
- simulation coordinates independent from visual theme;
- `PortalRuntime.syncFromRoom()` before room transition;
- room snapshot capture before returning to Portal;
- direct room-to-room transition through `RoomShell.go()`.

When a room runs inside Portal's `#roomHost`, `RoomShell.go()` records the transition and lets the parent Portal swap the persistent iframe. When a room is opened directly, the same call falls back to normal relative navigation.

## Rendering

`CanvasRuntime` keeps CSS viewport geometry separate from the HiDPI backing canvas. Cameras operate in CSS/world units. Renderers call `CanvasRuntime.prepare(ctx)` before drawing.

`VisualRuntime` resolves reusable PNG keys from `assets/cibola/`. Gameplay code should depend on semantic keys, not individual filenames.
