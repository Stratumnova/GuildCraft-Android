(function(global){
  const MAX_DPR=2.25;
  function viewport(){
    const vv=global.visualViewport;
    const width=Math.max(320,Math.floor(vv?.width||global.innerWidth||800));
    const height=Math.max(240,Math.floor(vv?.height||global.innerHeight||600));
    return {width,height};
  }
  function resize(canvas,camera){
    const {width,height}=viewport();
    const dpr=Math.max(1,Math.min(MAX_DPR,Number(global.devicePixelRatio)||1));
    const bw=Math.max(1,Math.round(width*dpr)), bh=Math.max(1,Math.round(height*dpr));
    if(canvas.width!==bw)canvas.width=bw;
    if(canvas.height!==bh)canvas.height=bh;
    canvas.style.width=width+'px';
    canvas.style.height=height+'px';
    canvas.dataset.cssWidth=String(width);
    canvas.dataset.cssHeight=String(height);
    canvas.dataset.dpr=String(dpr);
    if(camera?.resize)camera.resize(width,height);
    prepare(canvas.getContext('2d'));
    return {width,height,dpr};
  }
  function prepare(ctx){
    const canvas=ctx.canvas;
    const dpr=Math.max(1,Number(canvas.dataset.dpr)||1);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.imageSmoothingEnabled=true;
    ctx.imageSmoothingQuality='high';
  }
  function width(canvas){return Math.max(1,Number(canvas.dataset.cssWidth)||canvas.clientWidth||canvas.width)}
  function height(canvas){return Math.max(1,Number(canvas.dataset.cssHeight)||canvas.clientHeight||canvas.height)}
  function point(canvas,clientX,clientY){const r=canvas.getBoundingClientRect();return{x:clientX-r.left,y:clientY-r.top}}
  global.CanvasRuntime={resize,prepare,width,height,point,viewport};
})(window);
