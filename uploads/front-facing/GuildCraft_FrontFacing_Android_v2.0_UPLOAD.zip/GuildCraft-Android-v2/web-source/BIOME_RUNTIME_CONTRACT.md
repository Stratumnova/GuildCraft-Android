# GuildCraft Biome Runtime Contract

Each room declares a biome ID on the document root and may ship a `config/BIOME_PROFILE.json`. Shared gameplay systems do not depend on a biome name. `shared/biomeRegistry.js` resolves visual assets for the active room, while room layout maps decide where those assets belong.

Current profiles:
- `cibola-grants-wild` — Trapline / The Wild
- `cibola-grants-settlement` — Market Stall

Future rooms can register another pack without rewriting player, Portal, inventory, economy, save-card, or room-transition logic.
