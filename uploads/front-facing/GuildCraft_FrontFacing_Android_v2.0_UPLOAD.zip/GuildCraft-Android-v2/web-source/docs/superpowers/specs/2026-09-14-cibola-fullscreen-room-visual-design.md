# Cibola Fullscreen Room Visual Design

## Goal
Upgrade GuildCraft's Portal/Trapline/Market presentation into a reusable, polished room system while preserving the existing simulation and layout-map architecture.

## Approved direction
- Trapline and Market run as true full-screen room pages.
- A persistent PORTAL tab returns to the Portal page from every room.
- Portal launches rooms as top-level pages, not as the normal embedded gameplay surface.
- Trapline automatically transitions to Market Stall when the player walks into the Market Road gate.
- Market automatically transitions back to Trapline when the player walks out through its road gate.
- The room state remains continuous through PortalRuntime.
- The floor remains a logical grid in every room, but normal presentation uses subtle terrain seams instead of chunky/debug squares.
- Visual theme: Cibola County / Grants, New Mexico surface language (dry grass, sage, juniper/piñon, basalt, sandstone, old road/concrete) with restrained Stratumnova/Nova archaeology layered on top.
- Generated runtime PNG assets live in a reusable root `assets/cibola/` hierarchy and are addressed through an asset manifest.
- Layout maps remain the bridge between mechanics and visuals.
- Debug renderer remains available through the room tools drawer.
- GCPS1 remains importable. New exported memory cards use compact GCPS2 state and hide raw code by default in the mobile UI.

## Room shell
Each gameplay room owns the entire usable browser viewport. The world canvas fills the viewport. A small fixed room rail overlays the world with only PORTAL, TOOLS, and the room title. Existing detail panels move into a collapsible tools drawer rather than consuming permanent playfield width.

## Trapline gate
A canonical Market Road gate is stored in `TRAPLINE_VISUAL_LAYOUT_MAP.json`, not scattered in movement code. The gate sits on the south approach to Trail Camp. Transition is proximity based but armed only after the player has moved away from the arrival gate, preventing immediate bounce loops.

## Market gate
A corresponding road exit is stored in `MARKET_LAYOUT_MAP.json`. Market uses a player-follow camera rather than showing the entire 32x32 map at once. This keeps the player/world readable on Android landscape and gives the room the same spatial feel as Trapline.

## Visual assets
Root hierarchy:
- `assets/cibola/terrain/`
- `assets/cibola/animals/`
- `assets/cibola/npcs/`
- `assets/cibola/props/`
- `assets/cibola/ASSET_MANIFEST.json`

Assets are original reusable PNGs generated for this build. Rendering uses image smoothing and independent sprites for animals/NPCs rather than colored circles.

## Portable memory card
GCPS2 is a portable player snapshot, not a dump of every simulation detail. It carries player/account continuity and meaningful room deltas while omitting reconstructable ecology arrays, verbose Portal history, UI state, and uncollected stall till. The full local browser state remains unchanged. GCPS1 import remains available for legacy test cards.

## QA
Order: Portal -> Trapline -> Market Stall. Check JavaScript syntax, JSON/layout maps, local references, GCPS1/GCPS2 import/export compatibility, gate anti-bounce behavior, direct room navigation, asset references, and Android-sized viewport layout.
