# Market Expansion + Isometric Depth Design

## Goal
Expand Market Stall from 32×32 to a 64×64 isometric settlement market with realistic pedestrian circulation, permanent vendor rows, a player-stall district, Ada's crafter lane, a food court, loading edge, gathering square, and reserved expansion plots. Preserve Portal ownership, Wild↔Market continuity, player stall/till rules, roaming actors, and existing economy systems.

## Runtime contract
- Logical market grid is 64×64; presentation remains isometric.
- Layout data owns zones, stall plots, frontage cells, blocked cells, roads, entrances, and expansion plots.
- Player and NPC movement may use walkable cells only; stall/prop footprints are non-walkable.
- NPCs target stall frontage cells rather than stall footprint cells.
- Terrain and floor are rendered first; all tall props, stalls, NPCs, Ada, roaming actors, player, workers, and speech are depth sorted by isometric base-Y.
- Wild road gate is at south market boundary and remains the room transition to Trapline.
- Player stall is a permanent mapped district anchor; its furniture migrates from legacy positions into the new footprint without changing ownership/economy state.
- Reserved plots are intentionally unused and data-driven for later features.

## Visual structure
- Main south/north market spine, east/west cross-lanes, and a central open square.
- Vendor fronts face lanes; storage/loading stays behind vendor frontage.
- Ada has a dedicated east-side work lane.
- Player stall has customer frontage and rear storage.
- Food stalls cluster near the gathering square; material/service stalls line outer lanes.
- Perimeter props and restrained Nova remnants dress the space without blocking circulation.

## Compatibility
- Existing saves remain loadable. Legacy player furniture positions are migrated to the mapped player-stall footprint.
- Portal Player Card, GCPS1/GCPS2 import/export, till isolation, actor state, and economy state are unchanged.
