# Cibola Fullscreen Room Visual Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship Portal, Trapline, and Market as a polished full-screen connected room package with reusable Cibola/Nova PNG assets, data-driven road gates, and compact portable memory cards.

**Architecture:** Preserve existing simulation modules. Add one shared visual asset runtime and room-shell contract; move room-specific geometry into JSON layout maps. Portal remains the account/state authority while gameplay rooms navigate top-level and synchronize through PortalRuntime.

**Tech Stack:** HTML/CSS/vanilla JavaScript, Canvas 2D, localStorage/sessionStorage, JSON layout maps, PNG assets.

**Spec:** `docs/superpowers/specs/2026-09-14-cibola-fullscreen-room-visual-design.md`

## Global Constraints
- FUNCTION -> GRID -> ANCHORS -> COORDINATE MAP -> ARTWORK -> LIVE UI.
- No free dragging.
- Shared logic must remain theme-independent.
- Trapline is a resource/survival room, not a manufacturing room.
- Market manufacturing remains NPC-mediated through Ada.
- Uncollected stall till must remain excluded from portable Player Cards.
- Hidden Cottontail remains visually ordinary.

---

### Task 1: Reusable visual assets and manifest
**Files:** Create `assets/cibola/ASSET_MANIFEST.json`; create PNG files under `assets/cibola/{terrain,animals,npcs,props}/`; create `shared/visualRuntime.js`.
- [ ] Generate anti-aliased reusable PNG assets for Cibola terrain, ten animals, key Market NPCs, and Nova/market props.
- [ ] Write manifest paths and semantic keys.
- [ ] Add shared loader/drawing helpers with image smoothing.
- [ ] Validate every manifest path exists.

### Task 2: Full-screen room shell and navigation
**Files:** Modify `trapline/index.html`, `trapline/style.css`, `market-stall/index.html`, `market-stall/style.css`; create `shared/roomShell.js`.
- [ ] Add PORTAL/TOOLS room rail.
- [ ] Move existing UI into overlay drawers.
- [ ] Make canvas cover the usable viewport and resize on orientation/viewport changes.
- [ ] Preserve touch input and at least 44px controls.
- [ ] Verify standalone navigation to Portal works.

### Task 3: Trapline visual renderer and Market Road gate
**Files:** Create `trapline/TRAPLINE_VISUAL_LAYOUT_MAP.json`; modify `trapline/renderers/worldRenderer.js`, `trapline/animal.js`, `trapline/uniqueBlackRabbit.js`, `trapline/traders.js`, `trapline/main.js`, `trapline/camera.js`, `trapline/mapContent.js`.
- [ ] Store the Market Road gate and visual prop anchors in the layout map.
- [ ] Render smooth Cibola terrain PNGs and props while retaining the 192x192 simulation grid.
- [ ] Render each species from its own PNG; render hidden cottontail with the ordinary cottontail PNG.
- [ ] Render roaming traders as separate character sprites.
- [ ] Add armed proximity transition at Market Road with anti-bounce behavior.
- [ ] Remove obsolete delivery wording from player-facing Trapline UI.

### Task 4: Market camera, visual renderer, and Wild road gate
**Files:** Create `market-stall/MARKET_LAYOUT_MAP.json`, `market-stall/camera.js`; modify `market-stall/index.html`, `market-stall/main.js`, `market-stall/renderers/worldRenderer.js`, `market-stall/renderers/debugRenderer.js`.
- [ ] Add player-follow camera over the existing 32x32 simulation.
- [ ] Render Cibola settlement terrain and smooth reusable props.
- [ ] Render distinct Market NPC sprites and Ada at the crafter anchor.
- [ ] Add Wild road exit with anti-bounce behavior.
- [ ] Keep player stall and existing interaction mechanics intact.

### Task 5: Portal top-level launch and compact GCPS2
**Files:** Modify `portal/portal.js`, `portal/shared/portalRuntime.js`.
- [ ] Launch gameplay rooms as top-level pages.
- [ ] Add GCPS2 compact export that omits reconstructable population state/history/default noise and uncollected stall till.
- [ ] Keep GCPS1 importer.
- [ ] Hide raw code by default behind Show Code in the Memory Card overlay.
- [ ] Validate checksum and round-trip of GCPS2.

### Task 6: Ordered QA and packaging
**Files:** Create `VISUAL_FULLSCREEN_QA.md`, update `READY_TO_GO.md`.
- [ ] Run JS syntax checks.
- [ ] Parse all JSON/layout maps.
- [ ] Verify local HTML/CSS/script/image references.
- [ ] Run GCPS1 legacy import and GCPS2 round-trip tests.
- [ ] Run static gate/anti-bounce contract checks.
- [ ] Verify ZIP integrity and produce final archive.
