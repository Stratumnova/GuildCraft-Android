# Market Expansion Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a 64×64 structured isometric Market with real lanes, expansion plots, walkability and depth sorting.

**Architecture:** Layout data becomes the authority for Market geometry. Grid/pathing consumes layout walkability and the renderer creates one depth queue for all above-ground entities while terrain remains a base pass.

**Tech Stack:** HTML/CSS/JavaScript canvas, JSON layout maps, Python/Node verification.

**Spec:** `docs/superpowers/specs/2026-09-14-market-expansion-design.md`

## Global Constraints
- Keep Portal as player/account authority.
- Market remains a room of the same game session.
- Do not alter stall till isolation or portable-card rules.
- Preserve isometric grid presentation and mobile fullscreen room shell.
- No free dragging.

---

### Task 1: 64×64 market layout data
- [ ] Add failing structural tests for 64×64 geometry, zones, vendor plots, and expansion plots.
- [ ] Expand runtime and JSON layout maps.
- [ ] Update grid and state validation.
- [ ] Verify tests pass.

### Task 2: Walkability and stall frontage
- [ ] Add failing tests for blocked vendor footprints and walkable frontage/roads.
- [ ] Implement data-driven walkability and step selection.
- [ ] Update player and NPC movement to avoid stall footprints.
- [ ] Verify tests pass.

### Task 3: Real vendor distribution
- [ ] Add failing tests that other stalls originate from layout stall plots.
- [ ] Replace hard-coded 32×32 positions with mapped vendor plots.
- [ ] Target frontage cells for shoppers.
- [ ] Verify tests pass.

### Task 4: Isometric depth queue
- [ ] Add failing static/runtime tests for a unified depth queue.
- [ ] Render props, functional stalls, NPCs, market actors, Ada, worker and player in base-Y order.
- [ ] Render speech after world entities.
- [ ] Verify tests pass.

### Task 5: Compatibility and release package
- [ ] Migrate legacy player furniture positions to mapped stall district.
- [ ] Bump versions and docs.
- [ ] Run syntax/JSON/reference/layout/pathing/depth/ZIP integrity verification.
- [ ] Package the next ZIP.
