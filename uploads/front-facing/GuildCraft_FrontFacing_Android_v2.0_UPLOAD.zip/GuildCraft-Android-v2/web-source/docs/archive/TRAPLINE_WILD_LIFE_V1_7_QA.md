# Trapline Wild / Life Pass — Fullscreen Cibola v1.7

## Scope
This pass brings the Cibola County / Grants Wild closer to the populated Market presentation without changing its gameplay role. Trapline remains the resource/survival room and future rooms remain free to register different biome IDs.

## Changes
- Expanded mapped Wild dressing from 7 to 40 props around Trail Camp, creek country, wet ground, Reed Flats, North Rocks, Broken Array, Split Oak, South Service Scar and Market Road.
- Kept Stratumnova remains restrained: two terminals and one wayfinder across the 192x192 Wild dressing map.
- Added landmark dressing groups to the visual layout data so the art remains driven by the coordinate map.
- Added a unified isometric depth queue for mapped props, landmarks, active animals and the player.
- Active animals now use cell-center isometric anchors and ground shadows for cleaner separation.
- Preserved the hidden Cottontail visual contract, ecology/population authority, survival systems, Market Road transition and 192x192 simulation.

## Lore / biome boundary
Current room biome remains `cibola-grants-wild`: high desert, piñon-juniper / ponderosa edges, basalt/sandstone ground, old roads, and restrained Stratumnova remains. Biome data changes presentation/habitat dressing only; it does not own Portal account logic.

## Verification
- `tests/trapline_visual_v17.test.js` passes.
- All JavaScript syntax checks pass.
- All JSON parses.
- Existing Market expansion, Market flow and biome registry tests pass.
- Hidden Cottontail remains an ordinary `cottontail.png` visual.
- No normal Trapline manufacturing was reintroduced.
