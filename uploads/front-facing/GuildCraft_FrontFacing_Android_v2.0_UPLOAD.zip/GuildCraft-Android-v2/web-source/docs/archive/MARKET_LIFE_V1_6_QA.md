# Fullscreen Cibola v1.6 — Market Life / Biome Pass QA

## Build identity

- Portal: **R_D Portal v1.6**
- Trapline / The Wild: **Survival v1.9**
- Market Stall: **Fieldworks v1.9**
- Market simulation grid: **64×64**
- Current biome IDs:
  - `cibola-grants-wild`
  - `cibola-grants-settlement`

This pass intentionally skips Chromium/browser screenshot automation. Device/APK screenshots remain the visual acceptance evidence.

## What changed

### Real-market circulation

Market shoppers no longer use direct grid steering as their primary movement rule. `marketFlow.js` performs lane-weighted A* routing:

- central road and cross-lanes are preferred;
- the gathering square is a preferred public circulation area;
- crafter/player districts remain walkable but secondary;
- reserved expansion plots receive a strong routing penalty;
- mapped permanent objects and vendor workspaces remain blocked.

A runtime route from the south side to the north-west vendor front used 49 grid steps, with **92%** of the route on public lanes/gathering-space cells.

### Vendor frontage and dwell

- 24 permanent vendor plots remain mapped.
- Every permanent stall now has a mapped vendor keeper behind its counter.
- Every permanent vendor has two mapped customer stopping positions.
- The player stall has two customer positions that do **not** overlap the player's operating cell.
- Shoppers visibly dwell at a stall before making a purchase decision.

### Settlement dressing

The market layout map now owns reusable settlement dressing rather than scattering render positions through code:

- district signs;
- salvaged shade tarps;
- benches;
- water barrels;
- market lanterns;
- restrained Nova wayfinder;
- loading-edge crates/scrap;
- Cibola vegetation/rock edge dressing.

No permanent market dressing, stall, keeper, or customer stop occupies one of the eight reserved expansion plots.

### District organization

Vendor categories were regrouped to make the settlement read more like a functioning market:

- prepared-goods/food side;
- makers/crafter side;
- player-stall row;
- loading/service edge;
- north/south general vendor rows;
- central public gathering space.

Ada remains a service crafter rather than a player crafting bench. Trapline remains resource/survival only.

### NPC visual separation

Four reusable local-market NPC PNG variants were added. Recurring named actors keep their unique sprites. Permanent stall keepers and ambient shoppers therefore no longer all use a single identical generic sprite.

### Biome contract

`shared/biomeRegistry.js` now separates visual theme selection from room/game logic. The current Cibola pack is registered as both Wild and settlement variants. A future room can register an unrelated biome pack without rewriting Portal, player inventory, economy, save-card, or room-transition logic.

## Reusable PNG additions

Under `assets/cibola/`:

- `npcs/market_local_01.png`
- `npcs/market_local_02.png`
- `npcs/market_local_03.png`
- `npcs/market_local_04.png`
- `props/district_sign.png`
- `props/shade_tarp.png`
- `props/market_bench.png`
- `props/water_barrel.png`
- `props/market_lantern.png`
- `props/nova_wayfinder.png`

The hidden cottontail still uses the ordinary `animals/cottontail.png` asset.

## Fresh verification

- `tests/market_v16.test.js`: PASS
- `tests/market_flow_runtime.test.js`: PASS
- `tests/biome_registry.test.js`: PASS
- JavaScript syntax: 97 files checked, 0 failures
- JSON parse: 15 files checked, 0 failures
- HTML local references: 0 missing
- Cibola manifest assets: 52 paths checked, 0 missing
- Market layout collisions/reserved-plot violations: 0
- Hidden cottontail ordinary visual contract: PASS
- Trapline active HTML does not load the legacy Workshop path: PASS
- Biome registry loads before visual runtime in Wild and Market: PASS

### Routing performance proxy

240 fresh A* routes across the 64×64 market completed in ~865 ms in the local Node runtime (~3.6 ms per newly computed route). Paths are cached across movement steps, so this cost occurs when an NPC target changes rather than every frame.

## Intentional open testing decisions

- Market till remains browser/stall state until collected and remains excluded from portable Player Cards.
- Local room state vs imported portable snapshot precedence remains intentionally hybrid for live testing.
- Reserved expansion plots are intentionally empty until a later feature claims them.
- The dormant shared crafting engine remains unavailable to the player and reserved for a possible future Market crafting bench.
