# Fullscreen Cibola v1.4 — Isometric Presentation Pass

## Scope

No Chromium/browser screenshot gate is used in this pass. The change is focused on the next visual/mechanical layer: isometric/high-angle presentation while preserving the existing simulation grids and room mechanics.

## Portal

- Portal remains the persistent player/account/room bridge.
- Version bumped to v1.4 only to reflect the new room presentation contract.
- Room host/fullscreen behavior from v1.3 is unchanged.

## Trapline / The Wild

- Survival v1.9.
- Logical world remains 192x192.
- Rendering now projects cells to 56x28 isometric diamonds.
- Tap/click coordinates are inverse-projected back to the same integer simulation cells.
- Existing animals, resources, traders, drops, traps and hidden Cottontail continue using the same simulation positions.
- Terrain textures are clipped into high-angle diamond tiles rather than rendered as square blocks.
- Road, gate, vegetation, landmarks and Nova props are projected onto the same floor.
- Destination cell gets a subtle gold diamond highlight for touch feedback.

## Market Stall

- Fieldworks v1.7.
- Logical world remains 32x32.
- Market floor uses 84x42 isometric diamonds.
- Player movement and tap/click targeting use inverse isometric mapping.
- Stalls, Ada, roaming actors, NPCs, road gate and props use the same projection.
- Destination cell highlight added.

## Preserved contracts

- No Trapline crafting.
- Market crafting remains through Ada.
- Portal remains Player Card/save/room authority.
- Uncollected stall till remains browser-held and excluded from portable cards.
- Hidden Cottontail still uses the ordinary cottontail visual asset.
- Wild/Market physical road transitions are unchanged.
