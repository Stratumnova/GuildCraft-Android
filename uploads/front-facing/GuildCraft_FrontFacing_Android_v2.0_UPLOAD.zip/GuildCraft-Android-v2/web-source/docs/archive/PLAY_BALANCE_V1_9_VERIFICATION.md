# Play Balance v1.9 Verification

Fresh verification performed after the balance changes.

- 105 JavaScript files passed `node --check`.
- 15 JSON files parsed successfully.
- All Node test files passed, including the new play-balance contract and runtime tests.
- Market expansion Python suite passed 8/8 tests.
- HTML local references resolve and `shared/playBalance.js` loads before room systems that consume it.
- Version contract agrees: Portal v1.9 / Trapline Survival v2.3 / Market Fieldworks v2.2.
- Flat-price/service-fee drift checks passed: no stale `crafterNpc.serviceFee`, 12% seller cadence, or fixed 3-floppy Wild-runner price remains in active paths.
- Chromium/browser screenshot testing was intentionally not run for this stage, per project direction.

## Balance runtime evidence

- One 36-real-minute game day from full meters ends at approximately 76.24 food / 63.28 water without health loss.
- Natural creek water restores 45 water.
- Raw meat restores 10 food.
- Cooked meat restores 34 food and 4 health.
- Common and rare Market values differ (`wood=2`, `oldAlloy=12`, `rabbitPelt=3`, `wolfPelt=14`).
- Ada fees scale from 1 floppy on entry recipes to 4 on highest expedition recipes.
