# Fullscreen Cibola v1.3 — Build / QA Pass

## Portal

PASS (static/mechanical)

- Portal v1.4 remains the Player Card/account authority.
- Room launch no longer navigates the outer Portal document away.
- A persistent fullscreen `roomHost` keeps the Portal bridge alive while Trapline and Market swap inside one iframe.
- In-room `PORTAL` transitions return to the existing Portal session rather than loading a second Portal page inside the room.
- Maximize panels now use the actual viewport/safe area instead of the old 75% focus rectangle.
- Mobile Portal stage no longer forces a 1200 px minimum canvas.
- GCPS2 compact cards remain active; GCPS1 legacy import remains accepted.

## Trapline / The Wild

PASS (static/mechanical)

- Survival v1.9.
- HiDPI backing canvas added while simulation/camera coordinates stay in CSS/world units.
- Landscape visual zoom increases sprite/terrain readability without changing the 192×192 simulation grid.
- `PORTAL`, `FULL`, and `TOOLS` controls use safe-area-aware overlays.
- Returning to Portal commits clue eligibility, Player Card state, room snapshot and local save first.
- Market Road gate still transitions directly to Market Stall.
- Hidden Cottontail continues to use the normal cottontail asset.

## Market Stall

PASS (static/mechanical)

- Fieldworks v1.7.
- HiDPI canvas and modest landscape zoom added.
- Ada's mapped work area is now separate from the player's default stall location.
- Reusable `craft_bench.png` added to Ada's work zone.
- Returning to Portal saves Market/Player state first.
- Road to the Wild still transitions directly to Trapline.
- Player stall till behavior is unchanged: browser-held, stall-locked, non-portable until collected.

## Visual asset library

PASS

- 8 terrain textures rebuilt at 512×512.
- 10 animal PNGs rebuilt at 512×512.
- 6 player/NPC PNGs rebuilt at 512×512 with distinct silhouettes/gear.
- reusable Cibola/Nova props rebuilt at 512×512; craft bench added.
- asset manifest bumped to v2.

## Automated checks

- all JavaScript: `node --check` PASS
- all JSON: parse PASS
- HTML local references: PASS
- GCPS2 stress card with 2,000 ecology entries: 629 characters; round-trip PASS
- Market till absent after portable round-trip: PASS
- old Portal direct `window.location.href=room` launch path: absent
- persistent parent room transition bridge: present

## Browser rendering limitation

Local Chromium still hangs in this execution environment before producing a screenshot. Visual/API behavior therefore needs the next APK/device pass; no browser screenshot result is claimed.
