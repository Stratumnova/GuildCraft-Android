# Fullscreen Cibola v1.5 — Verification

Fresh verification performed after the Market expansion implementation.

## Versions
- Portal v1.5
- Trapline Survival v1.9
- Market Stall Fieldworks v1.8

## Market geometry
- Logical grid: 64×64.
- 24 active NPC vendor stalls, all sourced from `market-stall/MARKET_LAYOUT_MAP.json`.
- 8 reserved expansion plots with no active stall overlap.
- Separate player stall district and exact operator cell.
- Separate Ada crafter lane/workbench.
- Entrance road, central spine, three cross-lanes, gathering square, food court, loading edge and vendor rows are mapped as data.

## Movement
- Vendor footprints, player furniture, Ada/workbench and blocking props are non-walkable.
- Every NPC vendor frontage cell is walkable.
- Player tap targets are corrected to the nearest walkable cell.
- Player and NPC movement use the mapped walkability contract.

## Rendering
- Terrain remains an isometric base pass.
- Above-ground visual props, vendor stalls, player furniture, shoppers, the three market actors, Ada, workers and the player share one projected base-Y depth queue.
- Speech renders after world depth sorting.
- Five reusable category stall PNG variants were added to the Cibola asset library.

## Verification evidence
- Python expansion tests: 8/8 PASS.
- JavaScript syntax: 92 files PASS via `node --check`.
- JSON parse: 12 files PASS.
- HTML local references: PASS.
- Cibola VisualRuntime asset references: 41/41 exist.
- Layout invariants: 24 stalls, 40 blocked mapped cells, 8 reserved plots PASS.
- Isometric center round-trip: 1,500 randomized cells PASS.
- Runtime walkability/frontage path check: PASS.
- No Chromium/browser screenshot gate was used for this pass per project direction.
