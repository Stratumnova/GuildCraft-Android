# Fullscreen Cibola v1.5 — Market Expansion QA

## Scope
- Portal v1.5
- Trapline Survival v1.9 (unchanged mechanics)
- Market Fieldworks v1.8

## Market expansion
- 64×64 logical grid.
- 24 mapped NPC vendor stalls with customer frontage cells.
- Central north/south spine, three east/west cross lanes, gathering square, player stall district, Ada crafter lane, food court, loading edge, and eight reserved expansion plots.
- Player/NPC movement avoids stall and blocking-prop footprints.
- Player stall operation uses the exact mapped operator cell.
- Existing old furniture coordinates migrate into the new player-stall footprint.

## Rendering
- All above-ground market entities are sorted by projected isometric base-Y in one depth queue.
- Category-specific reusable stall PNGs were added to `assets/cibola/props/`.
- Terrain remains grid-authoritative and debug view remains available.

## Preserved contracts
- Portal still owns account/player shared state.
- Wild↔Market transition remains one continuous room session.
- Ada remains the active crafter.
- Trapline remains resource/survival only.
- Stall till remains browser-held and excluded from portable cards until collected.
- Black Cottontail visual/routing rules are unchanged.
