# GuildCraft Fullscreen / Cibola Visual Pass QA

Date: 2026-09-14

## Ordered pass

### 1. Portal
PASS (static/runtime contract)
- Portal v1.4 still owns player/account state.
- Room buttons now navigate to top-level full-screen room pages instead of using the Portal iframe as the normal gameplay surface.
- GCPS2 is the default portable card format.
- GCPS1 legacy import remains accepted.
- Mock snapshot containing 2,000 regional population entries exported to a 658-character GCPS2 code because reconstructable `populationState` and verbose history are omitted.
- GCPS2 import preserved browser-held `marketTill_testPlayerOne` and did not port the till into the Player Card.
- Raw card code is hidden behind `Show card code` by default.

### 2. Trapline / The Wild
PASS (static/runtime contract)
- Survival v1.9 uses a true viewport-filling canvas with Portal/Tools overlay rail.
- 192x192 logical grid and existing simulation are unchanged.
- New `TRAPLINE_VISUAL_LAYOUT_MAP.json` owns Market Road gate and visual anchors.
- Market Road proximity automatically enters Market Stall; direct menu teleport was removed from the Field Gear panel.
- Arrival/gate arming prevents immediate bounce-back.
- Cibola terrain PNGs replace flat color cells in the polished renderer.
- All ten animal species have separate PNG sprites.
- Hidden cottontail uses the ordinary cottontail PNG.
- Roaming traders use character sprites.
- Resource nodes use reusable vegetation/ore/scrap PNGs.
- Obsolete player-facing direct-delivery copy was removed.

### 3. Market Stall
PASS (static/runtime contract)
- Fieldworks v1.7 uses a true viewport-filling canvas and player-follow camera.
- New `MARKET_LAYOUT_MAP.json` owns Wild-road exit and key visual anchors.
- Walking into the south road gate returns to Trapline; the old direct Return-to-Wild button was removed.
- Existing economy, stall ownership, Ada crafting, roaming actors, and till behavior remain intact.
- Market renderer uses Cibola settlement floor textures, reusable stalls/props, separate player/NPC sprites, and a visible Ada crafter sprite.

## Mechanical/static checks
PASS
- All JavaScript files: `node --check`.
- All JSON files parse.
- HTML local script/link/image references resolve.
- Every `ASSET_MANIFEST.json` PNG exists.
- GCPS2 round-trip passes.
- GCPS1 legacy import passes.
- Browser-held till remains outside portable snapshots and survives card import in the runtime test.
- Layout maps contain explicit road gates and arrival anchors.

## Environment limitation
Visual browser screenshot automation was attempted with local Chromium, but Chromium does not terminate correctly in this execution environment (DBus/headless process hang). No Android emulator target is connected (`adb devices` returns none). Therefore this report does not claim automated APK screenshot QA. The user's real-device APK screenshots remain the current visual evidence source.
