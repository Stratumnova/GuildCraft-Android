# GuildCraft Character / Animal Presentation v1.8 QA

## Scope

This pass keeps the existing Portal → Wild → Market architecture and adds a shared presentation layer over the authoritative grid simulation.

### Shared runtime
- `shared/actorPresentation.js` owns presentation-only state: interpolated step movement, directional facing, idle/movement bob, temporary action states, and projected screen position.
- `shared/visualRuntime.js` now supports pose-aware sprite drawing and reusable feedback FX.
- Presentation state is deliberately excluded from saves and GCPS2 cards.

### Trapline / The Wild — Survival v2.1
- Player movement is smoothly interpolated between grid cells without changing grid authority.
- Active animals interpolate their existing ecology-driven movement and flip by travel direction.
- Flee behavior receives a faster visual step without changing simulation decisions.
- Predator attacks signal both predator action and player damage feedback.
- Gather, hunt/capture, trap, trader, eating, drinking and processing actions emit short presentation feedback.
- The three roaming traders now use distinct existing Cibola character variants rather than one repeated generic sprite.
- The hidden Cottontail still renders with the ordinary `rabbit` / `cottontail.png` asset and receives no unique visual marker.

### Market — Fieldworks v2.0
- Player and shopper movement use the same interpolated presentation layer.
- Shopper purchase success generates a short trade state.
- Permanent keepers have stable persistent presentation identities so idle motion does not jitter frame-to-frame.
- Kerr Voss, Mira Quill, Rook Fen and Ada use persistent actor state.
- Ada's crafting and material-sourcing service produces visible craft/trade feedback.
- Player-operated stall sales can signal trade feedback while the player is physically at the stall.

### Reusable assets
New transparent PNGs live under `assets/cibola/fx/`:
- `gather.png`
- `hunt.png`
- `craft.png`
- `trade.png`
- `hurt.png`
- `eat.png`
- `drink.png`
- `trap.png`

They are registered in the Cibola biome pack and can be replaced independently later.

## Preserved contracts
- Layout maps and integer simulation coordinates remain authoritative.
- No player crafting was enabled in Trapline.
- Ada remains the current visible Market manufacturing path.
- Hidden Cottontail appearance remains ordinary.
- Market stall till remains excluded from portable GCPS2 cards until physically collected.
- Future biome packs can replace terrain, character, animal and FX art without changing gameplay logic.

## Fresh verification evidence

Executed after implementation:

- `node tests/actor_presentation.test.js` — PASS
- `node tests/presentation_integration.test.js` — PASS
- `node tests/presentation_assets.test.js` — PASS
- `node tests/biome_registry.test.js` — PASS
- `node tests/trapline_visual_v17.test.js` — PASS
- `node tests/market_flow_runtime.test.js` — PASS; 49-step route, 0.92 lane share
- `node tests/market_v16.test.js` — PASS
- `python -m unittest tests/test_market_expansion.py` — 8/8 PASS
- `node --check` across all JavaScript — 102 files PASS
- JSON parse — 15 files PASS
- local HTML reference audit — PASS
- hidden Cottontail ordinary visual contract — PASS
- version consistency — Portal v1.8 / Survival v2.1 / Fieldworks v2.0 PASS
- presentation state save isolation — PASS

Chromium was intentionally not attempted in this pass per the project testing decision; APK/device screenshots remain the rendered visual authority.
