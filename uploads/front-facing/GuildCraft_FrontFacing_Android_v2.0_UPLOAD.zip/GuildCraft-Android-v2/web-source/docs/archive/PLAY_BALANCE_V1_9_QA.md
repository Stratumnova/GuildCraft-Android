# GuildCraft Play Balance v1.9 QA

## Scope

This pass prepares the current Cibola room set for a proper end-to-end playthrough without changing the established room roles or lore.

- Portal v1.9 remains player/account and room-bridge authority.
- Trapline Survival v2.3 remains the Cibola/Grants Wild resource/survival room.
- Market Stall Fieldworks v2.2 remains the settlement economy/manufacturing room with Ada as the visible crafter.
- The hidden Cottontail, stall till, GCPS2, biome registry and Wild ↔ Market continuity contracts are unchanged.

## Shared balance profile

`shared/playBalance.js` now owns tunable cross-room values instead of leaving important numbers scattered through multiple scripts.

### Survival targets

A 36-real-minute game day from full condition now consumes approximately:

- 23.76 food
- 36.72 water

This keeps survival relevant while allowing a new player to explore, gather and reach Market without the meters becoming the dominant first-session mechanic.

- raw meat: +10 food
- cooked meat: +34 food and +4 health
- natural water: +45 water
- field tonic: +30 health and +8 water
- sleep: +35 health, -8 food, -10 water

### Threat pacing

- wolf base damage: 10
- boar base damage: 7
- night hostile multiplier: 1.2
- hostile attack cadence: 2.25 seconds
- lit-campfire safe radius: 5 cells

The goal is danger with enough reaction time to move, fight or reach fire rather than near-instant chain damage.

### Hunting / trapping

Weapon family progression remains ordered:

- spear base: 58%
- bow base: 68%
- gun base: 78%
- each weapon tier: +10 percentage points before species difficulty

Trap checks remain limited to once per in-game hour. Bait provides a +16-point attraction bonus and catch chance is capped at 92%.

### Market value differentiation

Raw field goods no longer all collapse to a 3-floppy sweet spot. Common materials remain cheap while dangerous/rare Wild outputs carry meaningful value. Examples:

- wood: 2
- iron ore: 4
- copper ore: 6
- old-world alloy: 12
- rabbit pelt: 3
- deer pelt: 8
- wolf pelt: 14

Market-sourced materials use the same value table with a 1.4× purchasing markup, before Kerr Voss's price pressure.

### Ada service fees

Ada remains intentionally accessible for early equipment, but advanced work now has a higher labor fee.

- entry recipes: generally 1 floppy
- middle field gear: 2–3 floppies
- highest expedition gear: up to 4 floppies

The older specialization/commission path also uses a stage-scaled Ada fee rather than the removed flat `serviceFee` field.

### Player stall / market actors

The player-stall ownership thresholds remain established:

- stall purchase: 30 floppies
- hire seller: 12 completed sales + 25 floppies

Background sales are slower so a hired seller helps without instantly clearing a display:

- active background sale attempt: 4% per market actor update
- catch-up interval: one turn per 2 real minutes, capped at 12 turns
- Mira Quill foreground liquidity purchase chance: 3% per update

Rook Fen now prices returned Wild materials according to their field value instead of selling every material for the same 3 floppies.

## Verification targets

- one-day survival budget remains playable
- cooked food materially outperforms raw food
- hostile damage leaves reaction time
- weapon progression is monotonic
- rare goods are worth more than common goods
- advanced Ada work costs more than entry work
- seller/liquidity cadence cannot clear stock every few seconds
- current room/version/save contracts remain intact
