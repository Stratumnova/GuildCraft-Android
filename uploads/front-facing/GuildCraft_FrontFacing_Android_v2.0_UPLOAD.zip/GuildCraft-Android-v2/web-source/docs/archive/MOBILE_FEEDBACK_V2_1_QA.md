# Mobile / Player Feedback v2.1 QA

Scope: low-chrome HUD and interaction feedback for the connected Cibola rooms.

- Persistent playfield HUD is limited to two compact top-left chips: survival/currency and a short pack summary.
- Context prompt is transient-state driven and remains at the bottom edge, leaving the center/lower-middle playfield clear.
- Wild route cue changes to `Market Road nearby` before the crossing and `Cross Market Road → Market Stall` at the gate.
- Market route cue identifies the south road back to The Wild.
- Gatherable nodes, natural water, nearby wildlife, player stall, and uncollected till can surface contextual text without opening TOOLS.
- Touch/click movement now emits a short ground pulse at the input point.
- TOOLS remains the disclosure surface for inventory detail, crafting, trading, ledger, requests, and Player Card.
- Safe-area insets and small-screen rules are included. Market's older world HUD is hidden on narrow mobile screens to avoid duplicate chrome.
- Presentation state is DOM-only and is not serialized into Player Card/save state.
- No free-drag UI was introduced; the existing mapped room world and drawer contract remain intact.
