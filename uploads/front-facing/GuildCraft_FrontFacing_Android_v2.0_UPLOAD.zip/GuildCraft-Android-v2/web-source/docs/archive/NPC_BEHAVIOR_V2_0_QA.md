# NPC Behavior / Dialogue v2.0 QA

This pass deepens existing simulation actors without adding new lore facts.

- Generic Market dialogue now consults relationship axes and recent trade memories.
- Trust, respect, suspicion, need, prior purchases and prior refusals can alter lines.
- Kerr Voss now performs explicit price haggling against displayed asking/sweet-spot values and remembers outcomes.
- Mira Quill remembers foreground liquidity purchases and comments on repeated movement.
- Rook Fen compares his simulated Wild haul with the player’s actual Wild-run/catalogue state.
- Named Market actors persist bounded relationship/memory records through the existing market actor snapshot.
- Wild traders retain temperament, relationship pricing, memory and special barter behavior.
- Protected hidden-rabbit rumor remains exactly: `did you hear someone found the Black Cottontail?` and remains one-shot/gated.
- No Plan lore was promoted to Current.
