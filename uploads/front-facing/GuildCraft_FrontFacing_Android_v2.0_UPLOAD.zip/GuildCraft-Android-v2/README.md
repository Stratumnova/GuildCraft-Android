# GuildCraft Android v2

This project wraps the fullscreen Cibola checkpoint in Capacitor. It contains Portal v2.3, Trapline / The Wild v2.6, and Market Stall v2.5. The Portal is the app entry point and remains the main screen and pause hub.

## Build a debug APK

Requirements: Android Studio with the Android SDK, Node.js, and Java 21.

1. Run `npm install`.
2. Run `npm run build:debug`.
3. Find the APK at `android/app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, run `npm run sync:android`, then `npm run open:android` and build from Android Studio.

## Navigation

- Back closes the Memory Card/pause overlay first.
- Back inside Trapline or Market Stall saves and returns to the Portal.
- Swipe right from the left edge performs the same action.
- Back on the Portal requires a second press within 1.8 seconds to exit.
- Escape mirrors Back during desktop testing.

## Updating the bundled web build

The canonical web source in `web-source` is copied into `www` by `npm run sync:web`. Make web changes in `web-source`, then synchronize. Do not flatten the Portal, Trapline, or Market Stall directories; their relative links depend on the existing structure.
