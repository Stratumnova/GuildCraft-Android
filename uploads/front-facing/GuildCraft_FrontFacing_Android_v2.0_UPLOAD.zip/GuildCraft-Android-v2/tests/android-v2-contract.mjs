import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = relative => fs.readFileSync(path.join(root, relative), 'utf8');

for (const required of ['package.json','capacitor.config.json','www/index.html','www/portal/index.html','www/trapline/index.html','www/market-stall/index.html','www/shared/roomShell.js','www/assets/cibola']) {
  assert.ok(fs.existsSync(path.join(root, required)), `${required} must be bundled in v2`);
}
const pkg = JSON.parse(read('package.json'));
assert.equal(pkg.version, '2.0.0');
assert.equal(pkg.dependencies['@capacitor/core'], '8.5.2');
assert.equal(pkg.dependencies['@capacitor/android'], '8.5.2');
assert.equal(pkg.dependencies['@capacitor/app'], '8.1.1');
const capacitor = JSON.parse(read('capacitor.config.json'));
assert.equal(capacitor.webDir, 'www');
assert.equal(capacitor.appId, 'org.neocities.guildcraft');
assert.match(read('www/index.html'), /portal\/index\.html/);
assert.match(read('android/app/src/main/AndroidManifest.xml'), /screenOrientation="sensorLandscape"/);
assert.match(read('android/app/build.gradle'), /versionCode 2/);
assert.match(read('android/app/build.gradle'), /versionName "2\.0"/);
const roomShell = read('www/shared/roomShell.js');
assert.match(roomShell, /GC_ANDROID_BACK/);
assert.match(roomShell, /toolsOpen/);
assert.match(roomShell, /beforePortal/);
const portal = read('www/portal/portal.js');
assert.match(portal, /backButton/);
assert.match(portal, /GC_ANDROID_BACK/);
assert.match(portal, /gcPauseOverlay/);
assert.match(portal, /returnToPortal/);
assert.match(portal, /exitApp/);
console.log('PASS: GuildCraft Android v2 packaging and Back contract');
