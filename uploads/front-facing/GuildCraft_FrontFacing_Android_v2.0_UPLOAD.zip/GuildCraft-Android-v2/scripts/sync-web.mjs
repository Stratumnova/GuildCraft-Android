import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source = path.join(project, 'web-source');
const www = path.join(project, 'www');
const entries = ['index.html', 'portal', 'trapline', 'market-stall', 'shared', 'assets'];

for (const entry of entries) {
  const from = path.join(source, entry);
  const to = path.join(www, entry);
  if (!fs.existsSync(from)) throw new Error(`Missing v2 web source: ${from}`);
  fs.cpSync(from, to, { recursive: true, force: true });
}

console.log(`Synced GuildCraft v2 web application into ${www}`);
