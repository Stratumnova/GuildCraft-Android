package org.neocities.guildcraft;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
